"""Purrcept Cel 样式 lint：在使用方的 CSS / HTML 中禁止 Token 之外的视觉裸值。

职责：

- 扫描 ``.css`` 文件、HTML 的 ``<style>`` 块与 ``style="..."`` 属性；
- 对受治理的属性（颜色、圆角、阴影、动效）要求只引用 ``--pc-*`` Token；
- 禁止规范明令禁止的材质：渐变字面量、不是 ``--pc-material-*-filter`` 的毛玻璃、模糊；
- 禁止使用方覆盖 ``--pc-*`` 或引用不存在的 Token；
- 支持带理由的逐行豁免：``/* purrcept-lint-disable-next-line PC005 -- 热力图编码连续数据 */``。

不负责：

- 不是完整的 CSS 解析器；它按声明扫描，足以覆盖手写样式，但不理解预处理器语法。
- 不扫描 JS/TS 中的内联样式与 CSS-in-JS；这类代码应改为引用 CSS 变量。
- 不检查间距和字号裸值：它们由评审与“交付前检查”约束，机器强制的噪声大于收益。
"""

from __future__ import annotations

import argparse
import bisect
import re
import sys
from collections.abc import Callable, Iterable, Iterator, Sequence
from dataclasses import dataclass
from pathlib import Path

from export_tokens import DEFAULT_DESIGN, GENERATED_NOTE, TokenError, load_tokens, render_css

# ---------------------------------------------------------------------------
# 规则
# ---------------------------------------------------------------------------

RULES = {
    "PC000": "directive",
    "PC001": "raw-color",
    "PC002": "raw-radius",
    "PC003": "raw-shadow",
    "PC004": "raw-motion",
    "PC005": "forbidden-material",
    "PC006": "token-override",
    "PC007": "unknown-token",
}

SKIP_DIRS = {"node_modules", ".git", ".venv", "__pycache__", ".pytest_cache", ".ruff_cache"}
STYLE_SUFFIXES = {".css"}
HTML_SUFFIXES = {".html", ".htm"}

# 只在这些属性里把“red / white”之类的单词视为颜色，避免误伤动画名等标识符。
COLOR_PROPERTIES = {
    "color",
    "background",
    "background-color",
    "border",
    "border-top",
    "border-right",
    "border-bottom",
    "border-left",
    "border-block",
    "border-inline",
    "border-block-start",
    "border-block-end",
    "border-inline-start",
    "border-inline-end",
    "outline",
    "outline-color",
    "fill",
    "stroke",
    "caret-color",
    "accent-color",
    "text-decoration",
    "text-decoration-color",
    "text-emphasis-color",
    "column-rule",
    "column-rule-color",
    "scrollbar-color",
    "stop-color",
    "flood-color",
    "lighting-color",
}

SHADOW_PROPERTIES = {"box-shadow", "text-shadow"}

BACKDROP_PROPERTIES = {"backdrop-filter", "-webkit-backdrop-filter"}

MOTION_PROPERTIES = {
    "transition",
    "transition-duration",
    "transition-timing-function",
    "transition-delay",
    "animation",
    "animation-duration",
    "animation-timing-function",
    "animation-delay",
}

CSS_WIDE_KEYWORDS = {"inherit", "initial", "unset", "revert", "revert-layer"}

# CSS Color 4 全部命名颜色；按段落排列比列表字面量更易对照规范核对。
NAMED_COLORS = frozenset(
    """
    aliceblue antiquewhite aqua aquamarine azure beige bisque black blanchedalmond blue
    blueviolet brown burlywood cadetblue chartreuse chocolate coral cornflowerblue cornsilk
    crimson cyan darkblue darkcyan darkgoldenrod darkgray darkgreen darkgrey darkkhaki
    darkmagenta darkolivegreen darkorange darkorchid darkred darksalmon darkseagreen
    darkslateblue darkslategray darkslategrey darkturquoise darkviolet deeppink deepskyblue
    dimgray dimgrey dodgerblue firebrick floralwhite forestgreen fuchsia gainsboro ghostwhite
    gold goldenrod gray green greenyellow grey honeydew hotpink indianred indigo ivory khaki
    lavender lavenderblush lawngreen lemonchiffon lightblue lightcoral lightcyan
    lightgoldenrodyellow lightgray lightgreen lightgrey lightpink lightsalmon lightseagreen
    lightskyblue lightslategray lightslategrey lightsteelblue lightyellow lime limegreen linen
    magenta maroon mediumaquamarine mediumblue mediumorchid mediumpurple mediumseagreen
    mediumslateblue mediumspringgreen mediumturquoise mediumvioletred midnightblue mintcream
    mistyrose moccasin navajowhite navy oldlace olive olivedrab orange orangered orchid
    palegoldenrod palegreen paleturquoise palevioletred papayawhip peachpuff peru pink plum
    powderblue purple rebeccapurple red rosybrown royalblue saddlebrown salmon sandybrown
    seagreen seashell sienna silver skyblue slateblue slategray slategrey snow springgreen
    steelblue tan teal thistle tomato turquoise violet wheat white whitesmoke yellow
    yellowgreen
    """.split()  # noqa: SIM905
)

_HEX_COLOR = re.compile(r"#(?:[0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{3,4})(?![0-9a-zA-Z_-])")
_COLOR_FUNCTION = re.compile(
    r"(?<![\w-])(rgba?|hsla?|hwb|lab|lch|oklab|oklch|color|color-mix)\(", re.IGNORECASE
)
_GRADIENT = re.compile(r"(?<![\w-])(?:repeating-)?(?:linear|radial|conic)-gradient\(", re.I)
_WORD = re.compile(r"(?<![\w-])([A-Za-z]+)(?![\w-])")
_VAR = re.compile(r"var\(\s*(--[\w-]+)")
_VAR_CALL = re.compile(r"var\([^()]*\)")
_MATERIAL_FILTER = re.compile(r"var\(\s*--pc-material-[a-z0-9-]+-filter\s*\)")
_LENGTH = re.compile(
    r"(?<![\w.#-])(\d*\.?\d+)(px|rem|em|%|vh|vw|vmin|vmax|ch|ex|cm|mm|in|pt|pc)(?![\w-])", re.I
)
_TIME = re.compile(r"(?<![\w.#-])(\d*\.?\d+)(ms|s)(?![\w-])", re.I)
_EASING_FUNCTION = re.compile(r"(?<![\w-])(cubic-bezier|steps|linear)\(", re.I)
_EASING_KEYWORD = re.compile(
    r"(?<![\w-])(ease-in-out|ease-in|ease-out|ease|linear|step-start|step-end)(?![\w(-])", re.I
)
_DECLARATION = re.compile(r"(?<![\w-])(--[\w-]+|-?[A-Za-z][\w-]*)\s*:([^;{}]*)(?=[;}])")
_STYLE_BLOCK = re.compile(r"<style\b[^>]*>(.*?)</style\s*>", re.I | re.S)
_STYLE_ATTR = re.compile(r"""\sstyle\s*=\s*(?:"([^"]*)"|'([^']*)')""", re.I)
_HTML_COMMENT = re.compile(r"<!--(.*?)-->", re.S)
_DIRECTIVE = re.compile(
    r"^purrcept-lint-disable-next-line\s+(PC\d{3}(?:\s*,\s*PC\d{3})*)\s*--\s*(\S.*)$", re.S
)


@dataclass(frozen=True, slots=True)
class Violation:
    """一条违规。``line`` / ``column`` 从 1 开始。"""

    path: str
    line: int
    column: int
    code: str
    message: str

    def format(self) -> str:
        return (
            f"{self.path}:{self.line}:{self.column}: {self.code} {RULES[self.code]} {self.message}"
        )


@dataclass(frozen=True, slots=True)
class _Directive:
    line: int
    column: int
    target_line: int
    codes: frozenset[str]


# ---------------------------------------------------------------------------
# 文本预处理
# ---------------------------------------------------------------------------


def _mask_css(text: str) -> tuple[str, list[tuple[int, int, str]]]:
    """把注释、字符串内容和 ``url()`` 参数替换为空格，保留换行与偏移。

    返回 ``(masked, comments)``，``comments`` 是 ``(start, end, inner_text)``。
    这样颜色、时长等检测不会被注释或字体名中的字符误触发。
    """

    out = list(text)
    comments: list[tuple[int, int, str]] = []

    def blank(start: int, end: int) -> None:
        for k in range(start, end):
            if out[k] != "\n":
                out[k] = " "

    i, n = 0, len(text)
    while i < n:
        if text.startswith("/*", i):
            close = text.find("*/", i + 2)
            end = n if close < 0 else close + 2
            comments.append((i, end, text[i + 2 : close if close >= 0 else n]))
            blank(i, end)
            i = end
        elif text[i] in "\"'":
            quote, j = text[i], i + 1
            while j < n and text[j] != quote and text[j] != "\n":
                j += 2 if text[j] == "\\" else 1
            blank(i + 1, min(j, n))
            i = j + 1
        elif text[i : i + 4].lower() == "url(":
            close = text.find(")", i + 4)
            end = n if close < 0 else close
            blank(i + 4, end)
            i = end
        else:
            i += 1
    return "".join(out), comments


class _Locator:
    """偏移量到行列号的换算。"""

    def __init__(self, text: str) -> None:
        self._starts = [0] + [m.end() for m in re.finditer("\n", text)]

    def __call__(self, offset: int) -> tuple[int, int]:
        index = bisect.bisect_right(self._starts, offset) - 1
        return index + 1, offset - self._starts[index] + 1


# ---------------------------------------------------------------------------
# 声明检查
# ---------------------------------------------------------------------------

Report = Callable[[int, str, str], None]


def _check_declaration(
    prop: str,
    prop_offset: int,
    value: str,
    value_offset: int,
    known: frozenset[str],
    report: Report,
) -> None:
    """检查单条声明。``value`` 已经过遮蔽，偏移以整个文件为基准。"""

    name = prop.lower()

    # 覆盖 Token 等于在局部发明一套视觉值。
    if name.startswith("--pc-"):
        report(prop_offset, "PC006", f"不能在使用方覆盖 Token {prop}；修改 DESIGN.md 并重新导出")

    for m in _VAR.finditer(value):
        ref = m.group(1)
        if ref.startswith("--pc-") and ref not in known:
            report(value_offset + m.start(1), "PC007", f"Token {ref} 不存在")

    # 颜色字面量在任何属性中都不允许，包括自定义属性（防止 --my-blue: #123 绕过）。
    for m in _HEX_COLOR.finditer(value):
        report(
            value_offset + m.start(), "PC001", f"不能直接使用颜色 {m.group()}；请引用 --pc-color-*"
        )
    for m in _COLOR_FUNCTION.finditer(value):
        if m.group(1).lower() == "color" and name not in COLOR_PROPERTIES:
            continue
        report(
            value_offset + m.start(), "PC001", f"不能直接使用 {m.group(1)}()；请引用 --pc-color-*"
        )

    for m in _GRADIENT.finditer(value):
        report(
            value_offset + m.start(),
            "PC005",
            "渐变只能引用 --pc-gradient-*（背景美术）；只有编码连续数据时可带理由豁免",
        )

    if name in BACKDROP_PROPERTIES:
        _check_backdrop(value, prop_offset, report)
    if name == "filter":
        for fn, code, message in (
            ("blur(", "PC005", "规范禁止模糊材质"),
            ("drop-shadow(", "PC003", "不能用 drop-shadow 制造阴影；请引用 --pc-shadow-*"),
        ):
            index = value.lower().find(fn)
            if index >= 0:
                report(value_offset + index, code, message)

    if name in COLOR_PROPERTIES:
        for m in _WORD.finditer(value):
            if m.group(1).lower() in NAMED_COLORS:
                report(value_offset + m.start(), "PC001", f"不能直接使用颜色名 {m.group(1)}")
        _check_foreign_vars(value, value_offset, "PC001", "--pc-color-", report)

    if "radius" in name:
        for m in _LENGTH.finditer(value):
            if float(m.group(1)) != 0:
                report(
                    value_offset + m.start(),
                    "PC002",
                    f"不能直接使用圆角 {m.group()}；请引用 --pc-radius-*",
                )
        _check_foreign_vars(value, value_offset, "PC002", "--pc-radius-", report)

    if name in SHADOW_PROPERTIES:
        residue = _strip_vars(value)
        residue = re.sub(r"[\s,]+", " ", residue).strip().lower()
        if residue and residue not in {"none"} | CSS_WIDE_KEYWORDS:
            report(
                value_offset + _first_non_space(value),
                "PC003",
                "阴影必须引用 --pc-shadow-* 或为 none",
            )
        _check_foreign_vars(value, value_offset, "PC003", "--pc-shadow-", report)

    if name in MOTION_PROPERTIES:
        for m in _TIME.finditer(value):
            if float(m.group(1)) != 0:
                report(
                    value_offset + m.start(),
                    "PC004",
                    f"不能直接使用时长 {m.group()}；请引用 --pc-motion-*",
                )
        for m in _EASING_FUNCTION.finditer(value):
            report(
                value_offset + m.start(),
                "PC004",
                f"不能自定义缓动 {m.group(1)}()；请引用 --pc-motion-*-easing",
            )
        for m in _EASING_KEYWORD.finditer(value):
            report(
                value_offset + m.start(),
                "PC004",
                f"不能直接使用缓动 {m.group(1)}；请引用 --pc-motion-*-easing",
            )
        _check_foreign_vars(value, value_offset, "PC004", "--pc-motion-", report)


def _check_backdrop(value: str, prop_offset: int, report: Report) -> None:
    """玻璃只有一种：``backdrop-filter`` 只能是单个 ``var(--pc-material-*-filter)`` 或 none。"""

    stripped = value.strip()
    if stripped.lower() in {"none"} | CSS_WIDE_KEYWORDS:
        return
    if _MATERIAL_FILTER.fullmatch(stripped) is None:
        report(
            prop_offset,
            "PC005",
            "backdrop-filter 只能引用 --pc-material-*-filter；玻璃只用于导航轨与浮层",
        )


def _check_foreign_vars(value: str, offset: int, code: str, hint: str, report: Report) -> None:
    """受治理属性只能引用 ``--pc-*``：局部别名（例如 ``--accent``）同样是一套私有视觉值。"""

    for m in _VAR.finditer(value):
        ref = m.group(1)
        if not ref.startswith("--pc-"):
            report(
                offset + m.start(1), code, f"只能引用 Token，不能引用局部变量 {ref}；请使用 {hint}*"
            )


def _strip_vars(value: str) -> str:
    previous = None
    while previous != value:
        previous, value = value, _VAR_CALL.sub(" ", value)
    return value


def _first_non_space(value: str) -> int:
    return len(value) - len(value.lstrip())


def _declarations(
    masked: str, start: int, end: int, inline: bool
) -> Iterator[tuple[str, int, str, int]]:
    """在 ``masked[start:end]`` 中枚举 ``(属性, 属性偏移, 值, 值偏移)``。

    ``inline`` 为 True 时（style 属性）末尾没有 ``;`` 或 ``}``，补一个虚拟分号。
    """

    segment = masked[start:end] + (";" if inline else "")
    for m in _DECLARATION.finditer(segment):
        yield m.group(1), start + m.start(1), m.group(2), start + m.start(2)


# ---------------------------------------------------------------------------
# 文件
# ---------------------------------------------------------------------------


def lint_text(
    text: str, path: str, known: frozenset[str], *, html: bool = False
) -> list[Violation]:
    """检查一段 CSS 或 HTML 文本。"""

    if GENERATED_NOTE in text[:400]:
        return []

    locate = _Locator(text)
    raw: list[tuple[int, str, str]] = []

    def report(offset: int, code: str, message: str) -> None:
        raw.append((offset, code, message))

    comments: list[tuple[int, int, str]] = []

    if html:
        regions: list[tuple[int, int, bool]] = []
        for m in _STYLE_BLOCK.finditer(text):
            regions.append((m.start(1), m.end(1), False))
        for m in _STYLE_ATTR.finditer(text):
            group = 1 if m.group(1) is not None else 2
            regions.append((m.start(group), m.end(group), True))
        comments += [(m.start(), m.end(), m.group(1)) for m in _HTML_COMMENT.finditer(text)]

        masked_chars = list(text)
        for start, end, _ in regions:
            masked_region, region_comments = _mask_css(text[start:end])
            masked_chars[start:end] = masked_region
            comments += [(start + s, start + e, inner) for s, e, inner in region_comments]
        masked = "".join(masked_chars)
    else:
        masked, comments = _mask_css(text)
        regions = [(0, len(text), False)]

    for start, end, inline in regions:
        for prop, prop_offset, value, value_offset in _declarations(masked, start, end, inline):
            _check_declaration(prop, prop_offset, value, value_offset, known, report)

    directives, directive_problems = _parse_directives(comments, locate)
    violations = [Violation(path, *locate(o), code, msg) for o, code, msg in directive_problems]

    used: set[int] = set()
    for offset, code, message in raw:
        line, column = locate(offset)
        suppressing = [
            i for i, d in enumerate(directives) if d.target_line == line and code in d.codes
        ]
        if suppressing:
            used.update(suppressing)
            continue
        violations.append(Violation(path, line, column, code, message))

    # 不再生效的豁免会掩盖未来的问题，必须清理。
    for i, d in enumerate(directives):
        if i not in used:
            violations.append(
                Violation(path, d.line, d.column, "PC000", "该豁免没有抑制任何问题，请删除")
            )

    return sorted(violations, key=lambda v: (v.line, v.column, v.code))


def _parse_directives(
    comments: Iterable[tuple[int, int, str]], locate: _Locator
) -> tuple[list[_Directive], list[tuple[int, str, str]]]:
    directives: list[_Directive] = []
    problems: list[tuple[int, str, str]] = []

    for start, end, inner in comments:
        body = inner.strip()
        if "purrcept-lint-disable" not in body:
            continue
        match = _DIRECTIVE.match(body)
        if not match:
            problems.append(
                (
                    start,
                    "PC000",
                    "豁免格式应为 purrcept-lint-disable-next-line PC00X -- 理由（理由必填）",
                )
            )
            continue
        codes = frozenset(c.strip() for c in match.group(1).split(","))
        unknown = sorted(codes - RULES.keys())
        if unknown:
            problems.append((start, "PC000", f"未知的规则 {', '.join(unknown)}"))
            continue
        line, column = locate(start)
        end_line, _ = locate(max(start, end - 1))
        directives.append(_Directive(line, column, end_line + 1, codes))
    return directives, problems


def lint_file(path: Path, known: frozenset[str], display: str | None = None) -> list[Violation]:
    """检查单个文件；按扩展名决定 CSS 或 HTML 模式。"""

    text = path.read_text(encoding="utf-8")
    return lint_text(text, display or str(path), known, html=path.suffix.lower() in HTML_SUFFIXES)


def iter_targets(paths: Iterable[Path]) -> Iterator[Path]:
    """展开目录，按路径排序以保证输出稳定。"""

    suffixes = STYLE_SUFFIXES | HTML_SUFFIXES
    for path in paths:
        if path.is_dir():
            for child in sorted(path.rglob("*")):
                if (
                    child.is_file()
                    and child.suffix.lower() in suffixes
                    and not (SKIP_DIRS & set(child.relative_to(path).parts))
                ):
                    yield child
        else:
            yield path


def known_tokens(design: Path) -> frozenset[str]:
    """从 DESIGN.md 推导全部合法的 ``--pc-*`` 变量名，与导出产物保持同源。"""

    css = render_css(load_tokens(design))
    return frozenset(re.findall(r"^\s*(--pc-[\w-]+):", css, re.M))


def main(argv: Sequence[str] | None = None) -> int:
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            reconfigure(encoding="utf-8")

    parser = argparse.ArgumentParser(description="检查 CSS / HTML 是否只使用 Purrcept Cel Token。")
    parser.add_argument("paths", nargs="+", type=Path, help="要检查的文件或目录")
    parser.add_argument("--design", type=Path, default=DEFAULT_DESIGN, help="DESIGN.md 路径")
    args = parser.parse_args(argv)

    try:
        known = known_tokens(args.design)
    except TokenError as exc:
        print(f"DESIGN.md 不合法，无法确定 Token：\n{exc}", file=sys.stderr)
        return 2

    missing = [str(p) for p in args.paths if not p.exists()]
    if missing:
        print(f"路径不存在：{', '.join(missing)}", file=sys.stderr)
        return 2

    files = list(iter_targets(args.paths))
    violations = [v for f in files for v in lint_file(f, known)]
    for violation in violations:
        print(violation.format())

    if violations:
        print(
            f"\n{len(violations)} 个问题，涉及 {len({v.path for v in violations})} 个文件。",
            file=sys.stderr,
        )
        return 1
    print(f"已检查 {len(files)} 个文件，没有发现问题。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
