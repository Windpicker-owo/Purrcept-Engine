"""从 DESIGN.md 文件头导出 Purrcept Cel 设计 Token。

职责：

- 读取 ``DESIGN.md`` 的 YAML 文件头，它是全部 Token 的唯一规范值；
- 按 AGENTS.md 的不可破坏规则做严格校验（引用完整、禁止裸值、回弹上限、颜色过渡时长、
  文本对比度、柔和墨影、背景美术渐变与玻璃材质的可读性），一次汇总全部问题；
- 生成 ``dist/purrcept.css``（CSS 变量）、``dist/motion.js`` / ``dist/motion.d.ts``
  （Motion 预设）和 ``dist/tokens.json``（完全解析后的值）；
- ``--check`` 模式只比较、不写入，用于 CI 防止产物与规范脱节。

不负责：

- 不生成组件样式或工具类；组件如何使用变量属于参考实现。
- 不读取 Markdown 正文；正文是决策依据，不是机器契约。
- 不做主题切换；深色主题以后作为独立 Token 集加入。
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, TypeGuard, cast

import yaml

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DESIGN = ROOT / "DESIGN.md"
DEFAULT_OUT = ROOT / "dist"

CSS_PREFIX = "pc"
GENERATED_NOTE = "由 scripts/export_tokens.py 从 DESIGN.md 生成，请勿手动修改。"


# ---------------------------------------------------------------------------
# 规范常量：这些数字来自 DESIGN.md 正文与 AGENTS.md，改动它们等同于修改规范。
# ---------------------------------------------------------------------------

# “个性但不嘈杂”在动效上的量化边界。
MAX_BOUNCE = 0.18
# 平涂的时间维度：颜色变化不得超过 120ms，避免中间帧出现浑浊混色。
MAX_TWEEN_SECONDS = 0.12
# 顿帧只是一次短促停顿，不是等待。
MAX_HOLD_SECONDS = 0.2
# “运行中”唯一允许的低幅循环：周期与峰值缩放的边界。
MIN_LOOP_SECONDS = 0.8
MAX_LOOP_SECONDS = 3.0
MAX_LOOP_SCALE = 1.5
# 柔影：外阴影的不透明度上限，超过即成为“重影”。
MAX_SHADOW_ALPHA = 0.24
# inset 受光边只允许纯白；外阴影与下沉 inset 只允许墨色。
HIGHLIGHT_RGB = (255, 255, 255)
# 玻璃：底色不透明度下限保证没有模糊时也可读；模糊与饱和度的合理区间。
MIN_GLASS_ALPHA = 0.7
MIN_GLASS_BLUR_PX = 8
MAX_GLASS_BLUR_PX = 40
MIN_GLASS_SATURATE = 1.0
MAX_GLASS_SATURATE = 2.0
# 弹簧视为静止的位移阈值（目标距离的千分之一）。
SPRING_REST_DELTA = 0.001
# 弹簧采样间隔，用于生成 CSS linear()。
SPRING_SAMPLE_MS = 10
SPRING_MIN_SAMPLES = 24
SPRING_MAX_MS = 10_000

TOP_LEVEL_KEYS = (
    "version",
    "name",
    "description",
    "colors",
    "typography",
    "rounded",
    "spacing",
    "elevation",
    "gradients",
    "materials",
    "motion",
    "contrast",
    "components",
)

# 组件可引用的 Token 组与它们在 CSS 变量中的前缀。
REFERENCE_GROUPS = {
    "colors": "color",
    "typography": "font",
    "rounded": "radius",
    "spacing": "space",
}

TWEEN_EASINGS = {
    "linear": "linear",
    "easeIn": "ease-in",
    "easeOut": "ease-out",
    "easeInOut": "ease-in-out",
}

MOTION_SCALARS = {"stagger", "stagger-max-items"}

_NAME = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
_HEX = re.compile(r"^#[0-9A-Fa-f]{6}$")
_RGBA = re.compile(r"^rgba\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(0|1|0?\.\d+)\s*\)$")
_PX = re.compile(r"^(?:0|\d+(?:\.\d+)?px)$")
_EM = re.compile(r"^-?\d+(?:\.\d+)?em$")
_REF = re.compile(r"\{([a-z]+)\.([a-z0-9-]+)\}")
_FULL_REF = re.compile(r"^\{([a-z]+)\.([a-z0-9-]+)\}$")
# 单层阴影：可选 inset + 2–4 个长度 + rgba 颜色。inset 的颜色另行限制为墨色或纯白。
_SHADOW = re.compile(r"^(inset\s+)?(?:(?:-?\d+(?:\.\d+)?px|0)\s+){2,4}(rgba\([^()]*\))$")
# 渐变层：只允许线性与径向，不允许 conic / repeating（它们只会被用来做装饰）。
_GRADIENT_LAYER = re.compile(r"^(linear|radial)-gradient\((.+)\)$", re.S)
# 渐变参数中除颜色引用外允许出现的单词：方向、形状、尺寸关键字与 transparent。
_GRADIENT_WORDS = frozenset(
    """
    to top bottom left right center at circle ellipse transparent deg turn
    closest-side closest-corner farthest-side farthest-corner px
    """.split()  # noqa: SIM905
)


class TokenError(Exception):
    """Token 源不合法。``problems`` 汇总全部问题，便于一次修完。"""

    def __init__(self, problems: Sequence[str]) -> None:
        self.problems = tuple(problems)
        super().__init__("\n".join(f"- {p}" for p in self.problems))


# ---------------------------------------------------------------------------
# 数据模型
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Typography:
    """一个字体层级。``font`` 是可直接用于 CSS ``font`` 简写的值。"""

    family: str
    size: str
    weight: int
    line_height: float
    letter_spacing: str | None
    feature_settings: str | None

    @property
    def font(self) -> str:
        return f"{self.weight} {self.size}/{_number(self.line_height)} {self.family}"


@dataclass(frozen=True, slots=True)
class Spring:
    """Motion 弹簧。物理参数与 Motion 内部由 visualDuration/bounce 推导的结果一致。"""

    visual_duration: float
    bounce: float
    stiffness: float
    damping: float
    duration_ms: int
    samples: tuple[float, ...]


@dataclass(frozen=True, slots=True)
class Tween:
    """固定时长过渡，只允许用于颜色变化。"""

    duration: float
    ease: str


@dataclass(frozen=True, slots=True)
class Hold:
    """顿帧：状态切换时的一次短停顿。"""

    duration: float


@dataclass(frozen=True, slots=True)
class Loop:
    """低幅循环：只给“运行中”状态使用，``scale`` 是循环峰值。"""

    duration: float
    scale: float


MotionToken = Spring | Tween | Hold | Loop


@dataclass(frozen=True, slots=True)
class ComponentProperty:
    """组件属性。``css`` 使用 ``var()`` 引用，``resolved`` 是展开后的具体值。"""

    name: str
    css: str
    resolved: str


@dataclass(frozen=True, slots=True)
class Gradient:
    """背景美术渐变。``css`` 用 ``var()`` 引用颜色，``resolved`` 是展开后的具体值。"""

    css: str
    resolved: str


@dataclass(frozen=True, slots=True)
class Material:
    """磨砂材质：底色引用一个 rgba 颜色 Token，``filter`` 是 ``backdrop-filter`` 的值。"""

    tint: str
    tint_resolved: str
    blur_px: float
    saturate: float

    @property
    def filter(self) -> str:
        return f"blur({_number(self.blur_px)}px) saturate({round(self.saturate * 100)}%)"


@dataclass(frozen=True, slots=True)
class Tokens:
    """校验通过后的完整 Token 集，所有映射保持文件头中的声明顺序。"""

    version: str
    name: str
    description: str
    colors: Mapping[str, str]
    typography: Mapping[str, Typography]
    rounded: Mapping[str, str]
    spacing: Mapping[str, str]
    elevation: Mapping[str, str]
    gradients: Mapping[str, Gradient]
    materials: Mapping[str, Material]
    motion: Mapping[str, MotionToken]
    stagger: float
    stagger_max_items: int
    components: Mapping[str, tuple[ComponentProperty, ...]]


# ---------------------------------------------------------------------------
# 读取
# ---------------------------------------------------------------------------


def parse_front_matter(text: str) -> dict[str, Any]:
    """取出 Markdown 开头 ``---`` 包围的 YAML 并解析为映射。"""

    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        raise TokenError(["DESIGN.md 必须以 '---' 开头的 YAML 文件头起始"])

    try:
        end = next(i for i, line in enumerate(lines[1:], start=1) if line.strip() == "---")
    except StopIteration:
        raise TokenError(["YAML 文件头缺少结束的 '---'"]) from None

    try:
        data = yaml.safe_load("\n".join(lines[1:end]))
    except yaml.YAMLError as exc:
        raise TokenError([f"YAML 解析失败：{exc}"]) from None

    if not _is_mapping(data):
        raise TokenError(["YAML 文件头必须是映射"])
    return data


def load_tokens(path: Path) -> Tokens:
    """读取并校验 DESIGN.md。"""

    return validate(parse_front_matter(path.read_text(encoding="utf-8")))


# ---------------------------------------------------------------------------
# 校验
# ---------------------------------------------------------------------------


def validate(data: Mapping[str, Any]) -> Tokens:
    """把原始文件头转换为 ``Tokens``；任何不合规之处都汇总进 ``TokenError``。"""

    problems: list[str] = []

    unknown = [k for k in data if k not in TOP_LEVEL_KEYS]
    missing = [k for k in TOP_LEVEL_KEYS if k not in data]
    if unknown:
        problems.append(f"未知的顶层字段：{', '.join(map(str, unknown))}")
    if missing:
        problems.append(f"缺少顶层字段：{', '.join(missing)}")
    if missing:
        raise TokenError(problems)

    meta = {k: data[k] for k in ("version", "name", "description")}
    for key, value in meta.items():
        if not isinstance(value, str) or not value.strip():
            problems.append(f"{key} 必须是非空字符串")

    colors = _validate_colors(data["colors"], problems)
    typography = _validate_typography(data["typography"], problems)
    rounded = _validate_dimensions("rounded", data["rounded"], problems)
    spacing = _validate_dimensions("spacing", data["spacing"], problems)
    elevation = _validate_elevation(data["elevation"], colors, problems)
    spec = _contrast_spec(data["contrast"])
    gradients = _validate_gradients(data["gradients"], colors, spec, problems)
    materials = _validate_materials(data["materials"], colors, spec, problems)
    motion, stagger, stagger_max = _validate_motion(data["motion"], problems)

    groups: dict[str, Mapping[str, Any]] = {
        "colors": colors,
        "typography": typography,
        "rounded": rounded,
        "spacing": spacing,
    }
    components = _validate_components(data["components"], groups, problems)

    _validate_contrast(data["contrast"], colors, data["components"], problems)

    if problems:
        raise TokenError(problems)

    return Tokens(
        version=meta["version"],
        name=meta["name"],
        description=meta["description"],
        colors=colors,
        typography=typography,
        rounded=rounded,
        spacing=spacing,
        elevation=elevation,
        gradients=gradients,
        materials=materials,
        motion=motion,
        stagger=stagger,
        stagger_max_items=stagger_max,
        components=components,
    )


def _validate_elevation(raw: Any, colors: Mapping[str, str], problems: list[str]) -> dict[str, str]:
    """阴影必须是柔和的墨色；inset 只能是墨色（下沉）或纯白（受光边）。

    彩色阴影、白色外发光和过重的影子在规范中被禁止。
    """

    ink = _hex_rgb(colors.get("ink", ""))
    result: dict[str, str] = {}

    for key, value in _group("elevation", raw, problems).items():
        where = f"elevation.{key}"
        if not isinstance(value, str) or not value.strip():
            problems.append(f"{where} 必须是非空字符串")
            continue

        ok = True
        for layer in _split_top_level(value):
            match = _SHADOW.match(layer.strip())
            if not match or not _valid_rgba(match.group(2)):
                problems.append(
                    f"{where}：{layer.strip()!r} 不是“可选 inset + 2–4 个 px 长度 + rgba()”的阴影"
                )
                ok = False
                continue
            inset = match.group(1) is not None
            rgba = _RGBA.match(match.group(2))
            assert rgba is not None
            rgb = tuple(int(rgba.group(i)) for i in (1, 2, 3))
            alpha = float(rgba.group(4))
            if inset:
                if ink is None or rgb not in (ink, HIGHLIGHT_RGB):
                    problems.append(f"{where}：inset 阴影只能是墨色（colors.ink）或纯白受光边")
                    ok = False
            elif ink is None or rgb != ink:
                problems.append(f"{where}：阴影颜色必须与 colors.ink 同 RGB，禁止彩色阴影与发光")
                ok = False
            elif alpha > MAX_SHADOW_ALPHA:
                problems.append(f"{where}：外阴影不透明度 {alpha} 超过柔影上限 {MAX_SHADOW_ALPHA}")
                ok = False
        if ok:
            result[key] = value
    return result


def _contrast_spec(raw: Any) -> tuple[float, list[str], list[str]] | None:
    """取出 ``contrast`` 段的 ``(minimum, text, backgrounds)``。

    格式问题由 ``_validate_contrast`` 统一报告，这里只在格式正确时返回值。
    """

    if not _is_mapping(raw):
        return None
    minimum, text, backgrounds = (_field(raw, k) for k in ("minimum", "text", "backgrounds"))
    if not _is_number(minimum) or not _is_str_list(text) or not _is_str_list(backgrounds):
        return None
    return float(minimum), text, backgrounds


def _validate_gradients(
    raw: Any,
    colors: Mapping[str, str],
    spec: tuple[float, list[str], list[str]] | None,
    problems: list[str],
) -> dict[str, Gradient]:
    """渐变只给背景美术：线性 / 径向，色标只能是已校验对比度的背景色或 transparent。

    这样渐变上的任何位置都是若干可读背景之间的插值，文字处处可读；同时杜绝颜色字面量。
    """

    backgrounds: set[str] = set(spec[2]) if spec else set()
    result: dict[str, Gradient] = {}

    for key, value in _group("gradients", raw, problems).items():
        where = f"gradients.{key}"
        if not isinstance(value, str) or not value.strip():
            problems.append(f"{where} 必须是非空字符串")
            continue

        local: list[str] = []
        for layer in _split_top_level(value):
            layer = layer.strip()
            match = _GRADIENT_LAYER.match(layer)
            if not match:
                local.append(f"{where}：{layer[:40]!r} 不是 linear-gradient() 或 radial-gradient()")
                continue
            body = match.group(2)
            for ref in _REF.finditer(body):
                group, name = ref.groups()
                if group != "colors":
                    local.append(f"{where}：只能引用 colors，得到 {{{group}.{name}}}")
                elif name not in colors:
                    local.append(f"{where}：引用的 {{colors.{name}}} 不存在")
                elif name not in backgrounds:
                    local.append(
                        f"{where}：色标 {{colors.{name}}} 不在 contrast.backgrounds 中，"
                        "其上的文字可读性无法保证"
                    )
            residue = _REF.sub(" ", body)
            if "#" in residue or "(" in residue:
                local.append(f"{where}：渐变中不能出现颜色字面量或函数，只能引用 {{colors.*}}")
                continue
            words = {w.lower() for w in re.findall(r"[A-Za-z][A-Za-z-]*", residue)}
            for word in sorted(words - _GRADIENT_WORDS):
                local.append(f"{where}：不允许的关键字或颜色名 {word!r}")

        if local:
            problems.extend(local)
            continue

        def css(m: re.Match[str]) -> str:
            return f"var(--{CSS_PREFIX}-color-{m.group(2)})"

        def resolved(m: re.Match[str]) -> str:
            return colors[m.group(2)]

        result[key] = Gradient(_REF.sub(css, value), _REF.sub(resolved, value))
    return result


def _validate_materials(
    raw: Any,
    colors: Mapping[str, str],
    spec: tuple[float, list[str], list[str]] | None,
    problems: list[str],
) -> dict[str, Material]:
    """磨砂材质：底色足够不透明，叠在 canvas 上时全部文字色可读；模糊与饱和度有界。"""

    result: dict[str, Material] = {}
    for key, item in _group("materials", raw, problems).items():
        where = f"materials.{key}"
        if not _is_mapping(item):
            problems.append(f"{where} 必须是映射")
            continue

        local = [f"{where}：未知字段 {e}" for e in sorted(set(item) - {"tint", "blur", "saturate"})]
        tint = _bare_color_ref(_field(item, "tint"))
        blur = _field(item, "blur")
        saturate = _field(item, "saturate")

        rgba = _RGBA.match(colors.get(tint, "")) if tint else None
        if tint is None or tint not in colors:
            local.append(f"{where}.tint 必须引用存在的颜色 Token，例如 {{colors.glass}}")
        elif rgba is None:
            local.append(f"{where}.tint：{{colors.{tint}}} 必须是 rgba() 半透明颜色")
        elif float(rgba.group(4)) < MIN_GLASS_ALPHA:
            local.append(
                f"{where}.tint：不透明度 {rgba.group(4)} 低于 {MIN_GLASS_ALPHA}，"
                "没有模糊时文字将不可读"
            )

        blur_px = _px_value(blur)
        if blur_px is None or not (MIN_GLASS_BLUR_PX <= blur_px <= MAX_GLASS_BLUR_PX):
            local.append(f"{where}.blur 必须是 {MIN_GLASS_BLUR_PX}–{MAX_GLASS_BLUR_PX}px")
        if not _is_number(saturate) or not (
            MIN_GLASS_SATURATE <= float(saturate) <= MAX_GLASS_SATURATE
        ):
            local.append(f"{where}.saturate 必须是 {MIN_GLASS_SATURATE}–{MAX_GLASS_SATURATE}")

        if not local and rgba is not None and spec is not None:
            local += _glass_contrast(where, rgba, colors, spec)

        if local:
            problems.extend(local)
            continue
        assert tint is not None and blur_px is not None
        result[key] = Material(
            f"var(--{CSS_PREFIX}-color-{tint})", colors[tint], blur_px, float(saturate)
        )
    return result


def _glass_contrast(
    where: str,
    rgba: re.Match[str],
    colors: Mapping[str, str],
    spec: tuple[float, list[str], list[str]],
) -> list[str]:
    """把玻璃底色按 alpha 叠在 canvas 上，检查 ``contrast.text`` 在合成色上的对比度。"""

    canvas = _hex_rgb(colors.get("canvas", ""))
    if canvas is None:
        return [f"{where}：需要不透明的 colors.canvas 才能校验玻璃上的文字对比度"]
    alpha = float(rgba.group(4))
    tint = [int(rgba.group(i)) for i in (1, 2, 3)]
    mixed = (
        round(tint[0] * alpha + canvas[0] * (1 - alpha)),
        round(tint[1] * alpha + canvas[1] * (1 - alpha)),
        round(tint[2] * alpha + canvas[2] * (1 - alpha)),
    )
    minimum, text, _ = spec
    out: list[str] = []
    for name in text:
        fg = _hex_rgb(colors.get(name, ""))
        if fg is None:
            continue
        ratio = contrast_ratio(fg, mixed)
        if ratio < minimum:
            out.append(f"{where}：{name} 在玻璃（叠在 canvas 上）的对比度 {ratio:.2f} 过低")
    return out


def _px_value(value: Any) -> float | None:
    if isinstance(value, str) and re.match(r"^\d+(?:\.\d+)?px$", value):
        return float(value[:-2])
    return None


def _split_top_level(value: str) -> list[str]:
    """按不在括号内的逗号切分多层阴影。"""

    parts: list[str] = []
    depth = 0
    start = 0
    for index, char in enumerate(value):
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
        elif char == "," and depth == 0:
            parts.append(value[start:index])
            start = index + 1
    parts.append(value[start:])
    return parts


def _group(name: str, value: Any, problems: list[str]) -> dict[str, Any]:
    """检查 Token 组是非空映射且键名为 kebab-case。"""

    if not _is_mapping(value) or not value:
        problems.append(f"{name} 必须是非空映射")
        return {}
    result: dict[str, Any] = {}
    # YAML 1.1 会把 on / yes / 100 之类的键解析成 bool 或 int，必须在运行时拒绝。
    for key, item in cast(dict[object, Any], value).items():
        if not isinstance(key, str) or not _NAME.match(key):
            problems.append(f"{name}.{key}：Token 名必须是小写 kebab-case")
            continue
        result[key] = item
    return result


def _validate_colors(raw: Any, problems: list[str]) -> dict[str, str]:
    colors: dict[str, str] = {}
    for key, value in _group("colors", raw, problems).items():
        if not isinstance(value, str) or not (_HEX.match(value) or _valid_rgba(value)):
            problems.append(f"colors.{key}：颜色必须是 #RRGGBB 或 rgba(r, g, b, a)，得到 {value!r}")
            continue
        colors[key] = value.upper() if value.startswith("#") else value
    return colors


def _valid_rgba(value: str) -> bool:
    match = _RGBA.match(value)
    return bool(match) and all(int(match.group(i)) <= 255 for i in (1, 2, 3))


def _validate_typography(raw: Any, problems: list[str]) -> dict[str, Typography]:
    allowed = {"fontFamily", "fontSize", "fontWeight", "lineHeight", "letterSpacing", "fontFeature"}
    result: dict[str, Typography] = {}

    for key, spec in _group("typography", raw, problems).items():
        where = f"typography.{key}"
        if not _is_mapping(spec):
            problems.append(f"{where} 必须是映射")
            continue

        local: list[str] = []
        for extra in sorted(set(spec) - allowed):
            local.append(f"{where}：未知字段 {extra}")

        family = _field(spec, "fontFamily")
        size = _field(spec, "fontSize")
        weight = _field(spec, "fontWeight")
        line_height = _field(spec, "lineHeight")
        spacing = _field(spec, "letterSpacing")
        feature = _field(spec, "fontFeature")

        if not isinstance(family, str) or not family.strip():
            local.append(f"{where}.fontFamily 必须是非空字符串")
        if not isinstance(size, str) or not re.match(r"^\d+(?:\.\d+)?px$", size):
            local.append(f"{where}.fontSize 必须是 px 值")
        if not _is_int(weight) or not (100 <= weight <= 900 and weight % 100 == 0):
            local.append(f"{where}.fontWeight 必须是 100–900 的整百")
        if not _is_number(line_height) or not (0.8 <= float(line_height) <= 3):
            local.append(f"{where}.lineHeight 必须是 0.8–3 之间的数字")
        if spacing is not None and (not isinstance(spacing, str) or not _EM.match(spacing)):
            local.append(f"{where}.letterSpacing 必须是 em 值")
        if feature is not None and (not isinstance(feature, str) or not feature.strip()):
            local.append(f"{where}.fontFeature 必须是非空字符串")

        if local:
            problems.extend(local)
            continue
        result[key] = Typography(family, size, weight, float(line_height), spacing, feature)
    return result


def _validate_dimensions(name: str, raw: Any, problems: list[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for key, value in _group(name, raw, problems).items():
        if not isinstance(value, str) or not _PX.match(value):
            problems.append(f"{name}.{key}：必须是 px 值，得到 {value!r}")
            continue
        result[key] = value
    return result


def _validate_motion(raw: Any, problems: list[str]) -> tuple[dict[str, MotionToken], float, int]:
    result: dict[str, MotionToken] = {}
    stagger = 0.0
    stagger_max = 1

    for key, spec in _group("motion", raw, problems).items():
        where = f"motion.{key}"

        if key in MOTION_SCALARS:
            if key == "stagger":
                if not _is_number(spec) or not (0 < float(spec) <= 0.1):
                    problems.append(f"{where} 必须是 0–0.1 秒之间的数字")
                else:
                    stagger = float(spec)
            elif not _is_int(spec) or spec < 1:
                problems.append(f"{where} 必须是正整数")
            else:
                stagger_max = spec
            continue

        if not _is_mapping(spec):
            problems.append(f"{where} 必须是映射，或属于 {sorted(MOTION_SCALARS)}")
            continue

        kind = _field(spec, "type")
        if kind == "spring":
            token = _validate_spring(where, spec, problems)
        elif kind == "tween":
            token = _validate_tween(where, spec, problems)
        elif kind == "hold":
            token = _validate_hold(where, spec, problems)
        elif kind == "loop":
            token = _validate_loop(where, spec, problems)
        else:
            problems.append(f"{where}.type 必须是 spring、tween、hold 或 loop")
            continue
        if token is not None:
            result[key] = token

    for scalar in MOTION_SCALARS:
        if _is_mapping(raw) and scalar not in raw:
            problems.append(f"缺少 motion.{scalar}")
    return result, stagger, stagger_max


def _validate_spring(where: str, spec: Mapping[str, Any], problems: list[str]) -> Spring | None:
    extra = set(spec) - {"type", "visualDuration", "bounce"}
    visual = _field(spec, "visualDuration")
    bounce = _field(spec, "bounce")
    local: list[str] = [f"{where}：未知字段 {e}" for e in sorted(extra)]

    if not _is_number(visual) or not (0 < float(visual) <= 1):
        local.append(f"{where}.visualDuration 必须是 0–1 秒之间的数字")
    if not _is_number(bounce) or not (0 <= float(bounce) <= MAX_BOUNCE):
        # 回弹上限是规范硬约束，不允许局部突破。
        local.append(f"{where}.bounce 必须在 0–{MAX_BOUNCE} 之间")

    if local:
        problems.extend(local)
        return None
    return build_spring(float(visual), float(bounce))


def _validate_tween(where: str, spec: Mapping[str, Any], problems: list[str]) -> Tween | None:
    extra = set(spec) - {"type", "duration", "ease"}
    duration = _field(spec, "duration")
    ease = _field(spec, "ease")
    local: list[str] = [f"{where}：未知字段 {e}" for e in sorted(extra)]

    if not _is_number(duration) or not (0 < float(duration) <= MAX_TWEEN_SECONDS):
        # 固定时长只服务颜色变化；位移必须使用弹簧。
        local.append(f"{where}.duration 必须在 0–{MAX_TWEEN_SECONDS} 秒之间（tween 只用于颜色）")
    if ease not in TWEEN_EASINGS:
        local.append(f"{where}.ease 必须是 {', '.join(TWEEN_EASINGS)} 之一")

    if local:
        problems.extend(local)
        return None
    return Tween(float(duration), str(ease))


def _validate_hold(where: str, spec: Mapping[str, Any], problems: list[str]) -> Hold | None:
    extra = set(spec) - {"type", "duration"}
    duration = _field(spec, "duration")
    local: list[str] = [f"{where}：未知字段 {e}" for e in sorted(extra)]

    if not _is_number(duration) or not (0 < float(duration) <= MAX_HOLD_SECONDS):
        local.append(f"{where}.duration 必须在 0–{MAX_HOLD_SECONDS} 秒之间")

    if local:
        problems.extend(local)
        return None
    return Hold(float(duration))


def _validate_loop(where: str, spec: Mapping[str, Any], problems: list[str]) -> Loop | None:
    extra = set(spec) - {"type", "duration", "scale"}
    duration = _field(spec, "duration")
    scale = _field(spec, "scale")
    local: list[str] = [f"{where}：未知字段 {e}" for e in sorted(extra)]

    # 循环必须“低幅”：太快像报警，幅度太大像在表演。
    if not _is_number(duration) or not (MIN_LOOP_SECONDS <= float(duration) <= MAX_LOOP_SECONDS):
        local.append(f"{where}.duration 必须在 {MIN_LOOP_SECONDS}–{MAX_LOOP_SECONDS} 秒之间")
    if not _is_number(scale) or not (1 < float(scale) <= MAX_LOOP_SCALE):
        local.append(f"{where}.scale 必须大于 1 且不超过 {MAX_LOOP_SCALE}")

    if local:
        problems.extend(local)
        return None
    return Loop(float(duration), float(scale))


# 组件属性：CSS 后缀、允许引用的组、是否允许 px 裸值、允许的关键字。
_COMPONENT_PROPS: dict[str, tuple[str, frozenset[str], bool, frozenset[str]]] = {
    "backgroundColor": ("background", frozenset({"colors"}), False, frozenset({"transparent"})),
    "textColor": ("color", frozenset({"colors"}), False, frozenset()),
    "outline": ("outline", frozenset({"colors"}), False, frozenset()),
    "typography": ("font", frozenset({"typography"}), False, frozenset()),
    "rounded": ("radius", frozenset({"rounded"}), False, frozenset()),
    "padding": ("padding", frozenset({"spacing"}), True, frozenset()),
    "height": ("height", frozenset({"spacing"}), True, frozenset()),
    "size": ("size", frozenset({"spacing"}), True, frozenset()),
}


def _validate_components(
    raw: Any, groups: Mapping[str, Mapping[str, Any]], problems: list[str]
) -> dict[str, tuple[ComponentProperty, ...]]:
    result: dict[str, tuple[ComponentProperty, ...]] = {}

    for name, spec in _group("components", raw, problems).items():
        where = f"components.{name}"
        if not _is_mapping(spec) or not spec:
            problems.append(f"{where} 必须是非空映射")
            continue

        props: list[ComponentProperty] = []
        for prop, value in spec.items():
            rule = _COMPONENT_PROPS.get(prop)
            if rule is None:
                problems.append(f"{where}：未知属性 {prop}（允许 {', '.join(_COMPONENT_PROPS)}）")
                continue
            parsed = _component_value(f"{where}.{prop}", value, rule, groups, problems)
            if parsed is not None:
                props.append(ComponentProperty(rule[0], *parsed))
        result[name] = tuple(props)
    return result


def _component_value(
    where: str,
    value: Any,
    rule: tuple[str, frozenset[str], bool, frozenset[str]],
    groups: Mapping[str, Mapping[str, Any]],
    problems: list[str],
) -> tuple[str, str] | None:
    """返回 ``(css, resolved)``；颜色、字体、圆角必须是引用，这就是“禁止裸值”。"""

    _, allowed_groups, allow_px, keywords = rule
    if not isinstance(value, str) or not value.strip():
        problems.append(f"{where} 必须是非空字符串")
        return None
    if value in keywords:
        return value, value

    parts = value.split()
    if not allow_px and len(parts) != 1:
        problems.append(f"{where} 必须是单个 Token 引用")
        return None

    css_parts: list[str] = []
    resolved_parts: list[str] = []
    ok = True
    for part in parts:
        ref = _FULL_REF.match(part)
        if ref:
            group, key = ref.groups()
            if group not in allowed_groups:
                problems.append(
                    f"{where}：不能引用 {group}，只允许 {', '.join(sorted(allowed_groups))}"
                )
                ok = False
            elif key not in groups.get(group, {}):
                problems.append(f"{where}：引用的 {{{group}.{key}}} 不存在")
                ok = False
            else:
                css_parts.append(f"var(--{CSS_PREFIX}-{REFERENCE_GROUPS[group]}-{key})")
                target = groups[group][key]
                resolved_parts.append(target.font if isinstance(target, Typography) else target)
        elif allow_px and _PX.match(part):
            css_parts.append(part)
            resolved_parts.append(part)
        else:
            kind = "Token 引用或 px 值" if allow_px else "Token 引用（禁止裸值）"
            problems.append(f"{where}：{part!r} 不是合法的{kind}")
            ok = False

    if not ok:
        return None
    return " ".join(css_parts), " ".join(resolved_parts)


def _validate_contrast(
    raw: Any, colors: Mapping[str, str], components: Any, problems: list[str]
) -> None:
    """文本对比度检查。

    规则来源：

    1. ``on-X`` 与 ``X`` 天然是“文字 / 背景”配对；
    2. 组件同时声明 ``backgroundColor`` 与 ``textColor`` 时，它们必须可读；
    3. ``contrast.text`` × ``contrast.backgrounds`` 矩阵中的每一组。
    """

    if not _is_mapping(raw):
        problems.append("contrast 必须是映射")
        return
    extra = set(raw) - {"minimum", "text", "backgrounds"}
    if extra:
        problems.append(f"contrast：未知字段 {', '.join(sorted(extra))}")

    minimum = _field(raw, "minimum")
    text = _field(raw, "text")
    backgrounds = _field(raw, "backgrounds")
    if not _is_number(minimum) or float(minimum) < 4.5:
        problems.append("contrast.minimum 必须是数字且不低于 WCAG AA 的 4.5")
        return
    if not _is_str_list(text) or not _is_str_list(backgrounds):
        problems.append("contrast.text 与 contrast.backgrounds 必须是颜色名列表")
        return

    pairs: list[tuple[str, str, str]] = []
    for key in colors:
        if key.startswith("on-") and key[3:] in colors:
            pairs.append((key, key[3:], f"on-* 配对 {key}/{key[3:]}"))

    if _is_mapping(components):
        for name, spec in components.items():
            if not _is_mapping(spec):
                continue
            fg = _bare_color_ref(_field(spec, "textColor"))
            bg = _bare_color_ref(_field(spec, "backgroundColor"))
            if fg and bg:
                pairs.append((fg, bg, f"组件 {name}"))

    for fg in text:
        for bg in backgrounds:
            pairs.append((fg, bg, "contrast 矩阵"))

    for fg, bg, source in pairs:
        if fg not in colors or bg not in colors:
            problems.append(f"{source}：颜色 {fg} 或 {bg} 不存在")
            continue
        fg_rgb, bg_rgb = _hex_rgb(colors[fg]), _hex_rgb(colors[bg])
        if fg_rgb is None or bg_rgb is None:
            problems.append(f"{source}：{fg}/{bg} 必须是不透明 #RRGGBB 才能计算对比度")
            continue
        ratio = contrast_ratio(fg_rgb, bg_rgb)
        if ratio < float(minimum):
            problems.append(
                f"{source}：{fg} {colors[fg]} 在 {bg} {colors[bg]} 上的对比度 "
                f"{ratio:.2f} 低于 {minimum}"
            )


def _bare_color_ref(value: Any) -> str | None:
    if isinstance(value, str):
        match = _FULL_REF.match(value)
        if match and match.group(1) == "colors":
            return match.group(2)
    return None


# ---------------------------------------------------------------------------
# 计算
# ---------------------------------------------------------------------------


def spring_physics(visual_duration: float, bounce: float) -> tuple[float, float]:
    """返回 ``(stiffness, damping)``，质量为 1。

    与 Motion 的推导保持一致：``root = 2π / (visualDuration × 1.2)``，
    ``stiffness = root²``，``damping = 2 × clamp(0.05, 1, 1 − bounce) × √stiffness``。
    这样 CSS 回退曲线与 JS 弹簧是同一个物理模型。
    """

    root = 2 * math.pi / (visual_duration * 1.2)
    stiffness = root * root
    damping = 2 * min(1.0, max(0.05, 1 - bounce)) * math.sqrt(stiffness)
    return stiffness, damping


def spring_position(t: float, stiffness: float, damping: float) -> float:
    """初速度为 0、从 0 运动到 1 的阻尼弹簧在 ``t`` 秒时的位置。"""

    omega = math.sqrt(stiffness)
    zeta = damping / (2 * omega)
    if zeta >= 1 - 1e-9:
        return 1 - math.exp(-omega * t) * (1 + omega * t)
    damped = omega * math.sqrt(1 - zeta * zeta)
    envelope = math.exp(-zeta * omega * t)
    return 1 - envelope * (math.cos(damped * t) + zeta * omega / damped * math.sin(damped * t))


def build_spring(visual_duration: float, bounce: float) -> Spring:
    """计算弹簧的物理参数、静止时长与 CSS ``linear()`` 采样点。"""

    stiffness, damping = spring_physics(visual_duration, bounce)

    # 静止时长 = 最后一次偏离目标超过阈值的时刻；按 1ms 步进保证确定性。
    last_moving = 0
    for ms in range(SPRING_MAX_MS + 1):
        if abs(1 - spring_position(ms / 1000, stiffness, damping)) > SPRING_REST_DELTA:
            last_moving = ms
    duration_ms = last_moving + 1

    count = max(SPRING_MIN_SAMPLES, math.ceil(duration_ms / SPRING_SAMPLE_MS)) + 1
    samples = [
        round(spring_position(duration_ms * i / (count - 1) / 1000, stiffness, damping), 4)
        for i in range(count)
    ]
    samples[0], samples[-1] = 0.0, 1.0
    return Spring(visual_duration, bounce, stiffness, damping, duration_ms, tuple(samples))


def contrast_ratio(a: tuple[int, int, int], b: tuple[int, int, int]) -> float:
    """WCAG 2.x 相对亮度对比度。"""

    la, lb = _luminance(a), _luminance(b)
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)


def _luminance(rgb: tuple[int, int, int]) -> float:
    channels: list[float] = []
    for value in rgb:
        c = value / 255
        channels.append(c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4)
    return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2]


def _hex_rgb(value: str) -> tuple[int, int, int] | None:
    if not _HEX.match(value):
        return None
    return int(value[1:3], 16), int(value[3:5], 16), int(value[5:7], 16)


# ---------------------------------------------------------------------------
# 渲染
# ---------------------------------------------------------------------------


def render_outputs(tokens: Tokens) -> dict[str, str]:
    """返回 ``文件名 → 内容``。输出完全确定，便于 ``--check`` 比较。"""

    return {
        "purrcept.css": render_css(tokens),
        "motion.js": render_motion_js(tokens),
        "motion.d.ts": render_motion_dts(tokens),
        "tokens.json": render_json(tokens),
    }


def render_css(tokens: Tokens) -> str:
    """生成 ``:root`` 级 CSS 变量，以及减少动效时的覆盖。"""

    p = CSS_PREFIX
    out = [f"/* {GENERATED_NOTE} */", f"/* {tokens.name} {tokens.version} */", "", ":root {"]

    def section(title: str) -> None:
        if out[-1] != ":root {":
            out.append("")
        out.append(f"  /* {title} */")

    section("colors")
    for key, value in tokens.colors.items():
        out.append(f"  --{p}-color-{key}: {value};")

    section("typography")
    for key, t in tokens.typography.items():
        out.append(f"  --{p}-font-{key}: {t.font};")
        out.append(f"  --{p}-font-{key}-letter-spacing: {t.letter_spacing or 'normal'};")
        if t.feature_settings:
            out.append(f"  --{p}-font-{key}-feature-settings: {t.feature_settings};")

    section("rounded")
    for key, value in tokens.rounded.items():
        out.append(f"  --{p}-radius-{key}: {value};")

    section("spacing")
    for key, value in tokens.spacing.items():
        out.append(f"  --{p}-space-{key}: {value};")

    section("elevation：外阴影只用墨色，inset 只用墨色或纯白受光边")
    for key, value in tokens.elevation.items():
        out.append(f"  --{p}-shadow-{key}: {value};")

    section("gradients：只给背景美术")
    for key, gradient in tokens.gradients.items():
        out.append(f"  --{p}-gradient-{key}: {gradient.css};")

    section("materials：只给导航轨与浮层")
    for key, material in tokens.materials.items():
        out.append(f"  --{p}-material-{key}-background: {material.tint};")
        out.append(f"  --{p}-material-{key}-filter: {material.filter};")

    section("motion：弹簧的 CSS 回退不可打断，可打断的位移请使用 motion.js")
    for key, m in tokens.motion.items():
        if isinstance(m, Spring):
            out.append(f"  --{p}-motion-{key}-duration: {m.duration_ms}ms;")
            out.append(f"  --{p}-motion-{key}-easing: {_css_linear(m.samples)};")
        elif isinstance(m, Tween):
            out.append(f"  --{p}-motion-{key}-duration: {_ms(m.duration)};")
            out.append(f"  --{p}-motion-{key}-easing: {TWEEN_EASINGS[m.ease]};")
        elif isinstance(m, Loop):
            out.append(f"  --{p}-motion-{key}-duration: {_ms(m.duration)};")
            out.append(f"  --{p}-motion-{key}-scale: {_number(m.scale)};")
        else:
            out.append(f"  --{p}-motion-{key}-duration: {_ms(m.duration)};")
    out.append(f"  --{p}-motion-stagger: {_ms(tokens.stagger)};")
    out.append(f"  --{p}-motion-stagger-max-items: {tokens.stagger_max_items};")

    section("components")
    for name, props in tokens.components.items():
        for prop in props:
            out.append(f"  --{p}-{name}-{prop.name}: {prop.css};")

    out.append("}")

    # 减少动效：位移瞬切，颜色与形状信号保留，因此只清零弹簧与顿帧。
    reduced = [
        f"    --{p}-motion-{key}-duration: 0ms;"
        for key, m in tokens.motion.items()
        if not isinstance(m, Tween)
    ]
    out += ["", "@media (prefers-reduced-motion: reduce) {", "  :root {", *reduced]
    out += [f"    --{p}-motion-stagger: 0ms;", "  }", "}", ""]
    return "\n".join(out)


def render_motion_js(tokens: Tokens) -> str:
    """生成 Motion 预设模块，可直接作为 ``animate()`` 的 transition 参数。"""

    lines = [
        f"// {GENERATED_NOTE}",
        f"// {tokens.name} {tokens.version}",
        "//",
        "// 用法：animate(element, { x: 0 }, motion.move)",
        "// 弹簧保持 Motion 原生的 visualDuration/bounce 形式，中途打断时会继承当前速度。",
        "",
        "export const motion = Object.freeze({",
    ]
    for key, m in tokens.motion.items():
        if isinstance(m, Spring):
            body = (
                f'type: "spring", visualDuration: {_number(m.visual_duration)}, '
                f"bounce: {_number(m.bounce)}"
            )
        elif isinstance(m, Tween):
            body = f'type: "tween", duration: {_number(m.duration)}, ease: "{m.ease}"'
        else:
            continue
        lines.append(f"  {_js_key(key)}: Object.freeze({{ {body} }}),")
    lines.append("});")

    lines += [
        "",
        "/** 顿帧等停顿时长（秒），用作 delay。 */",
        "export const holds = Object.freeze({",
    ]
    for key, m in tokens.motion.items():
        if isinstance(m, Hold):
            lines.append(f"  {_js_key(key)}: {_number(m.duration)},")
    lines.append("});")

    lines += [
        "",
        "/** 低幅循环：duration 为周期（秒），scale 为峰值缩放。只给“运行中”使用。 */",
        "export const loops = Object.freeze({",
    ]
    for key, m in tokens.motion.items():
        if isinstance(m, Loop):
            lines.append(
                f"  {_js_key(key)}: Object.freeze({{ duration: {_number(m.duration)}, "
                f"scale: {_number(m.scale)} }}),"
            )
    lines.append("});")

    lines += [
        "",
        "/** 列表编排：每项间隔（秒）与参与错峰的最大项数。 */",
        "export const stagger = Object.freeze({ "
        f"each: {_number(tokens.stagger)}, maxItems: {tokens.stagger_max_items} }});",
        "",
        "/** 第 index 项的入场延迟；超过 maxItems 的项与最后一项同时出现。 */",
        "export function staggerDelay(index) {",
        "  const position = Math.max(0, Math.min(index, stagger.maxItems - 1));",
        "  return position * stagger.each;",
        "}",
        "",
        "/** 减少动效时用于位移的瞬切过渡。 */",
        'export const instant = Object.freeze({ type: "tween", duration: 0 });',
        "",
        "/**",
        " * 取得某个动效 Token 的过渡参数。",
        " * reducedMotion 为 true 时弹簧改为瞬切；颜色过渡保留，因为它承担状态信号。",
        " */",
        "export function transition(name, reducedMotion = false) {",
        "  const token = motion[name];",
        "  if (token === undefined) {",
        "    throw new Error(`Unknown motion token: ${name}`);",
        "  }",
        '  return reducedMotion && token.type === "spring" ? instant : token;',
        "}",
        "",
    ]
    return "\n".join(lines)


def render_motion_dts(tokens: Tokens) -> str:
    """生成 ``motion.js`` 的类型声明。"""

    springs = [k for k, m in tokens.motion.items() if isinstance(m, Spring)]
    tweens = [k for k, m in tokens.motion.items() if isinstance(m, Tween)]
    holds = [k for k, m in tokens.motion.items() if isinstance(m, Hold)]
    loops = [k for k, m in tokens.motion.items() if isinstance(m, Loop)]

    lines = [
        f"// {GENERATED_NOTE}",
        "",
        "export interface SpringTransition {",
        '  readonly type: "spring";',
        "  readonly visualDuration: number;",
        "  readonly bounce: number;",
        "}",
        "",
        "export interface TweenTransition {",
        '  readonly type: "tween";',
        "  readonly duration: number;",
        f"  readonly ease?: {' | '.join(json.dumps(e) for e in TWEEN_EASINGS)};",
        "}",
        "",
        "export declare const motion: {",
        *[f"  readonly {_js_key(k)}: SpringTransition;" for k in springs],
        *[f"  readonly {_js_key(k)}: TweenTransition;" for k in tweens],
        "};",
        "",
        "export type MotionToken = keyof typeof motion;",
        "",
        "export declare const holds: {",
        *[f"  readonly {_js_key(k)}: number;" for k in holds],
        "};",
        "",
        "/** 低幅循环：duration 为周期（秒），scale 为峰值缩放。 */",
        "export declare const loops: {",
        *[
            f"  readonly {_js_key(k)}: {{ readonly duration: number; readonly scale: number }};"
            for k in loops
        ],
        "};",
        "",
        "export declare const stagger: { readonly each: number; readonly maxItems: number };",
        "",
        "export declare function staggerDelay(index: number): number;",
        "",
        "export declare const instant: TweenTransition;",
        "",
        "export declare function transition(",
        "  name: MotionToken,",
        "  reducedMotion?: boolean,",
        "): SpringTransition | TweenTransition;",
        "",
    ]
    return "\n".join(lines)


def render_json(tokens: Tokens) -> str:
    """生成完全解析后的 Token，供非 CSS/JS 工具（设计工具、截图测试）使用。"""

    motion: dict[str, Any] = {}
    for key, m in tokens.motion.items():
        if isinstance(m, Spring):
            motion[key] = {
                "type": "spring",
                "visualDuration": m.visual_duration,
                "bounce": m.bounce,
                "stiffness": round(m.stiffness, 4),
                "damping": round(m.damping, 4),
                "mass": 1,
                "settleMs": m.duration_ms,
            }
        elif isinstance(m, Tween):
            motion[key] = {"type": "tween", "duration": m.duration, "ease": m.ease}
        elif isinstance(m, Loop):
            motion[key] = {"type": "loop", "duration": m.duration, "scale": m.scale}
        else:
            motion[key] = {"type": "hold", "duration": m.duration}
    motion["stagger"] = tokens.stagger
    motion["stagger-max-items"] = tokens.stagger_max_items

    document = {
        "name": tokens.name,
        "version": tokens.version,
        "colors": dict(tokens.colors),
        "typography": {
            key: {
                "font": t.font,
                "fontFamily": t.family,
                "fontSize": t.size,
                "fontWeight": t.weight,
                "lineHeight": t.line_height,
                "letterSpacing": t.letter_spacing,
                "fontFeature": t.feature_settings,
            }
            for key, t in tokens.typography.items()
        },
        "rounded": dict(tokens.rounded),
        "spacing": dict(tokens.spacing),
        "elevation": dict(tokens.elevation),
        "gradients": {key: g.resolved for key, g in tokens.gradients.items()},
        "materials": {
            key: {"background": m.tint_resolved, "backdropFilter": m.filter}
            for key, m in tokens.materials.items()
        },
        "motion": motion,
        "components": {
            name: {prop.name: prop.resolved for prop in props}
            for name, props in tokens.components.items()
        },
    }
    return json.dumps(document, ensure_ascii=False, indent=2) + "\n"


def _css_linear(samples: Sequence[float]) -> str:
    return "linear(" + ", ".join(_number(v) for v in samples) + ")"


def _ms(seconds: float) -> str:
    return f"{round(seconds * 1000)}ms"


def _number(value: float) -> str:
    """稳定、紧凑的数字格式：去掉多余的 0，且不产生 ``-0``。"""

    text = f"{value:.4f}".rstrip("0").rstrip(".")
    return "0" if text in {"-0", ""} else text


def _js_key(key: str) -> str:
    return key if re.match(r"^[A-Za-z_$][A-Za-z0-9_$]*$", key) else json.dumps(key)


def _is_number(value: object) -> TypeGuard[int | float]:
    return isinstance(value, int | float) and not isinstance(value, bool) and math.isfinite(value)


def _is_int(value: object) -> TypeGuard[int]:
    return isinstance(value, int) and not isinstance(value, bool)


def _is_str_list(value: object) -> TypeGuard[list[str]]:
    return isinstance(value, list) and all(isinstance(v, str) for v in cast(list[object], value))


def _is_mapping(value: object) -> TypeGuard[dict[str, Any]]:
    """YAML 映射的类型收窄；键是否为字符串由各组的命名校验负责。"""

    return isinstance(value, dict)


def _field(spec: Mapping[str, Any], key: str) -> Any:
    """读取 YAML 字段；返回 Any，由调用方立即做显式类型校验。"""

    return spec.get(key)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def write_outputs(outputs: Mapping[str, str], out_dir: Path) -> None:
    """以 LF 换行写入产物，保证跨平台字节一致。"""

    out_dir.mkdir(parents=True, exist_ok=True)
    for name, content in outputs.items():
        (out_dir / name).write_text(content, encoding="utf-8", newline="\n")


def stale_outputs(outputs: Mapping[str, str], out_dir: Path) -> list[str]:
    """返回与规范不一致（缺失或内容不同）的产物文件名。

    读取时统一换行，避免 Git 在 Windows 上的 CRLF 转换造成误报。
    """

    stale: list[str] = []
    for name, content in outputs.items():
        path = out_dir / name
        if not path.is_file() or path.read_text(encoding="utf-8") != content:
            stale.append(name)
    return stale


def main(argv: Sequence[str] | None = None) -> int:
    # Windows 控制台默认代码页不是 UTF-8，中文诊断会乱码。
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            reconfigure(encoding="utf-8")

    parser = argparse.ArgumentParser(description="从 DESIGN.md 导出 Purrcept Cel 设计 Token。")
    parser.add_argument("--design", type=Path, default=DEFAULT_DESIGN, help="DESIGN.md 路径")
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT, help="输出目录")
    parser.add_argument("--check", action="store_true", help="只检查产物是否最新，不写入")
    args = parser.parse_args(argv)

    try:
        tokens = load_tokens(args.design)
    except TokenError as exc:
        print(f"Token 校验失败（{len(exc.problems)} 项）：\n{exc}", file=sys.stderr)
        return 1

    outputs = render_outputs(tokens)

    if args.check:
        stale = stale_outputs(outputs, args.out)
        if stale:
            print(
                f"以下产物与 DESIGN.md 不一致：{', '.join(stale)}\n"
                "请运行 uv run python scripts/export_tokens.py",
                file=sys.stderr,
            )
            return 1
        print(f"Token 产物已是最新（{len(outputs)} 个文件）。")
        return 0

    write_outputs(outputs, args.out)
    print(f"已导出 {len(outputs)} 个文件到 {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
