/**
 * Purrcept Cel 语义模型：状态、反馈维度与风险等级。
 *
 * 职责：把 DESIGN.md 的 Semantics 章节翻译成类型与只读表，所有组件只从这里取状态的色彩
 * 家族、形状、文案与节拍，不各自发明。
 *
 * 不负责：不渲染任何东西；不决定组件放在哪里（反馈出现在受影响对象上由调用方保证）。
 */

/** Agent / 对象的状态集合，与 CognitiveRuntime 的主体行为对齐。 */
export type AgentState =
  | "idle"
  | "perceiving"
  | "reasoning"
  | "acting"
  | "waiting-external"
  | "waiting-user"
  | "warning"
  | "paused"
  | "completed"
  | "failed";

/** 五个语义色彩家族加中性。语义色只表达状态。 */
export type Family = "neutral" | "active" | "waiting" | "paused" | "success" | "failed";

/** 状态的形状信号：颜色之外的第二通道。 */
export type Shape =
  | "ring"
  | "dot"
  | "clock"
  | "person"
  | "triangle"
  | "pause"
  | "check"
  | "cross";

/**
 * 进入状态时的节拍。
 *
 * - ``still``：静止（等待用户时，静止本身就是信号）；
 * - ``loop``：全系统唯一允许的低幅循环；
 * - ``settle``：完成时的收束回弹；
 * - ``hit``：失败时的顿帧，硬停不摇晃；
 * - ``decelerate``：暂停时循环减速到停。
 */
export type Beat = "still" | "loop" | "settle" | "hit" | "decelerate";

/** 单个状态的完整语义描述。 */
export interface StateSpec {
  readonly family: Family;
  readonly shape: Shape;
  readonly label: string;
  readonly beat: Beat;
}

/** 状态表。状态文案全产品统一，不在相同语义间混用近义词。 */
export const STATES: Readonly<Record<AgentState, StateSpec>> = Object.freeze({
  idle: { family: "neutral", shape: "ring", label: "空闲", beat: "still" },
  perceiving: { family: "active", shape: "dot", label: "感知中", beat: "loop" },
  reasoning: { family: "active", shape: "dot", label: "思考中", beat: "loop" },
  acting: { family: "active", shape: "dot", label: "运行中", beat: "loop" },
  "waiting-external": { family: "waiting", shape: "clock", label: "等待中", beat: "still" },
  "waiting-user": { family: "waiting", shape: "person", label: "等你确认", beat: "still" },
  warning: { family: "waiting", shape: "triangle", label: "注意", beat: "still" },
  paused: { family: "paused", shape: "pause", label: "已暂停", beat: "decelerate" },
  completed: { family: "success", shape: "check", label: "已完成", beat: "settle" },
  failed: { family: "failed", shape: "cross", label: "失败", beat: "hit" },
});

/** 判断状态是否代表“仍在进行或需要关注”，用于确定行动路径的当前节点。 */
export function isLive(state: AgentState): boolean {
  const family = STATES[state].family;
  return family === "active" || family === "waiting" || family === "paused" || family === "failed";
}

// ---------------------------------------------------------------------------
// 反馈维度：呈现 = f(状态, 作用范围, 紧迫度, 持续性)
// ---------------------------------------------------------------------------

/** 反馈作用范围。氛围色面积必须等于范围。 */
export type Scope = "control" | "object" | "region" | "page" | "system";

/** 紧迫度。``blocking`` 只能通过 Dialog 表达，因此不出现在 Feedback 的类型里。 */
export type Urgency = "passive" | "actionable" | "blocking";

/** 持续性。``until-resolved`` 的反馈不可被关闭。 */
export type Persistence = "transient" | "retained" | "until-resolved";

/** 反馈应呈现在哪种表面上。 */
export type FeedbackSurface = "inline" | "banner" | "dialog";

/**
 * 根据反馈维度推导呈现表面。
 *
 * 只有 ``blocking`` 允许打断；页面与系统级反馈是横幅；其余都附着在受影响对象上。
 */
export function feedbackSurface(scope: Scope, urgency: Urgency): FeedbackSurface {
  if (urgency === "blocking") {
    return "dialog";
  }
  return scope === "page" || scope === "system" ? "banner" : "inline";
}

// ---------------------------------------------------------------------------
// 风险等级：从 Runtime Capability 的 EffectKind 推导
// ---------------------------------------------------------------------------

/** 与 purrcept_runtime ``EffectKind`` 保持一致的副作用种类。 */
export type EffectKind =
  | "pure"
  | "world_read"
  | "world_write"
  | "external_read"
  | "external_write"
  | "irreversible";

/** 风险等级。 */
export type Risk = "R0" | "R1" | "R2" | "R3";

/** 风险等级的展示语义。 */
export interface RiskSpec {
  readonly label: string;
  readonly family: Family;
  readonly reversible: boolean;
}

export const RISKS: Readonly<Record<Risk, RiskSpec>> = Object.freeze({
  R0: { label: "观察", family: "neutral", reversible: true },
  R1: { label: "世界内写入", family: "neutral", reversible: true },
  R2: { label: "对外写入", family: "waiting", reversible: true },
  R3: { label: "不可逆", family: "failed", reversible: false },
});

/** 由副作用种类推导风险等级；UI 不得自行提高或降低。 */
export function riskOf(effect: EffectKind): Risk {
  switch (effect) {
    case "pure":
    case "world_read":
    case "external_read":
      return "R0";
    case "world_write":
      return "R1";
    case "external_write":
      return "R2";
    case "irreversible":
      return "R3";
  }
}

// ---------------------------------------------------------------------------
// 部分失败：不伪装回滚
// ---------------------------------------------------------------------------

/** 一次 Action 中单个副作用的结局，来自 ``committed_effects`` 与调用轨迹。 */
export type EffectOutcome = "committed" | "skipped" | "unknown";

export const EFFECT_OUTCOMES: Readonly<
  Record<EffectOutcome, { readonly label: string; readonly family: Family }>
> = Object.freeze({
  committed: { label: "已经发生", family: "success" },
  skipped: { label: "没有发生", family: "neutral" },
  unknown: { label: "结果未知", family: "waiting" },
});
