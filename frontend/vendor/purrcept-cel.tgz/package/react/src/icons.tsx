/**
 * 状态、动作与导航图标：统一 1.75px 线性图标。
 *
 * 职责：为每个形状信号和每个导航目的地提供唯一图标，保证同一语义全产品只用一个图标。
 * 状态图标（ring、check、cross、pause、clock、person、triangle、question）只表达状态，
 * 不得用于导航；导航图标（home、inbox、timeline、device、activity、settings）只表达目的地；
 * 动作图标 chevron 只表示“进入下一层”，跟在区域标题或可进入的行之后。
 * 不负责：不决定颜色；图标使用 ``currentColor``，颜色由父级的色彩家族决定。
 */

import type { ReactElement } from "react";

export type IconName =
  | "ring"
  | "check"
  | "cross"
  | "pause"
  | "clock"
  | "person"
  | "triangle"
  | "question"
  | "close"
  | "home"
  | "inbox"
  | "timeline"
  | "device"
  | "activity"
  | "settings"
  | "chevron";

const PATHS: Record<IconName, ReactElement> = {
  ring: <circle cx="8" cy="8" r="4.5" />,
  check: <path d="M3.5 8.5 6.5 11.5 12.5 4.5" />,
  cross: <path d="M4.5 4.5 11.5 11.5M11.5 4.5 4.5 11.5" />,
  close: <path d="M4.5 4.5 11.5 11.5M11.5 4.5 4.5 11.5" />,
  pause: <path d="M6 4v8M10 4v8" />,
  clock: (
    <>
      <circle cx="8" cy="8" r="5.75" />
      <path d="M8 5v3.25l2.25 1.5" />
    </>
  ),
  person: (
    <>
      <circle cx="8" cy="5" r="2.25" />
      <path d="M3.5 13.5c.6-2.6 2.4-4 4.5-4s3.9 1.4 4.5 4" />
    </>
  ),
  triangle: (
    <>
      <path d="M8 2.5 14 13H2Z" />
      <path d="M8 6.5v3" />
      <path d="M8 11.25v.01" />
    </>
  ),
  question: (
    <>
      <path d="M6 6.25a2 2 0 1 1 2.9 1.8c-.55.3-.9.7-.9 1.3v.4" />
      <path d="M8 11.75v.01" />
    </>
  ),
  home: (
    <>
      <path d="M2.75 7.25 8 2.75l5.25 4.5" />
      <path d="M4.25 6v7.25h7.5V6" />
    </>
  ),
  inbox: (
    <>
      <path d="M2.75 9 4.5 3.25h7L13.25 9v3.75H2.75Z" />
      <path d="M2.75 9h3l.75 1.5h3L10.25 9h3" />
    </>
  ),
  timeline: (
    <>
      <path d="M4.25 3v10" />
      <path d="M7 4.25h6.25M7 8h6.25M7 11.75h4" />
    </>
  ),
  device: (
    <>
      <path d="M2.75 3.5h10.5v7H2.75Z" />
      <path d="M6 13.25h4M8 10.5v2.75" />
    </>
  ),
  activity: (
    <>
      <path d="M4 13.5V2.75" />
      <path d="M4 3.25h7.75L10 6l1.75 2.75H4" />
    </>
  ),
  settings: (
    <>
      <path d="M2.75 4.5h10.5M2.75 11.5h10.5" />
      <circle cx="10.25" cy="4.5" r="1.5" />
      <circle cx="5.75" cy="11.5" r="1.5" />
    </>
  ),
  chevron: <path d="M6.5 4 10.5 8l-4 4" />,
};

/** 线性图标。``label`` 缺省时视为装饰，对辅助技术隐藏。 */
export function Icon({ name, label }: { name: IconName; label?: string }): ReactElement {
  return (
    <svg
      className="pc-icon"
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
      role={label === undefined ? undefined : "img"}
      aria-label={label}
      aria-hidden={label === undefined ? true : undefined}
      focusable="false"
    >
      {PATHS[name]}
    </svg>
  );
}
