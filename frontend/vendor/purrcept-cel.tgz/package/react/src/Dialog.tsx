/**
 * Dialog：只用于 ``blocking`` 的阻断式浮层。
 *
 * 职责：屏幕中央以 ``arrive`` 进入、``exit`` 退出，带 scrim；标题必填；点击 scrim 不关闭，
 * 必须做出明确决定（Esc 等同于取消，由 ``onOpenChange(false)`` 通知调用方）。
 *
 * 不负责：不用于普通确认——可撤销的操作直接执行并提供撤销；不提供第二种对话框样式。
 */

import * as RadixDialog from "@radix-ui/react-dialog";
import { AnimatePresence, motion } from "motion/react";
import type { ReactElement, ReactNode } from "react";

import { noDescription } from "./internal";
import { transitions } from "./tokens";

/** Dialog 的属性。 */
export interface DialogProps {
  readonly open: boolean;
  readonly onOpenChange: (open: boolean) => void;
  /** 需要决定的事情，例如“永久删除 3 条记录？”。 */
  readonly title: ReactNode;
  /** 影响了什么。 */
  readonly description?: ReactNode;
  readonly children?: ReactNode;
  /** 决定按钮：一个推荐的下一步，加一个取消。 */
  readonly actions: ReactNode;
}

/** 阻断式对话框。 */
export function Dialog({
  open,
  onOpenChange,
  title,
  description,
  children,
  actions,
}: DialogProps): ReactElement {
  return (
    <RadixDialog.Root open={open} onOpenChange={onOpenChange}>
      <AnimatePresence>
        {open ? (
          <RadixDialog.Portal forceMount key="pc-dialog">
            <RadixDialog.Overlay forceMount asChild>
              <motion.div
                className="pc-scrim"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, transition: transitions.exit }}
                transition={transitions.arrive}
              />
            </RadixDialog.Overlay>
            <RadixDialog.Content
              forceMount
              asChild
              {...noDescription(description)}
              onPointerDownOutside={(event) => event.preventDefault()}
            >
              <motion.div
                className="pc-dialog pc-overlay-surface"
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98, transition: transitions.exit }}
                transition={transitions.arrive}
              >
                <RadixDialog.Title className="pc-dialog__title">{title}</RadixDialog.Title>
                {description === undefined ? null : (
                  <RadixDialog.Description className="pc-dialog__description">
                    {description}
                  </RadixDialog.Description>
                )}
                {children === undefined ? null : <div className="pc-dialog__body">{children}</div>}
                <div className="pc-dialog__actions">{actions}</div>
              </motion.div>
            </RadixDialog.Content>
          </RadixDialog.Portal>
        ) : null}
      </AnimatePresence>
    </RadixDialog.Root>
  );
}
