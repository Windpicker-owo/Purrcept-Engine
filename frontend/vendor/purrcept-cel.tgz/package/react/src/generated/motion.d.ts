// 由 scripts/export_tokens.py 从 DESIGN.md 生成，请勿手动修改。

export interface SpringTransition {
  readonly type: "spring";
  readonly visualDuration: number;
  readonly bounce: number;
}

export interface TweenTransition {
  readonly type: "tween";
  readonly duration: number;
  readonly ease?: "linear" | "easeIn" | "easeOut" | "easeInOut";
}

export declare const motion: {
  readonly snap: SpringTransition;
  readonly move: SpringTransition;
  readonly arrive: SpringTransition;
  readonly settle: SpringTransition;
  readonly exit: SpringTransition;
  readonly color: TweenTransition;
};

export type MotionToken = keyof typeof motion;

export declare const holds: {
  readonly hit: number;
};

/** 低幅循环：duration 为周期（秒），scale 为峰值缩放。 */
export declare const loops: {
  readonly pulse: { readonly duration: number; readonly scale: number };
};

export declare const stagger: { readonly each: number; readonly maxItems: number };

export declare function staggerDelay(index: number): number;

export declare const instant: TweenTransition;

export declare function transition(
  name: MotionToken,
  reducedMotion?: boolean,
): SpringTransition | TweenTransition;
