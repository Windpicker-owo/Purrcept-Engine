// 由 scripts/export_tokens.py 从 DESIGN.md 生成，请勿手动修改。
// Purrcept Cel 0.4.0
//
// 用法：animate(element, { x: 0 }, motion.move)
// 弹簧保持 Motion 原生的 visualDuration/bounce 形式，中途打断时会继承当前速度。

export const motion = Object.freeze({
  snap: Object.freeze({ type: "spring", visualDuration: 0.18, bounce: 0.06 }),
  move: Object.freeze({ type: "spring", visualDuration: 0.3, bounce: 0.04 }),
  arrive: Object.freeze({ type: "spring", visualDuration: 0.36, bounce: 0.14 }),
  settle: Object.freeze({ type: "spring", visualDuration: 0.44, bounce: 0.18 }),
  exit: Object.freeze({ type: "spring", visualDuration: 0.2, bounce: 0 }),
  color: Object.freeze({ type: "tween", duration: 0.1, ease: "linear" }),
});

/** 顿帧等停顿时长（秒），用作 delay。 */
export const holds = Object.freeze({
  hit: 0.08,
});

/** 低幅循环：duration 为周期（秒），scale 为峰值缩放。只给“运行中”使用。 */
export const loops = Object.freeze({
  pulse: Object.freeze({ duration: 1.6, scale: 1.25 }),
});

/** 感知阈值（秒）：反馈延迟出现与最短停留，用于防闪。减少动效时不变。 */
export const thresholds = Object.freeze({
  defer: 0.3,
  linger: 0.4,
});

/** 越界阻尼：可直接作为 Motion 的 dragElastic（0 为硬停，1 为 1:1）。 */
export const elastic = Object.freeze({
  resist: 0.08,
});

/** 列表编排：每项间隔（秒）与参与错峰的最大项数。 */
export const stagger = Object.freeze({ each: 0.03, maxItems: 6 });

/** 第 index 项的入场延迟；超过 maxItems 的项与最后一项同时出现。 */
export function staggerDelay(index) {
  const position = Math.max(0, Math.min(index, stagger.maxItems - 1));
  return position * stagger.each;
}

/** 减少动效时用于位移的瞬切过渡。 */
export const instant = Object.freeze({ type: "tween", duration: 0 });

/**
 * 取得某个动效 Token 的过渡参数。
 * reducedMotion 为 true 时弹簧改为瞬切；颜色过渡保留，因为它承担状态信号。
 */
export function transition(name, reducedMotion = false) {
  const token = motion[name];
  if (token === undefined) {
    throw new Error(`Unknown motion token: ${name}`);
  }
  return reducedMotion && token.type === "spring" ? instant : token;
}
