// 由 scripts/export_tokens.py 从 DESIGN.md 生成，请勿手动修改。
/** 布局能力阈值；应用把它交给 matchMedia，不自行复制数值。 */
export const breakpoints = Object.freeze({"navigation": "(max-width: 768px)", "inspector": "(max-width: 1152px)", "workspace": "(max-width: 960px)"});
/** 构建时解析 @media (--pc-名称)；未知名称拒绝构建，不静默丢失响应式规则。 */
export function breakpointMedia() {
  return { postcssPlugin: 'purrcept-breakpoints', AtRule(rule) {
    if (rule.name !== 'media') return;
    rule.params = rule.params.replace(/\(--pc-([a-z-]+)\)/g, (_, name) => {
      if (!Object.hasOwn(breakpoints, name)) throw rule.error(`未知 Cel 断点：${name}`);
      return breakpoints[name];
    });
  }};
}
