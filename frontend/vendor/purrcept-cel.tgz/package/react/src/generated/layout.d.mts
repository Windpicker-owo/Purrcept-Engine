// 由 scripts/export_tokens.py 从 DESIGN.md 生成，请勿手动修改。
export declare const breakpoints: {
  readonly navigation: string;
  readonly inspector: string;
  readonly workspace: string;
};
export declare function breakpointMedia(): {
  postcssPlugin: string;
  AtRule(rule: { name: string; params: string; error(message: string): Error }): void;
};
