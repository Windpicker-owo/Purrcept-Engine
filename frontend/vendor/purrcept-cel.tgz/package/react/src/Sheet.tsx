/**
 * Sheet：从右侧边缘推入的面板，用于详情、编辑、窄屏 Inspector 与审批。
 *
 * 职责：
 * - 默认非模态：点击外部不关闭，页面其余部分仍可操作；``modal`` 时带 scrim 并局部阻断；
 * - 头部是拖拽手柄：指针 1:1 跟随，松手时位移超过宽度 30% 或速度超过阈值即关闭，否则
 *   以弹簧回到原位（速度交给弹簧）；向左越界按 ``motion.resist`` 阻尼跟随；``modal`` 时
 *   scrim 随拖拽进度同步变淡。
 *
 * 不负责：不决定内容结构；审批场景请使用 ApprovalSheet。
 */

import * as RadixDialog from "@radix-ui/react-dialog";
import {
  AnimatePresence,
  motion,
  useDragControls,
  useMotionValue,
  useTransform,
  type PanInfo,
} from "motion/react";
import { useRef, type PointerEvent, type ReactElement, type ReactNode } from "react";

import { Icon } from "./icons";
import { noDescription } from "./internal";
import { elastic, springPhysics, transitions } from "./tokens";

/** 松手关闭的阈值：位移占宽度的比例。 */
export const SHEET_DISMISS_RATIO = 0.3;
/** 松手关闭的阈值：向右速度（px/s）。 */
export const SHEET_DISMISS_VELOCITY = 600;

const SNAP = springPhysics(transitions.snap);
/** 抽屉进入、离开和拖拽回位统一使用快速无回弹的 snap，避免内容就绪后仍拖尾。 */
const DRAG_RETURN = { bounceStiffness: SNAP.stiffness, bounceDamping: SNAP.damping } as const;

/** Sheet 的属性。 */
export interface SheetProps {
  readonly open: boolean;
  readonly onOpenChange: (open: boolean) => void;
  readonly title: ReactNode;
  readonly description?: ReactNode;
  readonly children?: ReactNode;
  /** 底部操作。 */
  readonly actions?: ReactNode;
  /** 局部阻断（例如审批）。默认 false。 */
  readonly modal?: boolean;
}

/** 根据松手时的位移与速度判断是否关闭。 */
export function shouldDismissSheet(offsetX: number, velocityX: number, width: number): boolean {
  return offsetX > width * SHEET_DISMISS_RATIO || velocityX > SHEET_DISMISS_VELOCITY;
}

/** 头部里这些元素保持自己的指针语义，不作为拖拽起点。 */
const INTERACTIVE = "button, a[href], input, textarea, select, [role='button'], [contenteditable]";

/** 右侧面板。 */
export function Sheet({ open, onOpenChange, modal = false, ...content }: SheetProps): ReactElement {
  return (
    <RadixDialog.Root open={open} onOpenChange={onOpenChange} modal={modal}>
      <AnimatePresence>
        {open ? (
          <RadixDialog.Portal forceMount key="pc-sheet">
            <SheetLayer modal={modal} onOpenChange={onOpenChange} {...content} />
          </RadixDialog.Portal>
        ) : null}
      </AnimatePresence>
    </RadixDialog.Root>
  );
}

/**
 * 每次打开挂载一次：拖拽位移是这一次打开的状态，重新打开时从零开始。
 *
 * 外层负责进出场（``x`` 以宽度百分比推入 / 推出），内层负责拖拽（``dragX`` 像素位移）；
 * 两者分开，scrim 才能只读取拖拽进度，随指针 1:1 变淡，松手回弹时也一起回来。
 */
function SheetLayer({
  onOpenChange,
  title,
  description,
  children,
  actions,
  modal,
}: Omit<SheetProps, "open"> & { readonly modal: boolean }): ReactElement {
  const controls = useDragControls();
  const panel = useRef<HTMLDivElement>(null);
  const dragX = useMotionValue(0);
  const scrimOpacity = useTransform(dragX, (offset) => {
    const width = panel.current?.offsetWidth ?? 0;
    return width > 0 ? 1 - Math.min(1, Math.max(0, offset / width)) : 1;
  });

  const startDrag = (event: PointerEvent<HTMLElement>): void => {
    // 头部里的按钮、链接与输入框保持普通的指针语义。
    if (event.target instanceof Element && event.target.closest(INTERACTIVE) !== null) {
      return;
    }
    controls.start(event);
  };

  const endDrag = (_event: unknown, info: PanInfo): void => {
    const width = panel.current?.offsetWidth ?? 0;
    if (shouldDismissSheet(info.offset.x, info.velocity.x, width)) {
      onOpenChange(false);
    }
  };

  return (
    <>
      {modal ? (
        <motion.div style={{ opacity: scrimOpacity }}>
          <RadixDialog.Overlay forceMount asChild>
            <motion.div
              className="pc-scrim"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, transition: transitions.snap }}
              transition={transitions.snap}
            />
          </RadixDialog.Overlay>
        </motion.div>
      ) : null}
      <RadixDialog.Content
        forceMount
        asChild
        {...noDescription(description)}
        onInteractOutside={modal ? undefined : (event) => event.preventDefault()}
        onOpenAutoFocus={(event) => {
          event.preventDefault();
          panel.current?.focus();
        }}
      >
        <motion.div
          ref={panel}
          tabIndex={-1}
          className="pc-sheet"
          initial={{ x: "110%" }}
          animate={{ x: 0 }}
          exit={{ x: "110%", transition: transitions.snap }}
          transition={transitions.snap}
        >
          <motion.div
            className="pc-sheet__panel pc-overlay-surface"
            style={{ x: dragX }}
            drag="x"
            dragControls={controls}
            dragListener={false}
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={{ left: elastic.resist, right: 1 }}
            dragTransition={DRAG_RETURN}
            onDragEnd={endDrag}
          >
            <div className="pc-sheet__header" onPointerDown={startDrag}>
              <div className="pc-sheet__heading">
                <RadixDialog.Title className="pc-sheet__title">{title}</RadixDialog.Title>
                {description === undefined ? null : (
                  <RadixDialog.Description className="pc-sheet__description">
                    {description}
                  </RadixDialog.Description>
                )}
              </div>
              <RadixDialog.Close asChild>
                <button type="button" className="pc-icon-button" aria-label="关闭">
                  <Icon name="close" />
                </button>
              </RadixDialog.Close>
            </div>
            <div className="pc-sheet__body">{children}</div>
            {actions === undefined ? null : <div className="pc-sheet__actions">{actions}</div>}
          </motion.div>
        </motion.div>
      </RadixDialog.Content>
    </>
  );
}
