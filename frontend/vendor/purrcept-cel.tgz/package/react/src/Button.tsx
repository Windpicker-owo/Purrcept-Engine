/**
 * Button：四种语义变体，全产品唯一的按钮实现。
 *
 * 职责：
 * - ``primary`` 品牌色实底，每个操作上下文最多一个；``destructive`` 只给 R3 不可逆操作；
 * - 加载时保留宽度与文字，超过 300ms 才出现状态点，避免闪烁；
 * - 禁用必须给出原因：没有 ``disabled`` 属性，只有 ``disabledReason``。
 *
 * 不负责：不接受 ``style`` / ``className`` / 颜色参数；视觉只能由变体决定。
 */

import { motion } from "motion/react";
import {
  useEffect,
  useId,
  useState,
  type ComponentPropsWithRef,
  type MouseEvent,
  type ReactElement,
  type ReactNode,
} from "react";

import { loops } from "./tokens";

/** 按钮变体。普通“重试”使用 primary，不因为与错误相关就变成 destructive。 */
export type ButtonVariant = "primary" | "secondary" | "ghost" | "destructive";

/** 低于该时长的操作不显示加载态（DESIGN.md · Motion · 编排）。 */
export const LOADING_DELAY_MS = 300;

type NativeButtonProps = Omit<
  ComponentPropsWithRef<"button">,
  "style" | "className" | "disabled" | "color" | "children"
>;

/** Button 的属性。 */
export interface ButtonProps extends NativeButtonProps {
  readonly variant?: ButtonVariant;
  /** 动词短语，例如“重新授权并重试”，不写“确定”。 */
  readonly children: ReactNode;
  /** 操作进行中：按钮保持宽度与文字，不响应点击。 */
  readonly loading?: boolean;
  /** 不可用的原因。提供时按钮不可用，原因通过 ``aria-describedby`` 与悬停提示可见。 */
  readonly disabledReason?: string;
}

/** 在 ``active`` 持续超过 ``delay`` 毫秒后才返回 true。 */
function useDelayedFlag(active: boolean, delay: number): boolean {
  const [shown, setShown] = useState(false);
  useEffect(() => {
    if (!active) {
      setShown(false);
      return undefined;
    }
    const timer = window.setTimeout(() => setShown(true), delay);
    return () => window.clearTimeout(timer);
  }, [active, delay]);
  return active && shown;
}

/** 按钮。 */
export function Button({
  variant = "primary",
  children,
  loading = false,
  disabledReason,
  type = "button",
  onClick,
  "aria-describedby": describedBy,
  ...rest
}: ButtonProps): ReactElement {
  const reasonId = useId();
  const busyShown = useDelayedFlag(loading, LOADING_DELAY_MS);
  const unavailable = disabledReason !== undefined;

  // 使用 aria-disabled 而不是 disabled：按钮仍可聚焦，读屏用户能听到原因。
  const handleClick = (event: MouseEvent<HTMLButtonElement>): void => {
    if (unavailable || loading) {
      event.preventDefault();
      return;
    }
    onClick?.(event);
  };

  const describedByIds =
    [describedBy, unavailable ? reasonId : undefined].filter(Boolean).join(" ") || undefined;

  return (
    <button
      {...rest}
      type={type}
      className="pc-button"
      data-variant={variant}
      aria-disabled={unavailable ? true : undefined}
      aria-busy={loading ? true : undefined}
      aria-describedby={describedByIds}
      title={disabledReason ?? rest.title}
      onClick={handleClick}
    >
      {busyShown ? (
        <span className="pc-button__busy" aria-hidden="true">
          <motion.span
            className="pc-button__busy-dot"
            animate={{ scale: [1, loops.pulse.scale, 1] }}
            transition={{ duration: loops.pulse.duration, ease: "easeInOut", repeat: Infinity }}
          />
        </span>
      ) : null}
      <span className="pc-button__label">{children}</span>
      {unavailable ? (
        // 留在按钮内部，作为 Radix asChild 触发器时仍是单个元素；aria-hidden 让它不进入
        // 按钮名称，而 aria-describedby 的直接引用仍会读出它。
        <span id={reasonId} className="pc-visually-hidden" aria-hidden="true">
          {disabledReason}
        </span>
      ) : null}
    </button>
  );
}
