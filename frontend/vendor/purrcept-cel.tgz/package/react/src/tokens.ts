/**
 * 动效 Token 的 React 侧入口。
 *
 * 职责：重新导出 ``dist/motion.js`` 生成的预设，组件只从这里取过渡参数。
 * ``./generated/`` 是 ``scripts/sync-tokens.mjs`` 从仓库根部 ``dist/`` 原样复制的副本，不入库。
 * 不负责：不定义任何数值；所有数值来自 DESIGN.md 文件头。
 */

import type { SpringTransition } from "./generated/motion.js";

export {
  holds,
  instant,
  loops,
  motion as transitions,
  stagger,
  staggerDelay,
} from "./generated/motion.js";
export type { MotionToken, SpringTransition, TweenTransition } from "./generated/motion.js";

/** 弹簧的物理参数（质量为 1）。 */
export interface SpringPhysics {
  readonly stiffness: number;
  readonly damping: number;
}

/**
 * 把 ``visualDuration / bounce`` 换算成刚度与阻尼。
 *
 * Motion 的拖拽回弹（``dragTransition``）只接受物理参数，不接受 visualDuration；这里使用与
 * Motion 以及 ``scripts/export_tokens.py`` 相同的推导，让拖拽松手后的回位与 Token 一致：
 * ``root = 2π / (visualDuration × 1.2)``，``stiffness = root²``，
 * ``damping = 2 × clamp(0.05, 1, 1 − bounce) × √stiffness``。
 */
export function springPhysics(spring: SpringTransition): SpringPhysics {
  const root = (2 * Math.PI) / (spring.visualDuration * 1.2);
  const stiffness = root * root;
  const ratio = Math.min(1, Math.max(0.05, 1 - spring.bounce));
  return { stiffness, damping: 2 * ratio * Math.sqrt(stiffness) };
}
