/**
 * ApprovalSheet：``requires_approval`` 的唯一呈现方式。
 *
 * 职责：在模态 Sheet 中依次说明“谁 · 通过什么 · 对谁 / 什么 · 做什么”，以及由
 * ``EffectKind`` 推导的风险等级与是否可逆；R3 使用 destructive 按钮。
 * 关闭面板**不等于拒绝**：请求保留在待处理列表中。
 *
 * 不负责：不决定是否需要审批（Runtime 策略决定）；不自行提高或降低风险等级。
 */

import type { ReactElement, ReactNode } from "react";

import { Button } from "./Button";
import { Icon } from "./icons";
import { RISKS, riskOf, type EffectKind, type Risk } from "./semantics";
import { Sheet } from "./Sheet";
import { StatusMark } from "./StatusMark";

/** 一条待审批的请求，字段直接来自 Runtime 的审批事件。 */
export interface ApprovalRequest {
  /** 谁，例如实体名称。 */
  readonly actor: ReactNode;
  /** 通过什么，例如“手机 · 微信”。 */
  readonly via: ReactNode;
  /** 对谁 / 什么，例如“张三”。 */
  readonly target: ReactNode;
  /** 做什么：动词短语，同时作为面板标题，例如“发送一条消息”。 */
  readonly action: string;
  /** Capability 声明的副作用种类。 */
  readonly effect: EffectKind;
  /** 将要发生的具体内容（可选），例如消息正文预览。 */
  readonly detail?: ReactNode;
}

/** ApprovalSheet 的属性。 */
export interface ApprovalSheetProps {
  readonly open: boolean;
  /** 关闭只是暂时离开，不会拒绝请求。 */
  readonly onOpenChange: (open: boolean) => void;
  readonly request: ApprovalRequest;
  readonly onApprove: () => void;
  readonly onReject: () => void;
  readonly approving?: boolean;
}

const RISK_DETAIL: Readonly<Record<Risk, string>> = {
  R0: "只读取信息，不会改变任何东西。",
  R1: "只改变世界内的状态，之后可以撤销。",
  R2: "会写入外部服务，执行后保留回执。",
  R3: "执行后无法撤回。",
};

/** 审批面板。 */
export function ApprovalSheet({
  open,
  onOpenChange,
  request,
  onApprove,
  onReject,
  approving = false,
}: ApprovalSheetProps): ReactElement {
  const risk = riskOf(request.effect);
  const spec = RISKS[risk];

  return (
    <Sheet
      modal
      open={open}
      onOpenChange={onOpenChange}
      title={request.action}
      description={<StatusMark state="waiting-user" />}
      actions={
        <>
          <Button variant="secondary" onClick={onReject}>
            拒绝
          </Button>
          <Button
            variant={risk === "R3" ? "destructive" : "primary"}
            loading={approving}
            onClick={onApprove}
          >
            允许并执行
          </Button>
        </>
      }
    >
      <dl className="pc-approval__facts">
        <dt>谁</dt>
        <dd>{request.actor}</dd>
        <dt>通过</dt>
        <dd>{request.via}</dd>
        <dt>对象</dt>
        <dd>{request.target}</dd>
        <dt>内容</dt>
        <dd>{request.detail ?? request.action}</dd>
      </dl>
      <div className="pc-approval__risk pc-field" data-family={spec.family} data-risk={risk}>
        {spec.reversible ? null : <Icon name="triangle" />}
        <div>
          <p className="pc-approval__risk-title">
            {risk} · {spec.label}
          </p>
          <p className="pc-approval__risk-detail">{RISK_DETAIL[risk]}</p>
        </div>
      </div>
      <p className="pc-approval__note">关闭面板不会拒绝，请求会留在待处理列表中。</p>
    </Sheet>
  );
}
