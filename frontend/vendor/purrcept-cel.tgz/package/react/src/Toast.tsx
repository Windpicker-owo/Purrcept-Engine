/**
 * Toast：底部中央的短消息，全产品唯一实现。
 *
 * 职责：只承载“结果无法在对象上观察、无需处理、消失后不丢信息”的消息。因此状态在类型上
 * 只允许 ``completed`` 与 ``idle``——失败与等待必须留在受影响的对象上。
 * 自动消失（悬停、聚焦或页面在后台时暂停，恢复后只等剩余时间）；可向下拖动跟手关闭，
 * 被甩走的 Toast 沿拖动方向离开。
 *
 * 不负责：不提供操作按钮（需要处理的事不是 Toast）；不排队重放过期消息。
 */

import { AnimatePresence, motion, type PanInfo } from "motion/react";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactElement,
  type ReactNode,
  type Ref,
} from "react";

import { StatusMark } from "./StatusMark";
import { elastic, transitions } from "./tokens";

/** Toast 允许的状态。 */
export type ToastState = "completed" | "idle";

/** 显示一条 Toast 的参数。 */
export interface ToastOptions {
  readonly title: string;
  readonly state?: ToastState;
  /** 停留时长（毫秒），默认 4000。 */
  readonly duration?: number;
}

/** Toast 的命令式接口。 */
export interface ToastApi {
  /** 显示一条消息，返回其 id。 */
  readonly show: (options: ToastOptions) => string;
  readonly dismiss: (id: string) => void;
}

/** 默认停留时长。 */
export const TOAST_DURATION_MS = 4000;
/** 同时可见的最多条数；更早的消息直接让位。 */
export const TOAST_MAX_VISIBLE = 3;
/** 向下拖动关闭的阈值。 */
export const TOAST_DISMISS_OFFSET = 24;
export const TOAST_DISMISS_VELOCITY = 400;

interface ToastItem {
  readonly id: string;
  readonly title: string;
  readonly state: ToastState;
  readonly duration: number;
}

const ToastContext = createContext<ToastApi | null>(null);

/** 取得 Toast 接口。必须位于 ``CelProvider``（或 ``ToastProvider``）之内。 */
export function useToast(): ToastApi {
  const api = useContext(ToastContext);
  if (api === null) {
    throw new Error("useToast 必须在 CelProvider 内使用");
  }
  return api;
}

/** 页面是否处于后台标签页：后台时没有人在看，Toast 不应悄悄过期。 */
function useDocumentHidden(): boolean {
  const [hidden, setHidden] = useState(() => document.visibilityState === "hidden");
  useEffect(() => {
    const update = (): void => setHidden(document.visibilityState === "hidden");
    document.addEventListener("visibilitychange", update);
    return () => document.removeEventListener("visibilitychange", update);
  }, []);
  return hidden;
}

/**
 * 可暂停的倒计时：暂停时记下剩余时间，恢复后只等剩下的部分。
 *
 * 每次恢复都从完整时长重新计时，会让反复悬停的 Toast 永远不消失。
 */
function usePausableTimeout(duration: number, paused: boolean, onExpire: () => void): void {
  const remaining = useRef(duration);
  useEffect(() => {
    if (paused) {
      return undefined;
    }
    const startedAt = Date.now();
    const timer = window.setTimeout(onExpire, remaining.current);
    return () => {
      window.clearTimeout(timer);
      remaining.current = Math.max(0, remaining.current - (Date.now() - startedAt));
    };
  }, [paused, onExpire]);
}

function ToastView({
  item,
  onDismiss,
  ref,
}: {
  item: ToastItem;
  onDismiss: (id: string) => void;
  /** ``AnimatePresence mode="popLayout"`` 需要直接测量退场元素。 */
  ref?: Ref<HTMLDivElement>;
}): ReactElement {
  const [hovered, setHovered] = useState(false);
  const [focused, setFocused] = useState(false);
  const hidden = useDocumentHidden();
  // 退场方向在动画开始时才读取：被向下甩走的沿同一轴继续离开，计时到期的原地收起。
  const swiped = useRef(false);

  const expire = useCallback(() => onDismiss(item.id), [onDismiss, item.id]);
  usePausableTimeout(item.duration, hovered || focused || hidden, expire);

  const endDrag = (_event: unknown, info: PanInfo): void => {
    if (info.offset.y > TOAST_DISMISS_OFFSET || info.velocity.y > TOAST_DISMISS_VELOCITY) {
      swiped.current = true;
      onDismiss(item.id);
    }
  };

  return (
    <motion.div
      ref={ref}
      layout
      className="pc-toast pc-overlay-surface"
      data-state={item.state}
      variants={{
        exit: () =>
          swiped.current
            ? { opacity: 0, y: "150%", transition: transitions.exit }
            : { opacity: 0, scale: 0.96, transition: transitions.exit },
      }}
      initial={{ opacity: 0, y: 16, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit="exit"
      transition={transitions.arrive}
      drag="y"
      dragConstraints={{ top: 0, bottom: 0 }}
      dragElastic={{ top: elastic.resist, bottom: 1 }}
      onDragEnd={endDrag}
      onPointerEnter={() => setHovered(true)}
      onPointerLeave={() => setHovered(false)}
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
    >
      <StatusMark state={item.state} label={false} />
      <span className="pc-toast__title">{item.title}</span>
      <span className="pc-visually-hidden">向下拖动可关闭</span>
    </motion.div>
  );
}

/** Toast 的宿主：提供接口并渲染底部中央的视口。 */
export function ToastProvider({ children }: { children: ReactNode }): ReactElement {
  const [items, setItems] = useState<readonly ToastItem[]>([]);
  const counter = useRef(0);

  const dismiss = useCallback((id: string) => {
    setItems((current) => current.filter((item) => item.id !== id));
  }, []);

  const show = useCallback((options: ToastOptions) => {
    if (options.title.trim() === "") {
      throw new Error("Toast 必须有文字");
    }
    counter.current += 1;
    const id = `pc-toast-${counter.current}`;
    const item: ToastItem = {
      id,
      title: options.title,
      state: options.state ?? "completed",
      duration: options.duration ?? TOAST_DURATION_MS,
    };
    setItems((current) => [...current, item].slice(-TOAST_MAX_VISIBLE));
    return id;
  }, []);

  const api = useMemo<ToastApi>(() => ({ show, dismiss }), [show, dismiss]);

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="pc-toast-viewport" aria-live="polite" aria-label="通知">
        {/* popLayout：退场的 Toast 立即让出位置，其余条目以 layout 弹簧补位，而不是等它消失后跳过去。 */}
        <AnimatePresence initial={false} mode="popLayout">
          {items.map((item) => (
            <ToastView key={item.id} item={item} onDismiss={dismiss} />
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}
