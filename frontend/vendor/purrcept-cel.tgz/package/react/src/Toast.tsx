/**
 * Toast：底部中央的短消息，全产品唯一实现。
 *
 * 职责：只承载“结果无法在对象上观察、无需处理、消失后不丢信息”的消息。因此状态在类型上
 * 只允许 ``completed`` 与 ``idle``——失败与等待必须留在受影响的对象上。
 * 自动消失（悬停或聚焦时暂停）；可向下拖动跟手关闭。
 *
 * 不负责：不提供操作按钮（需要处理的事不是 Toast）；不排队重放过期消息。
 */

import { AnimatePresence, motion, type PanInfo } from "motion/react";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactElement,
  type ReactNode,
} from "react";

import { StatusMark } from "./StatusMark";
import { transitions } from "./tokens";

/** Toast 允许的状态。 */
export type ToastState = "completed" | "idle";

/** 显示一条 Toast 的参数。 */
export interface ToastOptions {
  readonly title: string;
  readonly state?: ToastState;
  /** 停留时长（毫秒），默认 4000。 */
  readonly duration?: number;
}

/** Toast 的命令式接口。 */
export interface ToastApi {
  /** 显示一条消息，返回其 id。 */
  readonly show: (options: ToastOptions) => string;
  readonly dismiss: (id: string) => void;
}

/** 默认停留时长。 */
export const TOAST_DURATION_MS = 4000;
/** 同时可见的最多条数；更早的消息直接让位。 */
export const TOAST_MAX_VISIBLE = 3;
/** 向下拖动关闭的阈值。 */
export const TOAST_DISMISS_OFFSET = 24;
export const TOAST_DISMISS_VELOCITY = 400;

interface ToastItem {
  readonly id: string;
  readonly title: string;
  readonly state: ToastState;
  readonly duration: number;
}

const ToastContext = createContext<ToastApi | null>(null);

/** 取得 Toast 接口。必须位于 ``CelProvider``（或 ``ToastProvider``）之内。 */
export function useToast(): ToastApi {
  const api = useContext(ToastContext);
  if (api === null) {
    throw new Error("useToast 必须在 CelProvider 内使用");
  }
  return api;
}

function ToastView({
  item,
  onDismiss,
}: {
  item: ToastItem;
  onDismiss: (id: string) => void;
}): ReactElement {
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    if (paused) {
      return undefined;
    }
    const timer = window.setTimeout(() => onDismiss(item.id), item.duration);
    return () => window.clearTimeout(timer);
  }, [paused, item.id, item.duration, onDismiss]);

  const endDrag = (_event: unknown, info: PanInfo): void => {
    if (info.offset.y > TOAST_DISMISS_OFFSET || info.velocity.y > TOAST_DISMISS_VELOCITY) {
      onDismiss(item.id);
    }
  };

  return (
    <motion.div
      layout
      className="pc-toast pc-overlay-surface"
      data-state={item.state}
      initial={{ opacity: 0, y: 16, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.96, transition: transitions.exit }}
      transition={transitions.arrive}
      drag="y"
      dragConstraints={{ top: 0, bottom: 0 }}
      dragElastic={{ top: 0, bottom: 1 }}
      onDragEnd={endDrag}
      onPointerEnter={() => setPaused(true)}
      onPointerLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
    >
      <StatusMark state={item.state} label={false} />
      <span className="pc-toast__title">{item.title}</span>
      <span className="pc-visually-hidden">向下拖动可关闭</span>
    </motion.div>
  );
}

/** Toast 的宿主：提供接口并渲染底部中央的视口。 */
export function ToastProvider({ children }: { children: ReactNode }): ReactElement {
  const [items, setItems] = useState<readonly ToastItem[]>([]);
  const counter = useRef(0);

  const dismiss = useCallback((id: string) => {
    setItems((current) => current.filter((item) => item.id !== id));
  }, []);

  const show = useCallback((options: ToastOptions) => {
    if (options.title.trim() === "") {
      throw new Error("Toast 必须有文字");
    }
    counter.current += 1;
    const id = `pc-toast-${counter.current}`;
    const item: ToastItem = {
      id,
      title: options.title,
      state: options.state ?? "completed",
      duration: options.duration ?? TOAST_DURATION_MS,
    };
    setItems((current) => [...current, item].slice(-TOAST_MAX_VISIBLE));
    return id;
  }, []);

  const api = useMemo<ToastApi>(() => ({ show, dismiss }), [show, dismiss]);

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="pc-toast-viewport" aria-live="polite" aria-label="通知">
        <AnimatePresence initial={false}>
          {items.map((item) => (
            <ToastView key={item.id} item={item} onDismiss={dismiss} />
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}
