/**
 * PartialFailure 在对象上呈现部分失败；分组交给 OutcomeList，恢复能力由宿主明确声明。
 * 没有 recovery 时仅呈现事实，不暗示可以重试。组件只回调，不执行或推断重放范围。
 */
import type { ReactElement, ReactNode } from "react";
import { Button } from "./Button";
import { Feedback } from "./Feedback";
import { OutcomeList } from "./OutcomeList";
import type { EffectOutcome } from "./semantics";

/** 来自权威效果账本的事实，不能用请求受理状态替代。 */
export interface EffectRecord {
  readonly id: string;
  readonly label: string;
  readonly outcome: EffectOutcome;
}

/** 宿主必须提供动作名称和效果范围；不由布尔值推断“从失败处继续”。 */
export interface RecoveryAction {
  readonly label: string;
  readonly explanation: string;
  readonly onInvoke: () => void;
  readonly pending?: boolean;
  readonly disabledReason?: string;
}

/** 调用方提供失败原因与真实效果；只有存在业务端口时才提供 recovery。 */
export interface PartialFailureProps {
  readonly title: ReactNode;
  readonly children?: ReactNode;
  readonly effects: readonly EffectRecord[];
  readonly recovery?: RecoveryAction;
}

/** 展示效果与可选恢复入口，未知结果不会触发自动重试。 */
export function PartialFailure({ title, children, effects, recovery }: PartialFailureProps): ReactElement {
  const action = recovery ? {
    urgency: "actionable" as const,
    actions: <Button loading={recovery.pending} disabledReason={recovery.disabledReason} onClick={recovery.onInvoke}>{recovery.label}</Button>,
  } : { urgency: "passive" as const };
  return <Feedback state="failed" scope="object" persistence="until-resolved" title={title} {...action}>
    {children}<OutcomeList items={effects} />
    {recovery ? <p className="pc-outcomes__note">{recovery.explanation}</p> : null}
  </Feedback>;
}
