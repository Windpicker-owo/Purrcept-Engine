/**
 * PartialFailure：Action 部分失败的唯一呈现，如实展示“已经发生 / 结果未知 / 没有发生”。
 *
 * 职责：按 ``committed_effects`` 与调用轨迹把副作用分组展示，并提供“从失败步骤重试”；
 * 明确告诉用户已经发生的部分会不会重复执行。
 *
 * 不负责：不计算分组（来自 Runtime 的 ActionResult）；不执行重试，只回调。
 */

import type { ReactElement, ReactNode } from "react";

import { Button } from "./Button";
import { Feedback } from "./Feedback";
import { Icon, type IconName } from "./icons";
import { EFFECT_OUTCOMES, type EffectOutcome } from "./semantics";

/** 一个副作用及其结局。 */
export interface EffectRecord {
  readonly id: string;
  /** 可归因的描述，例如“消息已发送给张三”。 */
  readonly label: string;
  readonly outcome: EffectOutcome;
}

/** PartialFailure 的属性。 */
export interface PartialFailureProps {
  /** 发生了什么，例如“消息没有全部发出”。 */
  readonly title: ReactNode;
  /** 影响与原因（可选），例如错误码之外的人类描述。 */
  readonly children?: ReactNode;
  readonly effects: readonly EffectRecord[];
  /** 重试时，已经发生的副作用是否会再次执行。 */
  readonly repeatsCommitted: boolean;
  readonly onRetry: () => void;
  readonly retrying?: boolean;
}

/** 展示顺序：先说已经改变世界的，再说不确定的，最后说没有发生的。 */
const ORDER: readonly EffectOutcome[] = ["committed", "unknown", "skipped"];

const ICONS: Readonly<Record<EffectOutcome, IconName>> = {
  committed: "check",
  unknown: "question",
  skipped: "ring",
};

/** 部分失败视图。 */
export function PartialFailure({
  title,
  children,
  effects,
  repeatsCommitted,
  onRetry,
  retrying = false,
}: PartialFailureProps): ReactElement {
  const hasCommitted = effects.some((effect) => effect.outcome === "committed");

  return (
    <Feedback
      state="failed"
      scope="object"
      urgency="actionable"
      persistence="until-resolved"
      title={title}
      actions={
        <Button variant="primary" loading={retrying} onClick={onRetry}>
          从失败步骤重试
        </Button>
      }
    >
      {children}
      <div className="pc-outcomes">
        {ORDER.map((outcome) => {
          const group = effects.filter((effect) => effect.outcome === outcome);
          if (group.length === 0) {
            return null;
          }
          const spec = EFFECT_OUTCOMES[outcome];
          return (
            <section key={outcome} className="pc-outcomes__group" data-outcome={outcome}>
              <h4 className="pc-outcomes__title">{spec.label}</h4>
              <ul className="pc-outcomes__list">
                {group.map((effect) => (
                  <li key={effect.id} className="pc-outcomes__item" data-family={spec.family}>
                    <Icon name={ICONS[outcome]} />
                    <span>{effect.label}</span>
                  </li>
                ))}
              </ul>
            </section>
          );
        })}
        {hasCommitted ? (
          <p className="pc-outcomes__note">
            {repeatsCommitted
              ? "重试会再次执行已经发生的部分。"
              : "重试只执行失败及之后的步骤，已经发生的部分不会重复。"}
          </p>
        ) : null}
      </div>
    </Feedback>
  );
}
