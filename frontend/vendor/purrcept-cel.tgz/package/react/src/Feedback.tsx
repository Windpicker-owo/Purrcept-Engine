/**
 * Feedback：反馈函数 ``呈现 = f(状态, 作用范围, 紧迫度, 持续性)`` 的唯一实现。
 *
 * 职责：
 * - 由 ``scope`` 决定背景场面积：control 不铺底色，object / region 是圆角块，page / system
 *   是贴边横幅；
 * - 失败与等待用户使用 ``role="alert"``，其余使用 ``role="status"``；
 * - ``until-resolved`` 在类型层面不允许关闭。
 *
 * 不负责：不处理 ``blocking``（只能用 Dialog）；不决定出现位置——调用方必须把它放在受影响
 * 的对象旁边；不负责退场编排，需要退场动画时由调用方包一层 ``AnimatePresence``。
 */

import { motion } from "motion/react";
import type { ReactElement, ReactNode } from "react";

import { Icon } from "./icons";
import {
  STATES,
  feedbackSurface,
  type AgentState,
  type Persistence,
  type Scope,
} from "./semantics";
import { StatusMark } from "./StatusMark";
import { transitions } from "./tokens";

interface FeedbackBase {
  readonly state: AgentState;
  readonly scope: Scope;
  /** 发生了什么。 */
  readonly title: ReactNode;
  /** 影响了什么、为什么。 */
  readonly children?: ReactNode;
}

/** 只告知：不带操作。 */
interface PassiveFeedback {
  readonly urgency: "passive";
  readonly actions?: never;
}

/** 可处理：必须给出“现在能做什么”。 */
interface ActionableFeedback {
  readonly urgency: "actionable";
  readonly actions: ReactNode;
}

/** 短暂或保留：可以由用户关闭。 */
interface DismissibleFeedback {
  readonly persistence: Exclude<Persistence, "until-resolved">;
  readonly onDismiss?: () => void;
}

/** 直到解决：问题消失前不能被关闭。 */
interface UnresolvedFeedback {
  readonly persistence: "until-resolved";
  readonly onDismiss?: never;
}

/**
 * Feedback 的属性。``urgency`` 不包含 ``blocking``：必须决定的事只能通过 Dialog 表达。
 */
export type FeedbackProps = FeedbackBase &
  (PassiveFeedback | ActionableFeedback) &
  (DismissibleFeedback | UnresolvedFeedback);

/** 失败与等待用户需要立即被辅助技术播报。 */
function roleOf(state: AgentState): "alert" | "status" {
  return state === "failed" || state === "waiting-user" ? "alert" : "status";
}

/** 系统反馈。 */
export function Feedback(props: FeedbackProps): ReactElement {
  const { state, scope, urgency, persistence, title, children, actions, onDismiss } = props;
  const surface = feedbackSurface(scope, urgency);
  const field = scope !== "control";

  return (
    <motion.div
      className={field ? "pc-feedback pc-field" : "pc-feedback pc-tint"}
      data-family={STATES[state].family}
      data-state={state}
      data-scope={scope}
      data-surface={surface}
      data-persistence={persistence}
      role={roleOf(state)}
      initial={{ opacity: 0, y: -4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, transition: transitions.exit }}
      transition={transitions.arrive}
    >
      <span className="pc-feedback__mark">
        <StatusMark state={state} label={false} />
      </span>
      <div className="pc-feedback__body">
        <p className="pc-feedback__title">{title}</p>
        {children === undefined ? null : <div className="pc-feedback__detail">{children}</div>}
        {actions === undefined ? null : <div className="pc-feedback__actions">{actions}</div>}
      </div>
      {onDismiss === undefined ? null : (
        <button
          type="button"
          className="pc-icon-button pc-feedback__dismiss"
          aria-label="关闭"
          onClick={onDismiss}
        >
          <Icon name="close" />
        </button>
      )}
    </motion.div>
  );
}
