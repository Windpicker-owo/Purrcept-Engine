/**
 * @purrcept/cel-react 公共 API。
 *
 * 职责：导出 Purrcept Cel 规范的参考组件、语义模型与动效 Token。公共 API 只由本文件定义。
 * 不负责：不导出内部辅助（``internal.ts``）；不提供第二套同类组件。
 */

import "./styles/index.css";

export { ActionPath, reachOf } from "./ActionPath";
export type { ActionPathNode, ActionPathProps, Reach } from "./ActionPath";
export { ApprovalSheet } from "./ApprovalSheet";
export type { ApprovalRequest, ApprovalSheetProps } from "./ApprovalSheet";
export { Button, LOADING_DELAY_MS } from "./Button";
export type { ButtonProps, ButtonVariant } from "./Button";
export { CelProvider } from "./CelProvider";
export type { CelProviderProps } from "./CelProvider";
export { Dialog } from "./Dialog";
export type { DialogProps } from "./Dialog";
export { Feedback } from "./Feedback";
export type { FeedbackProps } from "./Feedback";
export { Icon } from "./icons";
export type { IconName } from "./icons";
export {
  BLINK_INTERVAL_MS,
  GAZE_RANGE_PX,
  Mascot,
  POSES,
  blinkDelay,
  computeGaze,
  resolveGaze,
} from "./Mascot";
export type {
  Gaze,
  MascotEars,
  MascotEyes,
  MascotGaze,
  MascotMotion,
  MascotPose,
  MascotProps,
} from "./Mascot";
export { PartialFailure } from "./PartialFailure";
export type { EffectRecord, PartialFailureProps } from "./PartialFailure";
export { Popover } from "./Popover";
export type { PopoverProps } from "./Popover";
export {
  EFFECT_OUTCOMES,
  RISKS,
  STATES,
  feedbackSurface,
  isLive,
  riskOf,
} from "./semantics";
export type {
  AgentState,
  Beat,
  EffectKind,
  EffectOutcome,
  Family,
  FeedbackSurface,
  Persistence,
  Risk,
  RiskSpec,
  Scope,
  Shape,
  StateSpec,
  Urgency,
} from "./semantics";
export { Sheet, SHEET_DISMISS_RATIO, SHEET_DISMISS_VELOCITY, shouldDismissSheet } from "./Sheet";
export type { SheetProps } from "./Sheet";
export { StatusMark } from "./StatusMark";
export type { StatusMarkProps } from "./StatusMark";
export {
  TOAST_DISMISS_OFFSET,
  TOAST_DISMISS_VELOCITY,
  TOAST_DURATION_MS,
  TOAST_MAX_VISIBLE,
  ToastProvider,
  useToast,
} from "./Toast";
export type { ToastApi, ToastOptions, ToastState } from "./Toast";
export {
  holds,
  instant,
  loops,
  springPhysics,
  stagger,
  staggerDelay,
  transitions,
} from "./tokens";
export type { MotionToken, SpringPhysics, SpringTransition, TweenTransition } from "./tokens";
