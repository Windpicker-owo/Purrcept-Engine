/**
 * Popover：从锚点长出的非阻断浮层，用于菜单、选择器与补充说明。
 *
 * 职责：以触发点为 transform-origin 用 ``arrive`` 长出、``exit`` 收回；支持受控与非受控。
 *
 * 不负责：不实现菜单键盘导航（菜单项语义由内容决定）；不承载必须决定的事（那是 Dialog）。
 */

import * as RadixPopover from "@radix-ui/react-popover";
import { AnimatePresence, motion } from "motion/react";
import type { ReactElement, ReactNode } from "react";

import { useOpenState } from "./internal";
import { transitions } from "./tokens";

/** Popover 的属性。 */
export interface PopoverProps {
  /** 触发元素，通常是 Button；必须能接收 ref 与事件属性。 */
  readonly trigger: ReactElement;
  readonly children: ReactNode;
  /** 浮层的可读名称。 */
  readonly label: string;
  readonly open?: boolean;
  readonly defaultOpen?: boolean;
  readonly onOpenChange?: (open: boolean) => void;
  readonly side?: "top" | "right" | "bottom" | "left";
  readonly align?: "start" | "center" | "end";
}

/** 锚点浮层。 */
export function Popover({
  trigger,
  children,
  label,
  open,
  defaultOpen = false,
  onOpenChange,
  side = "bottom",
  align = "start",
}: PopoverProps): ReactElement {
  const [isOpen, setOpen] = useOpenState(open, defaultOpen, onOpenChange);

  return (
    <RadixPopover.Root open={isOpen} onOpenChange={setOpen}>
      <RadixPopover.Trigger asChild>{trigger}</RadixPopover.Trigger>
      <AnimatePresence>
        {isOpen ? (
          <RadixPopover.Portal forceMount key="pc-popover">
            <RadixPopover.Content
              forceMount
              asChild
              side={side}
              align={align}
              sideOffset={8}
              collisionPadding={16}
              aria-label={label}
            >
              <motion.div
                className="pc-popover pc-overlay-surface"
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.96, transition: transitions.exit }}
                transition={transitions.arrive}
              >
                {children}
              </motion.div>
            </RadixPopover.Content>
          </RadixPopover.Portal>
        ) : null}
      </AnimatePresence>
    </RadixPopover.Root>
  );
}
