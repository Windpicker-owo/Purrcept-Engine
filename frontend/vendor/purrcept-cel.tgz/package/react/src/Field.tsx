/**
 * Field 统一原生字段的可见标签、说明和错误关联。
 * 应用通过 render function 把关联属性交给唯一原生控件，仍拥有值与校验，不传视觉参数。
 */
import { useId, type ReactElement, type ReactNode } from "react";

/** 必须原样传给字段唯一的 input/select/textarea，使标签与错误可被读屏读取。 */
export interface FieldControlProps {
  readonly id: string;
  readonly "aria-describedby"?: string;
  readonly "aria-invalid"?: true;
}

/** label 始终可见；description 说明用途，error 解释当前输入问题及修正办法。 */
export interface FieldProps {
  readonly label: string;
  readonly description?: string;
  readonly error?: string;
  readonly children: (control: FieldControlProps) => ReactNode;
}

/** 建立字段关联；原生控件继承统一样式与焦点环，组件不修改输入。 */
export function Field({ label, description, error, children }: FieldProps): ReactElement {
  const id = useId();
  const descriptionId = `${id}-description`;
  const errorId = `${id}-error`;
  const describedBy = [description ? descriptionId : null, error ? errorId : null].filter(Boolean).join(" ") || undefined;
  return <div className="pc-form-field">
    <label htmlFor={id}>{label}</label>
    {children({ id, "aria-describedby": describedBy, "aria-invalid": error ? true : undefined })}
    {description ? <p id={descriptionId} className="pc-form-field__description">{description}</p> : null}
    {error ? <p id={errorId} role="alert" className="pc-tint" data-family="failed">{error}</p> : null}
  </div>;
}
