/**
 * CelProvider：参考组件的运行环境。
 *
 * 职责：让 Motion 尊重系统的“减少动效”设置（位移瞬切，保留颜色与形状信号），并提供
 * Toast 宿主。应用根部挂载一次即可。
 *
 * 不负责：不渲染外壳布局，也不注入全局样式之外的视觉；根元素的 ``pc-root`` 类由应用添加。
 */

import { MotionConfig } from "motion/react";
import type { ReactElement, ReactNode } from "react";

import { ToastProvider } from "./Toast";

/** CelProvider 的属性。 */
export interface CelProviderProps {
  readonly children: ReactNode;
}

/** 参考组件的根提供者。 */
export function CelProvider({ children }: CelProviderProps): ReactElement {
  return (
    <MotionConfig reducedMotion="user">
      <ToastProvider>{children}</ToastProvider>
    </MotionConfig>
  );
}
