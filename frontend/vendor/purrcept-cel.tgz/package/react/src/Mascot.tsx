/**
 * Mascot：首页舞台上的吉祥物，Agent 的身体与活的状态显示器。
 *
 * 职责：
 * - 只接收两个输入：``state`` 与可选的 ``gazeTarget``；姿势完全由 ``POSES`` 表推导，外部不能
 *   直接控制某个动作；
 * - 只有眼睛带状态色，毛色与腮红是固定的固有色；
 * - 姿势、眼睑与耳根各自持有连续的弹簧，视线跟随 ``gazeTarget``；
 * - 一次性动作由可取消的序列编排，离开状态或卸载后不再续播。
 *
 * 不负责：不决定放在哪里（只应出现在首页舞台底边）；不渲染状态文字——首页仍须有状态点与当前
 * 任务文字，移除吉祥物后信息结构不变。
 */

import { motion, useAnimationControls, useReducedMotionConfig, type Transition } from "motion/react";
import { useEffect, useRef, useState, type ReactElement, type RefObject } from "react";

import { STATES, type AgentState } from "./semantics";
import { instant, loops, transitions } from "./tokens";

// ---------------------------------------------------------------------------
// 姿势表：吉祥物的全部表达都从这里推导
// ---------------------------------------------------------------------------

/** 眼睛形状：睁开、半垂（失败）、闭上（暂停）、笑眼（完成）。 */
export type MascotEyes = "open" | "low" | "closed" | "happy";

/** 视线：正视用户、向上（思考）、向下（沮丧）、看向侧面或目标。 */
export type MascotGaze = "center" | "up" | "down" | "side" | "target";

/** 耳朵：竖起、转向视线方向、向两侧半张开（警觉）、下压（飞机耳）。 */
export type MascotEars = "up" | "toward" | "wary" | "flat";

/**
 * 姿势内的持续或一次性运动。
 *
 * - ``blink``：空闲时 4–8 秒随机眨眼一次，算作首页唯一的持续运动；
 * - ``twitch``：思考时一只耳朵低幅抖动（代替尾巴，循环）；
 * - ``nod``：完成时以 ``settle`` 点头一次；
 * - ``hit``：失败时顿帧，姿势瞬切后静止；
 * - ``none``：静止。
 */
export type MascotMotion = "blink" | "twitch" | "nod" | "hit" | "none";

/** 单个状态的姿势。 */
export interface MascotPose {
  readonly eyes: MascotEyes;
  readonly gaze: MascotGaze;
  readonly ears: MascotEars;
  /** 侧头角度（度），方向跟随视线的水平方向。 */
  readonly tilt: number;
  readonly motion: MascotMotion;
}

/** 状态 → 姿势。与 DESIGN.md · Mascot · 状态姿势一一对应。 */
export const POSES: Readonly<Record<AgentState, MascotPose>> = Object.freeze({
  idle: { eyes: "open", gaze: "center", ears: "up", tilt: 0, motion: "blink" },
  perceiving: { eyes: "open", gaze: "target", ears: "toward", tilt: 0, motion: "none" },
  reasoning: { eyes: "open", gaze: "up", ears: "up", tilt: 0, motion: "twitch" },
  acting: { eyes: "open", gaze: "target", ears: "up", tilt: 0, motion: "none" },
  "waiting-external": { eyes: "open", gaze: "side", ears: "up", tilt: 6, motion: "none" },
  "waiting-user": { eyes: "open", gaze: "center", ears: "up", tilt: 0, motion: "none" },
  warning: { eyes: "open", gaze: "center", ears: "wary", tilt: 0, motion: "none" },
  paused: { eyes: "closed", gaze: "center", ears: "up", tilt: 0, motion: "none" },
  completed: { eyes: "happy", gaze: "center", ears: "up", tilt: 0, motion: "nod" },
  failed: { eyes: "low", gaze: "down", ears: "flat", tilt: 0, motion: "hit" },
});

// ---------------------------------------------------------------------------
// 视线
// ---------------------------------------------------------------------------

/** 归一化视线方向，分量在 [-1, 1]。 */
export interface Gaze {
  readonly x: number;
  readonly y: number;
}

interface Point {
  readonly x: number;
  readonly y: number;
}

/** 目标距离达到该像素值时视线到达最大偏移；更近时按比例减小，避免近处目标斗鸡眼。 */
export const GAZE_RANGE_PX = 240;

const CENTER: Gaze = { x: 0, y: 0 };
/** 没有提供目标时，“看向目标”默认看向右下方（行动路径通常在吉祥物右侧）。 */
const DEFAULT_TARGET: Gaze = { x: 0.7, y: 0.3 };
const DEFAULT_SIDE: Gaze = { x: 1, y: 0 };

function round2(value: number): number {
  return Math.round(value * 100) / 100;
}

/** 由面部中心与目标中心计算归一化视线。 */
export function computeGaze(from: Point, to: Point): Gaze {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const distance = Math.hypot(dx, dy);
  if (!Number.isFinite(distance) || distance < 1) {
    return CENTER;
  }
  const reach = Math.min(1, distance / GAZE_RANGE_PX);
  return { x: round2((dx / distance) * reach), y: round2((dy / distance) * reach) };
}

/** 把姿势的视线种类解析为具体方向。 */
export function resolveGaze(kind: MascotGaze, measured: Gaze | null): Gaze {
  switch (kind) {
    case "center":
      return CENTER;
    case "up":
      return { x: 0, y: -1 };
    case "down":
      return { x: 0, y: 0.6 };
    case "side":
      return measured ?? DEFAULT_SIDE;
    case "target":
      return measured ?? DEFAULT_TARGET;
  }
}

function sameGaze(a: Gaze | null, b: Gaze | null): boolean {
  return a === b || (a !== null && b !== null && a.x === b.x && b.y === a.y);
}

// ---------------------------------------------------------------------------
// 眨眼
// ---------------------------------------------------------------------------

/** 空闲眨眼的间隔范围（毫秒），来自 DESIGN.md：4–8 秒随机一次。 */
export const BLINK_INTERVAL_MS = { min: 4000, max: 8000 } as const;

/** 由 [0, 1) 的随机数得到下一次眨眼的延迟。 */
export function blinkDelay(random: number): number {
  const r = Math.min(Math.max(random, 0), 1);
  return BLINK_INTERVAL_MS.min + r * (BLINK_INTERVAL_MS.max - BLINK_INTERVAL_MS.min);
}

// ---------------------------------------------------------------------------
// 造型：viewBox 134 × 96，底边与舞台底边重合
//
// 无线稿平涂（参考 Grok Companion 的 Q 版头像）：形体只靠色块区分，没有描边；脸上只有一对
// 竖椭圆眼和腮红，没有鼻子、嘴和胡须。少即是可爱，也让它不和界面争夺焦点。
// 毛色接近白色，因此头部右下有一块赛璐璐阴影（硬边，不是渐变）来撑起轮廓。
// ---------------------------------------------------------------------------

/** viewBox 左右各留出余量：常驻侧倾叠加侧头时，耳尖不被裁掉。 */
const VIEW_X = -4;
const VIEW_W = 134;
const VIEW_H = 96;
/** 面部中心（视线的起点），以 viewBox 比例表示。 */
const FACE_CENTER = { x: (60 - VIEW_X) / VIEW_W, y: 70 / VIEW_H } as const;
const EYE_Y = 70;
const EYE_X = [40.5, 79.5] as const;
/** 视线在 viewBox 中的最大位移。 */
const GAZE_SHIFT = { x: 7, y: 5 } as const;
/**
 * 常驻侧倾（度）：头顶偏向右侧的内容，像从角落探头张望，静止时也有生命感。
 * 姿势里的 ``tilt`` 在此基础上叠加。
 */
const BASE_TILT = 7;
const EAR_TOWARD_DEG = 14;
const EAR_WARY_DEG = 13;
const EAR_FLAT_DEG = 28;
/** 压耳时耳朵整体下沉，贴近头顶。 */
const EAR_FLAT_DROP = 4;
const EAR_TWITCH_DEG = 11;
const NOD_DROP = 5;

// 头部向下延伸出 viewBox，侧头时底边不会露出缺口；两颊外鼓，是团子形而不是方块。
const HEAD =
  "M4 124 C3 108 -1 90 4 74 C9 54 28 33 60 33 C92 33 111 54 116 74 C121 90 117 108 116 124 Z";
/**
 * 受光面向左上收拢，右下露出更宽的硬边阴影。锚点在凸形内部，因此缩小后的色块
 * 仍落在头部轮廓内，不需要 clipPath，也不会在脸颊之外露出白边。
 */
const LIT_SCALE = 0.91;
const LIT_ANCHOR = { x: 22, y: 54 } as const;
const LIT_TRANSFORM =
  `matrix(${LIT_SCALE} 0 0 ${LIT_SCALE} ` +
  `${LIT_ANCHOR.x * (1 - LIT_SCALE)} ${LIT_ANCHOR.y * (1 - LIT_SCALE)})`;
// 耳根深入头部遮挡区，转耳时底角不会从脸颊边缘刺出。
const EAR_LEFT = "M24 69 C15 54 12 25 17 18 C20 13 25 15 30 19 C38 25 46 33 52 40 L43 65 Z";
const EAR_LEFT_INNER = "M20 47 C20 38 21 29 24 26 C27 23 35 32 42 38 Z";
const EAR_RIGHT = "M96 69 C105 54 108 25 103 18 C100 13 95 15 90 19 C82 25 74 33 68 40 L77 65 Z";
const EAR_RIGHT_INNER = "M100 47 C100 38 99 29 96 26 C93 23 85 32 78 38 Z";
/** 头顶的闪电呆毛：Q 版头像的标志，同色平涂；圆角由同色描边的圆形连接得到。 */
const TUFT = "M66 9 Q68 7 67 10 L60 21 L65 21 Q67 21 65 24 L57 34 Q55 36 56 33 L59 25 L54 25 Q52 25 54 22 Z";
const BLUSH = [
  { cx: 26, cy: 85 },
  { cx: 94, cy: 85 },
] as const;
const EYE_OVAL =
  "M0 -10.5 C4.5 -10.5 7 -5.5 7 0 C7 6 4 10 0 10 " +
  "C-4 10 -7 6 -7 0 C-7 -5.5 -4.5 -10.5 0 -10.5 Z";
// 闭眼与笑眼共用同一条弧线，用连续翻转衔接，避免切换 path 时闪断。
const EYE_CLOSED = "M-6.5 0 C-3 4.5 3 4.5 6.5 0";

/**
 * Motion 默认以 fill-box 定位 SVG 转轴，轮廓变形时该轴也会漂移。
 * 显式使用 view-box，并扣除它的左边界，将绘图坐标转换为稳定的 CSS 原点偏移。
 */
function svgPivot(x: number, y: number) {
  return { transformBox: "view-box" as const, originX: `${x - VIEW_X}px`, originY: `${y}px` };
}

// ---------------------------------------------------------------------------
// 组件
// ---------------------------------------------------------------------------

/** Mascot 的属性：组件契约只有这两项。 */
export interface MascotProps {
  readonly state: AgentState;
  /**
   * 视线目标，例如行动路径当前节点。``perceiving`` / ``acting`` 看向它，``waiting-external``
   * 侧头看向它；其余状态忽略。
   */
  readonly gazeTarget?: RefObject<Element | null>;
}

function earAngles(ears: MascotEars, gaze: Gaze): readonly [number, number] {
  switch (ears) {
    case "up":
      return [0, 0];
    case "toward":
      return [gaze.x * EAR_TOWARD_DEG, gaze.x * EAR_TOWARD_DEG];
    case "wary":
      return [-EAR_WARY_DEG, EAR_WARY_DEG];
    case "flat":
      return [-EAR_FLAT_DEG, EAR_FLAT_DEG];
  }
}

function eyeScale(eyes: MascotEyes, blinking: boolean): number {
  if (blinking || eyes === "closed" || eyes === "happy") {
    return 0.04;
  }
  return eyes === "low" ? 0.5 : 1;
}

function centerOf(rect: DOMRect): Point {
  return { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
}

/** 跟随布局动画的测量窗口：覆盖一次 ``move`` 弹簧的完整时长。 */
const FOLLOW_MS = transitions.move.visualDuration * 2 * 1000;

/**
 * 耳朵的反射动作与完成点头独立于静态姿势，避免视线更新重新播放动作。
 *
 * 生命周期：每次状态变化先停止旧序列，新弹簧从当前值接管。等待用户、失败及减少动效
 * 立即归零；暂停则允许耳朵柔和回位。定时器只控制静候间隔，所有实际位移均为 Token 弹簧。
 */
function useGestures(state: AgentState, reduced: boolean) {
  const ear = useAnimationControls();
  const nod = useAnimationControls();
  const previous = useRef(state);

  useEffect(() => {
    const entered = previous.current !== state;
    previous.current = state;
    let cancelled = false;
    let timer: number | undefined;
    const earRest = { rotate: 0, scaleX: 1 };
    const headRest = { y: 0, scaleY: 1 };
    const hardStop = reduced || state === "failed" || state === "waiting-user";

    if (hardStop) {
      ear.set(earRest);
      nod.set(headRest);
    } else {
      void ear.start({ ...earRest, transition: transitions.move });
      void nod.start({ ...headRest, transition: transitions.move });
    }

    // 耳根先外拨，耳廓略收窄，再反向小幅回摆。长短不一的静候避免钟摆式循环。
    const flick = async (): Promise<void> => {
      await ear.start({ rotate: EAR_TWITCH_DEG, scaleX: 0.94, transition: transitions.snap });
      if (cancelled) return;
      await ear.start({ rotate: -EAR_TWITCH_DEG / 4, scaleX: 1, transition: transitions.snap });
      if (cancelled) return;
      await ear.start({ ...earRest, transition: transitions.settle });
      if (cancelled) return;
      const quietMs = loops.pulse.duration * (2 + Math.random() * 2) * 1000;
      timer = window.setTimeout(() => void flick(), quietMs);
    };

    // 点头先压低再收束，禁止把 [起点, 终点] 关键帧当作弹簧，打断时不能跳回起点。
    const acknowledge = async (): Promise<void> => {
      await nod.start({ y: NOD_DROP, scaleY: 0.97, transition: transitions.snap });
      if (cancelled) return;
      await nod.start({ ...headRest, transition: transitions.settle });
    };

    if (!reduced && state === "reasoning") {
      timer = window.setTimeout(() => void flick(), transitions.move.visualDuration * 1000);
    }
    if (!reduced && entered && state === "completed") {
      void acknowledge();
    }

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
      ear.stop();
      nod.stop();
    };
  }, [state, reduced, ear, nod]);

  return { ear, nod };
}

/**
 * 首页舞台创建的状态显示器。调用方提供语义状态和可选的视线目标，不控制内部动作。
 * 任意时刻可切换状态，未完成的动作由新状态接管；组件独占动画与计时器，并在卸载时释放。
 * 首次显示完成状态不点头，减少动效时只保留静态姿势；状态文字由舞台另行提供。
 */
export function Mascot({ state, gazeTarget }: MascotProps): ReactElement {
  const pose = POSES[state];
  const family = STATES[state].family;
  const reduced = useReducedMotionConfig() ?? false;
  const svg = useRef<SVGSVGElement>(null);
  const gestures = useGestures(state, reduced);

  // 视线测量 ----------------------------------------------------------------
  const [measured, setMeasured] = useState<Gaze | null>(null);
  const tracks = pose.gaze === "target" || pose.gaze === "side";

  // 每次渲染后测量；目标节点常伴随 layout 动画移动，因此在一个弹簧时长内逐帧跟随。
  useEffect(() => {
    if (!tracks) {
      return undefined;
    }
    const measure = (): void => {
      const target = gazeTarget?.current ?? null;
      const host = svg.current;
      if (target === null || host === null) {
        setMeasured((previous) => (previous === null ? previous : null));
        return;
      }
      const box = host.getBoundingClientRect();
      const face = {
        x: box.left + box.width * FACE_CENTER.x,
        y: box.top + box.height * FACE_CENTER.y,
      };
      const next = computeGaze(face, centerOf(target.getBoundingClientRect()));
      setMeasured((previous) => (sameGaze(previous, next) ? previous : next));
    };

    let frame = 0;
    const until = performance.now() + FOLLOW_MS;
    const tick = (): void => {
      measure();
      if (!reduced && performance.now() < until) {
        frame = requestAnimationFrame(tick);
      }
    };
    tick();
    window.addEventListener("resize", measure);
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("resize", measure);
    };
  });

  // 眨眼 --------------------------------------------------------------------
  const [blinking, setBlinking] = useState(false);
  const blinks = pose.motion === "blink" && !reduced;

  useEffect(() => {
    if (!blinks) {
      // 离开空闲必须释放未完成的闭眼，返回时重新计时，不继承旧眨眼的一半。
      setBlinking(false);
      return undefined;
    }
    if (blinking) {
      return undefined;
    }
    const timer = window.setTimeout(() => setBlinking(true), blinkDelay(Math.random()));
    return () => window.clearTimeout(timer);
  }, [blinks, blinking]);

  const blinkNow = blinks && blinking;

  // 姿势 → 动画目标 ----------------------------------------------------------
  const gaze = resolveGaze(pose.gaze, tracks ? measured : null);
  const [earLeft, earRight] = earAngles(pose.ears, gaze);
  const tilt = BASE_TILT + pose.tilt * (gaze.x < 0 ? -1 : 1);

  const poseTransition: Transition = reduced || pose.motion === "hit" ? instant : transitions.move;
  const earY = pose.ears === "flat" ? EAR_FLAT_DROP : 0;
  const scaleY = eyeScale(pose.eyes, blinkNow);
  const eyeTransition: Transition = reduced || pose.motion === "hit" ? instant : transitions.snap;
  const lineEyes = pose.eyes === "closed" || pose.eyes === "happy";

  const renderEye = (x: number): ReactElement => (
    <g key={x} transform={`translate(${x} ${EYE_Y})`}>
      <motion.path
        className="pc-mascot__eye"
        d={EYE_OVAL}
        style={svgPivot(0, 2)}
        initial={false}
        animate={{ scaleY, opacity: lineEyes ? 0 : 1 }}
        transition={eyeTransition}
        onAnimationComplete={() => {
          if (blinkNow && x === EYE_X[0]) {
            setBlinking(false);
          }
        }}
      />
      <motion.path
        className="pc-mascot__eye-line"
        d={EYE_CLOSED}
        style={svgPivot(0, 0)}
        initial={false}
        animate={{ scaleY: pose.eyes === "happy" ? -1 : 1, opacity: lineEyes ? 1 : 0, y: 2 }}
        transition={eyeTransition}
      />
    </g>
  );

  return (
    <svg
      ref={svg}
      className="pc-mascot pc-tint"
      viewBox={`${VIEW_X} 0 ${VIEW_W} ${VIEW_H}`}
      role="img"
      aria-label={`吉祥物：${STATES[state].label}`}
      data-state={state}
      data-family={family}
      data-eyes={pose.eyes}
      data-ears={pose.ears}
      data-gaze={pose.gaze}
      data-blinking={blinkNow ? true : undefined}
    >
      <motion.g
        style={svgPivot(60, 104)}
        initial={false}
        animate={{ rotate: tilt }}
        transition={poseTransition}
      >
        <motion.g
          className="pc-mascot__nod"
          style={svgPivot(60, 96)}
          initial={false}
          animate={gestures.nod}
        >
          <motion.g
            className="pc-mascot__ear"
            style={svgPivot(28, 49)}
            initial={false}
            animate={{ rotate: earLeft, y: earY }}
            transition={poseTransition}
          >
            <path className="pc-mascot__fur" d={EAR_LEFT} />
            <path className="pc-mascot__shade" d={EAR_LEFT_INNER} />
          </motion.g>
          <motion.g
            className="pc-mascot__ear"
            style={svgPivot(92, 49)}
            initial={false}
            animate={{ rotate: earRight, y: earY }}
            transition={poseTransition}
          >
            <motion.g
              className="pc-mascot__ear-flick"
              style={svgPivot(92, 49)}
              initial={false}
              animate={gestures.ear}
            >
              <path className="pc-mascot__fur" d={EAR_RIGHT} />
              <path className="pc-mascot__shade" d={EAR_RIGHT_INNER} />
            </motion.g>
          </motion.g>
          <path className="pc-mascot__tuft" d={TUFT} />
          <path className="pc-mascot__shade" d={HEAD} />
          <path className="pc-mascot__fur" d={HEAD} transform={LIT_TRANSFORM} />
          {BLUSH.map(({ cx, cy }) => (
            <ellipse key={cx} className="pc-mascot__blush" cx={cx} cy={cy} rx={8} ry={4} />
          ))}
          <motion.g
            initial={false}
            animate={{ x: gaze.x * GAZE_SHIFT.x, y: gaze.y * GAZE_SHIFT.y }}
            transition={reduced || pose.motion === "hit" ? instant : transitions.snap}
          >
            {EYE_X.map(renderEye)}
          </motion.g>
        </motion.g>
      </motion.g>
    </svg>
  );
}
