/**
 * Switch 统一布尔控制的形态和可访问说明。父级提供权威值并执行请求，本组件不乐观翻转。
 * checked=null 表示未知；pending 或 disabledReason 阻止新请求但仍允许聚焦了解原因。
 */
import { motion } from "motion/react";
import { transitions } from "./tokens";
import { useId, type ReactElement } from "react";

/** 每次激活只请求相反的已知值；调用方在宿主确认后更新 checked。 */
export interface SwitchProps {
  readonly label: string;
  readonly checked: boolean | null;
  readonly pending?: boolean;
  readonly disabledReason?: string;
  readonly onCheckedChange: (checked: boolean) => void;
}

/** 使用原生按钮的 Enter/Space 行为，未知或在途时保留可见原因。 */
export function Switch({ label, checked, pending = false, disabledReason, onCheckedChange }: SwitchProps): ReactElement {
  const reasonId = useId();
  const reason = disabledReason ?? (checked === null ? "尚未取得开关状态。" : pending ? "正在等待确认。" : undefined);
  const unavailable = reason !== undefined;
  return <div className="pc-switch-field">
    <button type="button" role="switch" className="pc-switch pc-focusable" aria-label={label}
      aria-checked={checked === true} aria-disabled={unavailable || undefined} aria-busy={pending || undefined}
      aria-describedby={unavailable ? reasonId : undefined} data-checked={checked === true}
      onClick={() => { if (!unavailable && checked !== null) onCheckedChange(!checked); }}>
      <span className="pc-switch__track" aria-hidden="true"><motion.span layout transition={transitions.snap} /></span>
      <span>{checked === null ? "状态未知" : checked ? "已开启" : "已关闭"}</span>
    </button>
    {unavailable ? <p id={reasonId} className="pc-switch__reason">{reason}</p> : null}
  </div>;
}
