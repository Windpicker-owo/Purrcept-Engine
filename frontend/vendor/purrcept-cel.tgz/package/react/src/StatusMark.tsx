/**
 * StatusMark：全产品唯一的状态表达单元。
 *
 * 职责：把 ``AgentState`` 映射成“颜色 + 形状 + 文字”三通道，并播放状态节拍：
 * 运行中低幅循环、完成时收束、失败时硬停、暂停时减速到停、等待用户时静止。
 *
 * 不负责：不决定放在哪里，也不决定背景场；背景场属于 Feedback 等承载组件。
 */

import {
  motion,
  useReducedMotionConfig,
  type TargetAndTransition,
  type Transition,
} from "motion/react";
import type { ReactElement } from "react";

import { Icon, type IconName } from "./icons";
import { useHasChanged } from "./internal";
import { STATES, type AgentState, type Beat, type Shape } from "./semantics";
import { instant, loops, transitions } from "./tokens";

/** StatusMark 的属性。只接受语义参数。 */
export interface StatusMarkProps {
  /** 当前状态。 */
  readonly state: AgentState;
  /**
   * 文字通道。缺省使用统一状态文案；传入字符串时替换为更具体的描述（例如“正在打开微信”）；
   * 传 ``false`` 时只显示标记，文字仍保留给辅助技术。
   */
  readonly label?: string | false;
  /**
   * ``signal`` 使用状态色；``quiet`` 用于“已经结束、不应再吸引注意”的位置，例如行动路径中
   * 已完成的节点。
   */
  readonly tone?: "signal" | "quiet";
}

const ICON_OF: Readonly<Partial<Record<Shape, IconName>>> = {
  clock: "clock",
  person: "person",
  triangle: "triangle",
  pause: "pause",
  check: "check",
  cross: "cross",
};

type ScaleTarget = {
  readonly animate: TargetAndTransition;
  readonly transition: Transition;
};

const REST: ScaleTarget = { animate: { scale: 1 }, transition: instant };

/**
 * 根据节拍计算标记框的缩放目标。
 *
 * ``entered`` 为 false 表示首次挂载：除了循环之外都直接处于静止姿态，避免页面加载时
 * 所有已完成的标记一起弹跳。
 */
function beatTarget(beat: Beat, entered: boolean, reduced: boolean): ScaleTarget {
  if (reduced) {
    return REST;
  }
  switch (beat) {
    case "loop":
      return {
        animate: { scale: [1, loops.pulse.scale, 1] },
        transition: { duration: loops.pulse.duration, ease: "easeInOut", repeat: Infinity },
      };
    case "settle":
      return entered ? { animate: { scale: [0.9, 1] }, transition: transitions.settle } : REST;
    case "decelerate":
      // 从循环中的当前尺度减速回到 1，不重置，与 failed 的硬停形成对比。
      return { animate: { scale: 1 }, transition: transitions.move };
    case "hit":
    case "still":
      return REST;
  }
}

/** 状态标记。 */
export function StatusMark({ state, label, tone = "signal" }: StatusMarkProps): ReactElement {
  const spec = STATES[state];
  const reduced = useReducedMotionConfig() ?? false;
  const entered = useHasChanged(state);

  const target = beatTarget(spec.beat, entered, reduced);
  const text = label === undefined || label === false ? spec.label : label;
  const iconName = ICON_OF[spec.shape];

  return (
    <span
      className={tone === "signal" ? "pc-status pc-tint" : "pc-status"}
      data-family={spec.family}
      data-state={state}
      data-tone={tone}
    >
      <motion.span
        className="pc-status__mark"
        data-shape={spec.shape}
        aria-hidden="true"
        initial={spec.beat === "loop" && !reduced ? undefined : false}
        animate={target.animate}
        transition={target.transition}
      >
        {spec.shape === "dot" ? <span className="pc-status__dot" /> : null}
        {spec.shape === "ring" ? <span className="pc-status__ring" /> : null}
        {iconName === undefined ? null : <Icon name={iconName} />}
      </motion.span>
      <span className={label === false ? "pc-visually-hidden" : "pc-status__label"}>{text}</span>
    </span>
  );
}
