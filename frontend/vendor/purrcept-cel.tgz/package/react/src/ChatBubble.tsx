/**
 * ChatBubble：陪伴对话气泡，按说话方语义自动切换左上/右下小尖角与赛璐璐描边材质。
 *
 * 职责：
 * - ``speaker="agent"`` 使用左上小尖角（``--pc-shape-bubble-agent``）、纯白赛璐璐片与冰蓝硬投影；
 * - ``speaker="user"`` 使用右下小尖角（``--pc-shape-bubble-user``）与澄空蓝浅底；
 * - 不接受 ``style`` / ``className`` / 颜色参数。
 */
import type { ReactElement, ReactNode } from "react";
import type { AgentState } from "./semantics";
import { StatusMark } from "./StatusMark";

/** 对话发言角色：陪伴主体或用户。 */
export type ChatSpeaker = "agent" | "user";

/** ChatBubble 的语义属性。 */
export interface ChatBubbleProps {
  readonly speaker: ChatSpeaker;
  readonly author: string;
  /** 可选的角色情绪/渠道短签，例如“耳朵竖起听你说”或“手机端”。 */
  readonly badge?: string;
  readonly timestamp?: string;
  /** 主体发言关联的行动状态。 */
  readonly state?: AgentState;
  readonly actions?: ReactNode;
  readonly children: ReactNode;
}

/** 渲染单条对话气泡。 */
export function ChatBubble({
  speaker,
  author,
  badge,
  timestamp,
  state,
  actions,
  children,
}: ChatBubbleProps): ReactElement {
  return (
    <article className="pc-bubble" data-speaker={speaker}>
      <header className="pc-bubble__meta">
        <strong className="pc-bubble__author">{author}</strong>
        {badge ? <span className="pc-bubble__badge">{badge}</span> : null}
        {state !== undefined ? <StatusMark state={state} /> : null}
        {timestamp ? <span className="pc-bubble__time">{timestamp}</span> : null}
        {actions ? <div className="pc-bubble__actions">{actions}</div> : null}
      </header>
      <div className="pc-bubble__body">{children}</div>
    </article>
  );
}
