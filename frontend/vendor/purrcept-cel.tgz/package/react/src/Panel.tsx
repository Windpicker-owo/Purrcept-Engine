/**
 * Panel 统一区域的标题、头部操作和材质。应用决定区域位置与内容，不传视觉参数。
 * 只用于 canvas 上的功能区域，不嵌套 Panel；对象内容使用平涂瓦片。
 */
import { useId, type ReactElement, type ReactNode } from "react";
import { Icon } from "./icons";

/** 应用提供区域内容；onNavigate 只让标题进入该区域的完整页面。 */
export interface PanelProps {
  readonly id?: string;
  readonly title: string;
  readonly actions?: ReactNode;
  readonly onNavigate?: () => void;
  readonly children: ReactNode;
}

/** 渲染具名区域，不拥有导航历史或业务状态。 */
export function Panel({ id, title, actions, onNavigate, children }: PanelProps): ReactElement {
  const generatedId = useId();
  const titleId = id ?? generatedId;
  return <section className="pc-panel" aria-labelledby={titleId}>
    <header className="pc-panel__heading">
      <h2 id={titleId}>{onNavigate ? <button type="button" className="pc-panel__link pc-focusable" onClick={onNavigate}>
        {title}<Icon name="chevron" />
      </button> : title}</h2>
      {actions}
    </header>
    {children}
  </section>;
}
