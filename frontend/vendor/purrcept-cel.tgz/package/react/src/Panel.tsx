/**
 * Panel 统一区域的标题、眉标、头部操作与双生场域材质（清透学园 default / 暖调手账 notebook）。
 * 应用决定区域位置与内容，只传语义角色，不传视觉裸值。
 */
import { useId, type ReactElement, type ReactNode } from "react";
import { Icon } from "./icons";

/** 区域所属的双生场域：常规清透学园面板，或承载记忆与随笔的暖调手账页。 */
export type PanelSurface = "default" | "notebook";

/** 应用提供区域内容；onNavigate 只让标题进入该区域的完整页面。 */
export interface PanelProps {
  readonly id?: string;
  readonly title: string;
  /** 可选的大写机能/手账章节眉标（例如 STAGE // 01 或 DIARY ENTRY）。 */
  readonly eyebrow?: string;
  readonly surface?: PanelSurface;
  readonly actions?: ReactNode;
  readonly onNavigate?: () => void;
  readonly children: ReactNode;
}

/** 渲染具名区域，不拥有导航历史或业务状态。 */
export function Panel({
  id,
  title,
  eyebrow,
  surface = "default",
  actions,
  onNavigate,
  children,
}: PanelProps): ReactElement {
  const generatedId = useId();
  const titleId = id ?? generatedId;
  return (
    <section className="pc-panel" data-surface={surface} aria-labelledby={titleId}>
      <header className="pc-panel__heading">
        <div className="pc-panel__titles">
          {eyebrow ? <span className="pc-eyebrow">{eyebrow}</span> : null}
          <h2 id={titleId}>
            {onNavigate ? (
              <button type="button" className="pc-panel__link pc-focusable" onClick={onNavigate}>
                {title}
                <Icon name="chevron" />
              </button>
            ) : (
              title
            )}
          </h2>
        </div>
        {actions}
      </header>
      {children}
    </section>
  );
}
