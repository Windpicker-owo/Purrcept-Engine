/**
 * ActionPath：把 Runtime 的行动链（实体 → 设备 → 应用 → 目标）画成一条路径。
 *
 * 职责：
 * - 当前节点 = 第一个仍在进行或需要关注的节点，它是唯一被上色的节点；
 * - 已到达的连接是墨色实线，通往当前节点的连接以 ``move`` 弹簧推进，未到达的是虚线；
 * - 窄容器下转为纵向（CSS 容器查询），节点增删使用 layout 动画保持身份连续。
 *
 * 不负责：不推断节点状态；状态来自 Runtime 的行动事件，由调用方传入。
 */

import { motion } from "motion/react";
import type { ReactElement, ReactNode } from "react";

import { STATES, isLive, type AgentState } from "./semantics";
import { StatusMark } from "./StatusMark";
import { transitions } from "./tokens";

/** 路径上的一个节点。 */
export interface ActionPathNode {
  /** 稳定身份，例如 World 节点 id；决定 layout 动画的对象身份。 */
  readonly id: string;
  /** 名称，例如“手机”“微信”。 */
  readonly label: string;
  /** 一行状态描述，例如“正在打开对话”。缺省使用统一状态文案。 */
  readonly detail?: string;
  /** 实体头像或类别图标。 */
  readonly icon: ReactNode;
  readonly state: AgentState;
}

/** ActionPath 的属性。 */
export interface ActionPathProps {
  /** 路径的可读名称，例如“Mio 正在通过手机发送消息”。 */
  readonly label: string;
  readonly nodes: readonly ActionPathNode[];
}

/** 节点相对当前进度的位置。 */
export type Reach = "reached" | "current" | "pending";

/**
 * 计算每个节点的到达情况。
 *
 * 没有进行中的节点时，已完成的节点视为到达，其余视为未到达。
 */
export function reachOf(nodes: readonly ActionPathNode[]): readonly Reach[] {
  const current = nodes.findIndex((node) => isLive(node.state));
  return nodes.map((node, index) => {
    if (current < 0) {
      return node.state === "completed" ? "reached" : "pending";
    }
    if (index < current) {
      return "reached";
    }
    return index === current ? "current" : "pending";
  });
}

function Link({ reach }: { reach: Reach }): ReactElement {
  // 通往当前节点的连接从 0 推进到 1；已到达的直接是 1；未到达的只剩虚线轨道。
  const fill = reach === "pending" ? 0 : 1;
  return (
    <span className="pc-path__link" data-reach={reach} aria-hidden="true">
      <span className="pc-path__track" />
      <motion.span
        className="pc-path__fill"
        initial={reach === "current" ? { "--fill": 0 } : false}
        animate={{ "--fill": fill }}
        transition={transitions.move}
      />
    </span>
  );
}

/** 行动路径。 */
export function ActionPath({ label, nodes }: ActionPathProps): ReactElement {
  const reach = reachOf(nodes);

  return (
    <div className="pc-path-frame">
      <ol className="pc-path" aria-label={label}>
        {nodes.map((node, index) => {
          const nodeReach = reach[index] ?? "pending";
          const current = nodeReach === "current";
          return (
            <motion.li
              key={node.id}
              layout="position"
              transition={transitions.move}
              className="pc-path__item"
              data-reach={nodeReach}
              aria-current={current ? "step" : undefined}
            >
              {index === 0 ? null : <Link reach={nodeReach} />}
              <span className="pc-path__node">
                <span
                  className={current ? "pc-path__icon pc-field" : "pc-path__icon"}
                  data-family={current ? STATES[node.state].family : undefined}
                  aria-hidden="true"
                >
                  {node.icon}
                </span>
                <span className="pc-path__label">{node.label}</span>
                <StatusMark
                  state={node.state}
                  label={node.detail}
                  tone={current ? "signal" : "quiet"}
                />
              </span>
            </motion.li>
          );
        })}
      </ol>
    </div>
  );
}
