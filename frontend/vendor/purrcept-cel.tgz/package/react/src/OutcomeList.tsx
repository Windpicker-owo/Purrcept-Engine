/**
 * OutcomeList 按已发生、未知、失败、进行中、未发生的顺序展示逐项事实。
 * 调用方从权威回执建立条目；组件不把调用确认升级为持续效果保证，不推断或执行恢复动作。
 */
import type { ReactElement, ReactNode } from "react";
import { Icon, type IconName } from "./icons";
import { EFFECT_OUTCOMES, type EffectOutcome, type Family } from "./semantics";

/** pending 与 failed 描述调用阶段，另外三种结局复用效果语义。 */
export type OutcomeKind = EffectOutcome | "failed" | "pending";

/** 身份在列表内唯一；children 可提供真实回执、时间与技术细节。 */
export interface OutcomeItem {
  readonly id: string;
  readonly outcome: OutcomeKind;
  readonly label: ReactNode;
  readonly children?: ReactNode;
}

const GROUPS: readonly { outcome: OutcomeKind; label: string; family: Family; icon: IconName }[] = [
  { outcome: "committed", ...EFFECT_OUTCOMES.committed, icon: "check" },
  { outcome: "unknown", ...EFFECT_OUTCOMES.unknown, icon: "question" },
  { outcome: "failed", label: "失败（已发生的部分不会回滚）", family: "failed", icon: "cross" },
  { outcome: "pending", label: "进行中", family: "active", icon: "ring" },
  { outcome: "skipped", ...EFFECT_OUTCOMES.skipped, icon: "pause" },
];

/** 按固定语义顺序分组，组内保持回执顺序；空组不占位。 */
export function OutcomeList({ items }: { readonly items: readonly OutcomeItem[] }): ReactElement {
  return <div className="pc-outcomes">
    {GROUPS.map((group) => {
      const records = items.filter((item) => item.outcome === group.outcome);
      if (!records.length) return null;
      return <section className="pc-outcomes__group" key={group.outcome}>
        <h3 className="pc-outcomes__title pc-tint" data-family={group.family}><Icon name={group.icon} />{group.label} · {records.length}</h3>
        <ul className="pc-outcomes__list">{records.map((item) => <li key={item.id} className="pc-outcomes__record">
          <div>{item.label}</div>{item.children}
        </li>)}</ul>
      </section>;
    })}
  </div>;
}
