/**
 * 组件之间共享的内部辅助，不属于公共 API。
 */

import { useCallback, useState } from "react";

/**
 * 值是否在挂载后发生过变化。
 *
 * 状态节拍（完成的收束、吉祥物点头）只应在状态**变化**时播放；首次挂载时直接处于静止姿态，
 * 避免页面加载时所有已完成的标记一起弹跳。采用“渲染期间调整状态”模式，不依赖 effect。
 */
export function useHasChanged<T>(value: T): boolean {
  const [previous, setPrevious] = useState(value);
  const [changed, setChanged] = useState(false);
  if (!Object.is(previous, value)) {
    setPrevious(value);
    setChanged(true);
  }
  return changed;
}

/**
 * Radix 在缺少 Description 时会告警；只有在确实没有描述时才显式解除关联，
 * 否则保留 Radix 自动生成的 ``aria-describedby``。
 */
export function noDescription(description: unknown): { "aria-describedby"?: undefined } {
  return description === undefined ? { "aria-describedby": undefined } : {};
}

/**
 * 受控 / 非受控的开关状态。
 *
 * 浮层需要在组件内部知道 ``open`` 才能编排退场动画，因此即使调用方不受控也要自己持有状态。
 */
export function useOpenState(
  open: boolean | undefined,
  defaultOpen: boolean,
  onOpenChange: ((open: boolean) => void) | undefined,
): readonly [boolean, (open: boolean) => void] {
  const [inner, setInner] = useState(defaultOpen);
  const controlled = open !== undefined;
  const value = controlled ? open : inner;
  const setValue = useCallback(
    (next: boolean) => {
      if (!controlled) {
        setInner(next);
      }
      onOpenChange?.(next);
    },
    [controlled, onOpenChange],
  );
  return [value, setValue] as const;
}
