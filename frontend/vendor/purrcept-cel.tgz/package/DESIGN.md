---
version: 0.2.0
name: Purrcept Cel
description: "Purrcept 系列 WebUI 的通用视觉与交互语言：背景美术给氛围，前景赛璐璐层干净分明，运动遵循物理；交互用品牌色，状态用语义色。"
colors:
  # 背景美术：页面最底层的氛围。只出现在 canvas 与 gradients 中，不承载信息。
  canvas: "#F2F4F7"
  atmosphere-sky: "#E2EBFC"
  atmosphere-peach: "#FCEEE2"
  # 赛璐璐层：承载内容的面板、对象与浮层。
  surface: "#FFFFFF"
  surface-sunken: "#F3F5F8"
  surface-selected: "#E8ECF2"
  # 磨砂玻璃的底色：只通过 materials.glass 使用，只给导航轨与浮层。
  glass: "rgba(255, 255, 255, 0.78)"
  # 墨：文字、图标与结构线。
  ink: "#15171A"
  ink-secondary: "#484D55"
  ink-muted: "#5E636B"
  ink-disabled: "#A3A7AD"
  on-ink: "#FFFFFF"
  outline: "#D3D8E0"
  outline-subtle: "#E4E8EE"
  focus-ring: "#2456D6"
  scrim: "rgba(21, 23, 26, 0.32)"
  # 品牌“猫眼蓝”：交互与识别。不表达任何状态；“运行中”使用青色 active，与品牌蓝分开。
  brand: "#2456D6"
  brand-hover: "#1C47B8"
  brand-pressed: "#163A99"
  on-brand: "#FFFFFF"
  brand-container: "#E3EBFD"
  on-brand-container: "#173B8F"
  # 语义色：只允许表达状态，禁止用于装饰、品牌或普通交互。
  active: "#0A7480"
  active-container: "#DDF2F4"
  on-active-container: "#06525B"
  success: "#127236"
  success-container: "#E4F3E9"
  on-success-container: "#0F5A2B"
  waiting: "#9C5000"
  waiting-signal: "#F2A11F"
  waiting-container: "#FDF0DA"
  on-waiting-container: "#6B3800"
  failed: "#BC3329"
  # 只给 destructive 按钮的悬停 / 按压：更深一阶的纯色，与 brand-hover / brand-pressed 对称。
  failed-hover: "#A32B22"
  failed-pressed: "#8A1F17"
  failed-container: "#FBE8E5"
  on-failed-container: "#8A1F17"
  paused: "#6D4BC9"
  paused-container: "#EEE9FB"
  on-paused-container: "#3F2490"
  # 吉祥物专用：无线稿平涂的三种固有色，只允许出现在 Mascot 内部，不得用于界面。
  mascot-fur: "#FFFDF9"
  mascot-fur-shade: "#E9E2D8"
  mascot-blush: "#F3BDB3"
typography:
  display:
    fontFamily: 'Geist, MiSans, "Noto Sans SC", system-ui, sans-serif'
    fontSize: 48px
    fontWeight: 700
    lineHeight: 1.08
    letterSpacing: -0.025em
  headline:
    fontFamily: 'Geist, MiSans, "Noto Sans SC", system-ui, sans-serif'
    fontSize: 28px
    fontWeight: 700
    lineHeight: 1.25
    letterSpacing: -0.015em
  title:
    fontFamily: 'Geist, MiSans, "Noto Sans SC", system-ui, sans-serif'
    fontSize: 17px
    fontWeight: 600
    lineHeight: 1.45
  body:
    fontFamily: 'Geist, MiSans, "Noto Sans SC", system-ui, sans-serif'
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.6
  body-long:
    fontFamily: 'Geist, MiSans, "Noto Sans SC", system-ui, sans-serif'
    fontSize: 16px
    fontWeight: 400
    lineHeight: 1.7
  label:
    fontFamily: 'Geist, MiSans, "Noto Sans SC", system-ui, sans-serif'
    fontSize: 13px
    fontWeight: 600
    lineHeight: 1.4
  caption:
    fontFamily: 'Geist, MiSans, "Noto Sans SC", system-ui, sans-serif'
    fontSize: 12px
    fontWeight: 500
    lineHeight: 1.4
  mono:
    fontFamily: '"JetBrains Mono", "SFMono-Regular", Consolas, monospace'
    fontSize: 13px
    fontWeight: 500
    lineHeight: 1.5
    fontFeature: '"tnum" 1, "zero" 1'
rounded:
  none: 0px
  xs: 6px
  sm: 8px
  md: 12px
  lg: 16px
  xl: 24px
  full: 9999px
spacing:
  base: 4px
  xxs: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
  4xl: 96px
  gutter: 32px
  gutter-narrow: 16px
  island-gap: 12px
  sidebar: 72px
  inspector: 360px
  content-max: 1600px
  touch-target: 40px
elevation:
  # 外阴影只能是墨色（与 colors.ink 同 RGB）且足够柔和；inset 只允许墨色（下沉）或纯白（受光边）。
  # 禁止彩色阴影与发光。
  control: "0 1px 2px rgba(21, 23, 26, 0.16), inset 0 1px 0 rgba(255, 255, 255, 0.22)"
  control-surface: "0 1px 2px rgba(21, 23, 26, 0.06)"
  well: "inset 0 1px 2px rgba(21, 23, 26, 0.06)"
  panel: "0 1px 2px rgba(21, 23, 26, 0.04), 0 8px 24px rgba(21, 23, 26, 0.06), inset 0 1px 0 rgba(255, 255, 255, 0.9)"
  lifted: "0 2px 4px rgba(21, 23, 26, 0.05), 0 12px 32px rgba(21, 23, 26, 0.10), inset 0 1px 0 rgba(255, 255, 255, 0.9)"
  overlay: "0 2px 6px rgba(21, 23, 26, 0.06), 0 16px 40px rgba(21, 23, 26, 0.14), inset 0 1px 0 rgba(255, 255, 255, 0.7)"
  dialog: "0 4px 12px rgba(21, 23, 26, 0.08), 0 24px 64px rgba(21, 23, 26, 0.20)"
gradients:
  # 只给背景美术：每个色标必须是 contrast.backgrounds 中的颜色或 transparent，保证其上文字处处可读。
  atmosphere: "radial-gradient(60% 55% at 0% 0%, {colors.atmosphere-sky} 0%, transparent 100%), radial-gradient(55% 50% at 100% 0%, {colors.atmosphere-peach} 0%, transparent 100%)"
  stage: "linear-gradient(115deg, {colors.surface} 40%, {colors.atmosphere-sky} 100%)"
materials:
  # 磨砂玻璃只有一种，只给导航轨与浮层；底色不透明度 ≥ 0.7，没有模糊时也必须可读。
  glass: { tint: "{colors.glass}", blur: 24px, saturate: 1.6 }
motion:
  # 参考实现：Motion (motion.dev) 的 spring，参数为 visualDuration(秒) / bounce。
  snap:   { type: spring, visualDuration: 0.18, bounce: 0 }
  move:   { type: spring, visualDuration: 0.32, bounce: 0 }
  arrive: { type: spring, visualDuration: 0.38, bounce: 0.12 }
  settle: { type: spring, visualDuration: 0.45, bounce: 0.18 }
  exit:   { type: spring, visualDuration: 0.22, bounce: 0 }
  color:  { type: tween, duration: 0.12, ease: linear }
  hit:    { type: hold, duration: 0.08 }
  pulse:  { type: loop, duration: 1.6, scale: 1.25 }
  stagger: 0.03
  stagger-max-items: 6
contrast:
  # 导出脚本据此校验：text × backgrounds 的每一组，以及全部 on-* 配对和组件文字/背景，
  # 都必须达到 minimum。状态信号点（waiting-signal）、禁用色和线条不属于文本，不在此列。
  minimum: 4.5
  text: [ink, ink-secondary, ink-muted, brand, active, success, waiting, failed, paused]
  backgrounds: [canvas, surface, surface-sunken, surface-selected, atmosphere-sky, atmosphere-peach]
components:
  button-primary:
    backgroundColor: "{colors.brand}"
    textColor: "{colors.on-brand}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    height: 36px
    padding: "0 16px"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    outline: "{colors.outline}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    height: 36px
    padding: "0 16px"
  button-ghost:
    backgroundColor: transparent
    textColor: "{colors.ink-secondary}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    height: 36px
    padding: "0 12px"
  button-destructive:
    backgroundColor: "{colors.failed}"
    textColor: "{colors.on-ink}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    height: 36px
    padding: "0 16px"
  input:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    outline: "{colors.outline}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    height: 40px
    padding: "0 12px"
  nav-item:
    backgroundColor: transparent
    textColor: "{colors.ink-muted}"
    rounded: "{rounded.md}"
    size: 44px
  nav-item-current:
    backgroundColor: "{colors.brand-container}"
    textColor: "{colors.on-brand-container}"
    rounded: "{rounded.md}"
    size: 44px
  panel:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.xl}"
    padding: "{spacing.lg}"
  object-surface:
    backgroundColor: "{colors.surface-sunken}"
    rounded: "{rounded.lg}"
    padding: "{spacing.md}"
  stage-field:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.xl}"
    padding: "{spacing.xl}"
  status-mark:
    size: 8px
    rounded: "{rounded.full}"
  status-chip:
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    height: 24px
    padding: "0 8px"
  progress-track:
    backgroundColor: "{colors.outline-subtle}"
    rounded: "{rounded.full}"
    height: 4px
  tooltip:
    backgroundColor: "{colors.ink}"
    textColor: "{colors.on-ink}"
    typography: "{typography.caption}"
    rounded: "{rounded.sm}"
    padding: "6px 8px"
---

# Purrcept Cel

## Overview

Purrcept 的界面像一帧**赛璐璐动画**：最底下是一张有空气感的**背景美术**，上面叠着干净、
边缘分明的**赛璐璐层**——面板、对象和浮层；层与层之间有真实的前后关系。只有“正在发生的
事情”被涂上状态色。状态改变时色块干脆地切换，物体带着重量和惯性移动，最后稳稳停下。

这份规范回答两个问题：**怎样让一个复杂的、持续行动的 Agent 系统被人一眼看懂；以及怎样让它
看起来是一个精心制作的现代产品，而不是一份线框稿。** 两者冲突时，前者优先。

### 核心命题

> **背景有氛围，前景是干净的赛璐璐；运动遵循物理。**
>
> 材质分层，行为拟物。

> **交互用品牌色，状态用语义色。**
>
> 界面上出现的每一处语义色都是一个状态信号；品牌色只表示“可以操作”和“这是 Purrcept”。

这一版采用**克制的新拟物**：

- **深度可见。** 面板浮在背景之上，按钮可以被按下，输入框微微下沉。深度来自柔和的墨色阴影、
  受光边和色阶，而不是粗重的描边。
- **氛围存在，但只在背景。** 背景美术可以有极淡的品牌色晕；首页舞台可以有柔和过渡。内容所在
  的赛璐璐层保持平涂，保证可读。
- **材质有边界。** 磨砂玻璃全产品只有一种，只给导航轨和浮层；渐变只给背景美术和连续数据；
  没有彩色阴影、发光和霓虹。
- **真实感进入行为。** 惯性、弹性、连续、跟手（见 Motion），这一点不变。

### 七条原则

每条原则都附带一个可以在评审时直接执行的检验。

| # | 原则 | 含义 | 检验 |
|---|---|---|---|
| 1 | **感知先于阅读** | 颜色、形状、位置、运动回答“发生了哪类事、在哪里”；文字回答“具体是什么、接下来怎么办” | 把截图缩到 25% 或模糊处理，仍能指出哪里在运行、哪里出错 |
| 2 | **语法唯一，形态可变** | 同一状态在任何地方遵循同一反馈逻辑；返回动画、浮层、状态词全产品只有一套 | 任取两处出现同一状态的界面，能说出它们共享的规则 |
| 3 | **个性只在变化时出现** | 静止时退后，变化时鲜活；氛围是静态的背景，不是动画 | 30 秒不操作，屏幕上持续运动的区域 ≤ 1 处 |
| 4 | **分区明确，层级不超过三层** | 页面先分成几块浮起的面板，再在面板里摆放对象；面板是区域，卡片是对象 | 能用一句话说出每块面板负责什么；找不到第四层叠放 |
| 5 | **材质分层** | 背景美术可以有氛围；内容层平涂；玻璃只在导航与浮层 | 内容文字下方找不到渐变或透出的杂色 |
| 6 | **边界交给层，不交给线** | 区域之间用面板和间隙分开；线只用于面板内部的真实边界 | 去掉所有分界线后区域仍然分明 |
| 7 | **连续、可打断、跟手** | 对象身份不瞬移，动画可中途反向且继承速度，手势 1:1 跟随 | 动画进行到一半时反向操作，不跳帧、不重播 |

### 原则冲突时的裁决

- **感知先于阅读 × 无障碍**：颜色是第一通道，但永远不是唯一通道。每个状态必须同时有一个
  **形状**信号；失败和等待用户还必须有文字。
- **氛围信号 × 不嘈杂**：状态氛围色的面积**等于受影响的范围**。按钮失败只染按钮；任务失败
  只染任务行；只有全局断线才染顶栏。背景美术的品牌色晕不随状态变化。
- **设计感 × 可读性**：任何材质与氛围效果都必须在其上的文字达到 4.5:1 时才成立；做不到就
  回到平涂。
- **流畅动效 × 不嘈杂**：动效是个性的主要载体，但只由状态变化或用户操作触发。
- **一致 × 模板化**：要一致的是**语法**（状态、反馈、空间、运动、材质），不是**版式**。首页
  可以大胆，设置页可以安静，但两者出错的方式必须相同。

### 适用范围

本规范第一版面向 **Purrcept 系列 WebUI**（控制台、观测台、工作台）。桌面、移动端和
Live2D/语音叠加层以后可以在 L5 平台适配中扩展；扩展时只调整密度和导航，不改变语义、
色彩角色、反馈语法、材质层级和动效词汇。

规范分层如下：

```text
L0 命题与原则      本节
L1 语义模型        Semantics：状态、范围、紧迫度、持续性、风险
L2 Tokens          文件头 YAML：色彩、字体、间距、形状、深度、氛围、材质、动效
L3 交互语法        Layout / Elevation / Motion / Feedback / Overlays
L4 组件            Components：StatusMark、ActionPath、Panel、Inspector、ApprovalSheet……
L5 平台适配        未来扩展
L6 治理            Governance：语义 props、禁止裸值、交付检查
```

文件头 YAML 中的 Token 是规范值；正文是遇到新场景时的决策依据。

---

## Semantics

语义模型是整套规范的地基。任何视觉表现都必须从这里推导，不能在组件里另行发明。

### 状态

状态集合与 Purrcept CognitiveRuntime 的主体行为对齐，并归入五个色彩家族。

| 状态 | 色彩家族 | 形状信号 | 运动 | 用户应理解为 |
|---|---|---|---|---|
| `idle` | 墨（muted） | 空心圆点 | 静止 | 当前没有活动 |
| `perceiving` | active 青 | 实心点 + 输入源高亮 | 唯一允许的低幅循环 | 正在接收或分析输入 |
| `reasoning` | active 青 | 实心点 + 阶段标签 | 唯一允许的低幅循环 | 正在组织计划 |
| `acting` | active 青 | 实心点 + 行动路径推进 | 唯一允许的低幅循环 | 正在操作设备、应用或外部服务 |
| `waiting-external` | waiting 琥珀 | 时钟 | 静止 | 在等网络、应用或其他实体 |
| `waiting-user` | waiting 琥珀 | 手 / 人形 | **全部静止** | 需要你做决定 |
| `warning` | waiting 琥珀 | 三角 | 静止 | 可以继续，但有风险或异常 |
| `paused` | paused 紫 | 双竖线 | 循环减速至停 | 任务保留，但不会继续 |
| `completed` | success 绿 | 勾 | 一次收束后静止 | 已成功结束，结果可检查 |
| `failed` | failed 珊瑚 | 叉 | 一次顿帧后静止 | 已停止，需要修复或重试 |

规则：

- **active 青是“系统正在动”的专用色。** 它不用于按钮、链接、导航或品牌；品牌蓝也不用于
  表示“运行中”。
- 没有真实进度数据时，显示阶段和已完成步骤，**禁止伪造百分比**。
- `waiting-user` 必须打断“仍在运行”的错觉：该区域所有循环停止，主操作出现在状态旁边。
- 状态文案全产品统一：运行中 / 等待中 / 等你确认 / 已暂停 / 已完成 / 失败。不要在相同
  语义之间混用“成功、结束、OK”等词。

### 反馈函数

任何系统反馈都由同一个函数决定：

> **呈现 = f(状态, 作用范围, 紧迫度, 持续性)**

| 维度 | 取值 |
|---|---|
| 作用范围 `scope` | `control` 控件 · `object` 对象 · `region` 区域 · `page` 页面 · `system` 系统 |
| 紧迫度 `urgency` | `passive` 告知 · `actionable` 可处理 · `blocking` 必须决定 |
| 持续性 `persistence` | `transient` 短暂 · `retained` 保留 · `until-resolved` 直到解决 |

推导规则：

1. **反馈出现在受影响对象上。** 字段错误在字段旁，步骤失败在步骤行和 Inspector 中，断线
   在顶栏。
2. **氛围色面积 = scope。** 不允许局部错误把整页染红。
3. **只有 `blocking` 才允许打断。** 局部等待不锁住整页，局部失败不跳全局错误页。
4. **`retained` 和 `until-resolved` 的结果留在对象上**，不能只闪过一次 Toast。

### 风险等级：从 Runtime 的 EffectKind 推导

Purrcept 的每个 Capability 都声明了 `effect`。UI 的风险表现直接由它推导，不由组件作者
主观判断。

| 风险 | EffectKind | 执行前 | 执行中 / 后 | 按钮样式 |
|---|---|---|---|---|
| R0 观察 | `pure` · `world_read` · `external_read` | 无提示 | 只进入行动流 | — |
| R1 世界内写入 | `world_write` | 无提示 | 结果附着在对象上；可撤销时提供撤销 | primary |
| R2 对外写入 | `external_write` | 在行动流中预告目标和内容 | 显示“已提交”，并保留回执 | primary |
| R3 不可逆 | `irreversible` | 遵守 `requires_approval`，进入 ApprovalSheet | 结果永久保留在记录中 | destructive |

- 审批是 Runtime 策略决定的，UI 只负责呈现，不能自行跳过或追加审批。
- 普通“重试”使用 primary，不因为它与错误有关就变成 destructive。

### 部分失败：不伪装回滚

Runtime 的不变量是“外部副作用不承诺全局回滚”。UI 必须如实呈现这一点。Action 失败时，
失败视图按 `committed_effects` 和调用轨迹把结果分成三组：

| 分组 | 标记 | 含义 |
|---|---|---|
| 已经发生 | 勾（success） | 已提交的副作用，例如“消息已发送给张三” |
| 没有发生 | 空心圆（ink-muted） | 失败点之后未执行的步骤 |
| 结果未知 | 问号（waiting） | 超时或中断的外部写入，状态无法确认 |

禁止只显示一个红叉，让用户以为什么都没发生。重试应从失败步骤继续，并明确告知已经发生
的部分不会重复执行（或会重复执行）。

---

## Colors

色彩分成四个角色，彼此不能互相借用：**背景美术**、**赛璐璐层（纸与墨）**、**品牌**、**语义**。

### 背景美术

- **Canvas** `{colors.canvas}` 是页面最底层的暖灰纸色，面板浮在它上面。它不是内容底色：正文
  不直接写在 canvas 上，标题和导航除外。
- **Atmosphere** `{colors.atmosphere-sky}`、`{colors.atmosphere-peach}` 是品牌色晕的两种极淡
  色调，只通过 `{gradients.atmosphere}` 和 `{gradients.stage}` 出现，不单独用于任何组件。
- 背景美术是静态的，不随状态变化，也不做动画。

### 纸与墨

- **Surface** `{colors.surface}` 是赛璐璐层的底色：面板、输入框、浮层的不透明退化色。
- **Surface Sunken** `{colors.surface-sunken}` 是面板**内部**的色阶：对象瓦片、工具带、代码块。
  它在面板里表示“这是一个独立对象”，不需要外加轮廓。
- **Surface Selected** `{colors.surface-selected}` 表示被选中的对象。
- **Glass** `{colors.glass}` 只能经由 `{materials.glass}` 使用，见 Elevation & Depth。
- **Ink** `{colors.ink}` 是文字、图标与结构线的颜色；**Ink Secondary / Muted** 依次承担辅助
  说明和低优先级元数据。Tooltip 使用墨底反白。

同一屏幕上，如果用户无法一眼说出两种灰的语义差异，就合并它们。

### 品牌

**Brand** `{colors.brand}`（“猫眼蓝”）是 Purrcept 的品牌色，也是**全部交互**的颜色：

- primary 按钮（`{colors.brand}` 底、`{colors.on-brand}` 字）；
- 焦点环 `{colors.focus-ring}`；
- 链接文字；
- 当前导航项（`{colors.brand-container}` 底、`{colors.on-brand-container}` 字）；
- 文本选中、开关打开、复选框勾选等“用户做出的选择”。

品牌色**不表达任何状态**：不用于“成功”“进行中”或任何告警，也不用于状态点和进度条。它与
五个语义色在色相上刻意保持距离（纯正的蓝；“运行中”的 active 偏青，paused 偏蓝紫），并且
永远伴随交互形态出现（按钮、链接、导航项），因此不会被误读为状态。

品牌识别还来自：

1. 首页吉祥物（见 Mascot）；
2. 猫头标志；
3. 招牌形状：**斜切色块**（见 Shapes）；
4. 招牌运动：`settle` 收束；
5. 背景美术里的品牌色晕。

### 语义色

五个色彩家族（active、success、waiting、failed、paused）**专用于状态**。每个家族只有
三阶，对应赛璐璐的“底色、阴影色、高光色”：

- **实色**（例如 `{colors.active}`）：小面积标记、图标、进度条、状态点。
- **Container**：受影响范围的背景场。
- **On Container**：背景场上的文字。

`waiting` 额外提供 `{colors.waiting-signal}`，只用于状态点和图标填充，因为琥珀色的文字
安全色太暗，作为信号点会失去辨识度。

`failed` 额外提供 `{colors.failed-hover}` / `{colors.failed-pressed}`，只给 destructive 按钮。
destructive 是 R3 风险的交互形态，因此借用 failed 家族；这是语义色进入按钮的唯一例外。

### 吉祥物专用色

`{colors.mascot-fur}`、`{colors.mascot-fur-shade}`、`{colors.mascot-blush}` 是吉祥物的固有色
（毛、内耳、腮红），让无线稿平涂的形体成立。它们**只允许出现在 Mascot 内部**，不得用于
界面、插画、空状态或品牌图形；腮红的暖粉也不是语义色，不表达任何状态。

### 禁止

- 蓝紫粉渐变、彩色发光、霓虹描边、任何“AI 感”背景。
- 把语义色用作装饰、分类标签或“好看的强调”；把品牌色用作状态。如果确实需要按对象类别
  区分，使用图标和文字，不使用颜色。
- 渐变只有两种合法用途：背景美术（`gradients.*` Token）与编码真实连续量（热力、音量、
  数值区间，需带理由豁免）。
- 所有正文与交互文本对比度 ≥ 4.5:1（WCAG AA）。

### 深色模式

深色模式需要一套独立的 Token：纸变成墨，墨变成纸，阴影改为更深的色阶与受光边，语义色逐项
重新校验对比度和强度。禁止通过简单反相生成。第一版只定义浅色主题。

---

## Typography

字体是除吉祥物外最主要的审美来源。

- 字体栈：**Geist → MiSans → Noto Sans SC → 系统无衬线**。技术标识、时间戳、请求 ID、
  代码使用 JetBrains Mono。
- 层级：`display`（每屏最多一处）→ `headline`（页面 / 任务标题）→ `title`（面板、
  Inspector、列表主信息）→ `body` → `label` / `caption`。
- 同一视图只用 400、600、700 三档字重。
- `mono` 只用于真正的技术数据。面向人的数量和百分比使用主字体，并开启表格数字。
- 中文长文本每行约 28–42 个全角字符；正文不使用负字距。
- 每块面板以一个 `title` 开头，下方 `{spacing.sm}` 后进入内容；面板内的小分组用 `label` +
  间距，不再套面板。
- Placeholder 不是标签，字段名称始终可见。

---

## Layout

### 外壳：岛屿式

WebUI 外壳由三块**浮起的岛屿**组成：**导航轨 + 主舞台 + Inspector**。岛屿之间、岛屿与视口
边缘之间都留出 `{spacing.island-gap}` 的间隙，让 canvas 和背景美术透出来。

```text
┌ canvas + gradients.atmosphere ─────────────────────────────────────┐
│ ┌──────┐ ┌──────────────────────────────────┐ ┌──────────────────┐ │
│ │ 导航 │ │ 主舞台（panel 或 canvas 上的多块  │ │ Inspector        │ │
│ │ glass│ │ panel）                           │ │ panel            │ │
│ └──────┘ └──────────────────────────────────┘ └──────────────────┘ │
└────────────────────────────────────────────────────────────────────┘
```

- **导航轨** `{spacing.sidebar}`：`{materials.glass}` + `{elevation.panel}` + `{rounded.xl}`。
  猫头标志置顶，图标 + Tooltip；当前项使用 `nav-item-current`（品牌色容器），不使用状态色。
- **主舞台**：最大宽度 `{spacing.content-max}`。可以是一整块 panel，也可以是 canvas 上
  按 12 列网格排布的多块 panel（工作台、仪表页）。
- **Inspector** `{spacing.inspector}`：一块 panel，解释当前选择；窄屏变为右侧 Sheet。
- 窄屏（< 720px）时导航轨变为底部 glass 标签栏，岛屿间隙收紧为 `{spacing.xs}`。

### 三层结构

可见的叠放最多三层，每一层有固定的材质：

| 层 | 是什么 | 材质 |
|---|---|---|
| 0 背景 | canvas + 背景美术 | `{colors.canvas}` + `{gradients.atmosphere}` |
| 1 面板 | 区域：导航、主舞台、Inspector、页面中的一个功能区 | `panel`：surface + `{elevation.panel}` + `{rounded.xl}` |
| 2 对象 | 面板里的独立对象：任务、设备、审批、字段组 | `object-surface`：surface-sunken 平涂瓦片，无阴影 |

浮层（Popover、Sheet、Dialog、Toast）不计入三层，它们临时盖在一切之上。

- **面板是区域，不是卡片。** 一块面板回答“这一块负责什么”；它有标题，可以有自己的工具栏。
- **面板不嵌套面板。** 面板里需要再分组时，使用对象瓦片、`label` 小标题与间距，或面板内的
  分界线。
- **对象瓦片不加阴影。** 只有放在 canvas 上、可以被选择或拖动的对象（例如看板卡片）才使用
  surface + `{elevation.panel}`，悬停时升到 `{elevation.lifted}`。

### 什么时候分出一块面板

满足任一项就应当分区，而不是让内容在同一张白纸上漂浮：

- 这块内容有自己的职责，可以用一个名词命名（“当前任务”“设备”“最近活动”）；
- 它有自己的工具栏、过滤或滚动区域；
- 它会被单独折叠、调整大小或在窄屏下移动位置。

普通段落、设置项的一行、对象内部的元数据**不是**面板。

### 面板内部的分组

按以下顺序选择手段，前一种足够时不使用后一种：

1. 距离；
2. 对齐与共同轴线；
3. 字号与字重；
4. 色阶（surface → surface-sunken 瓦片）；
5. 分界线（`{colors.outline-subtle}`）。

分界线用于面板内部的真实边界：表头与数据、列表行之间的扫描线、面板头部工具栏与内容、
危险区域。**面板与面板之间不画线**，间隙就是边界。

### 空间节奏

| 关系 | 间距 |
|---|---|
| 同一控件组内 | `{spacing.xs}` |
| 面板标题与内容 | `{spacing.sm}` |
| 同一面板内的条目 | `{spacing.md}` |
| 面板内的相邻分组 | `{spacing.lg}` |
| 面板之间 | `{spacing.island-gap}`（外壳）或 `{spacing.md}`（主舞台内的网格） |
| 面板内边距 | `{spacing.lg}`；首页舞台 `{spacing.xl}` |

不要使用 13px、19px 这类任意值修补布局。尺度不合适时，应重新判断元素之间的关系层级。

### 视觉能量预算

每屏最多：

- 1 个视觉中心（首页是吉祥物舞台，其他页面是标题或任务摘要）；
- 1 个装饰图形家族（斜切色块）；
- 1 处持续运动；
- 1 个 primary 按钮（每个操作上下文）。

### 页面类型

| 类型 | 构图 | 密度 |
|---|---|---|
| 首页 / 工作台 | 舞台面板：吉祥物 + 当前任务 + 行动路径；下方 2–3 块功能面板 | 低 |
| 行动与详情 | 主舞台面板 + Inspector 面板；状态附着在步骤上 | 中 |
| 数据与日志 | 一块满宽面板；面板头是过滤工具带，内容是平面行与扫描线 | 高 |
| 设置与表单 | 每个设置组一块面板，线性单列；组内是标题 + 说明 + 控件 | 低 |

---

## Elevation & Depth

深度由**三层结构**、**柔和墨影**与**受光边**建立，就像赛璐璐片叠在背景美术上：越靠前的层
越亮、投在后一层上的影子越清晰。

### 阴影词汇

| Token | 用于 | 观感 |
|---|---|---|
| `{elevation.panel}` | 岛屿与面板；canvas 上可选择的对象 | 轻轻浮起，顶部一道受光边 |
| `{elevation.lifted}` | 可选择对象的悬停、拖动中 | 更高，影子更远更软 |
| `{elevation.control}` | 实底按钮（primary、destructive） | 可按压的小凸起，顶部高光 |
| `{elevation.control-surface}` | 白底按钮（secondary） | 贴着面板的一点点厚度 |
| `{elevation.well}` | 输入框、搜索框、滑轨 | 微微下沉的凹槽 |
| `{elevation.overlay}` | Popover、Sheet、Toast | 明确脱离页面 |
| `{elevation.dialog}` | Dialog | 最高的一层 |

规则：

- **外阴影只能是墨色**，且不透明度 ≤ 0.24；**inset 只能是墨色（下沉）或纯白（受光边）**。
  彩色阴影、白色外发光、霓虹描边一律禁止。
- **悬停：** 按钮和行只改变底色色阶；canvas 上可选择的对象可以 `{motion.snap}` 上移 2px 并
  换成 `{elevation.lifted}`。面板本身不响应悬停。
- **按压：** 实底按钮换成更深一阶的纯色（`brand-pressed`、`failed-pressed`），并以
  `{motion.snap}` 缩放到 0.97；松开时弹回。
- 对象瓦片（surface-sunken）不加阴影，否则就成了第四层。

### 磨砂玻璃

`{materials.glass}` 是全产品**唯一**的半透明材质：

- 只允许用于**导航轨**与**四种浮层**。内容面板、对象、按钮、输入框都不使用玻璃。
- 底色是 `{colors.glass}`（不透明度 ≥ 0.7），即使浏览器不支持背景模糊也必须可读；导出
  脚本会把它叠在 canvas 上的合成色与全部文字色做对比度校验。
- 玻璃下面只应透出背景美术或页面内容的模糊轮廓，不叠放第二层玻璃。

### 背景美术

- `{gradients.atmosphere}` 铺在 canvas 上，是两团极淡的品牌色晕，固定在视口顶部，不随滚动
  视差、不做动画。
- `{gradients.stage}` 是首页舞台面板的底色，从 surface 过渡到品牌色晕；斜切色块（状态色）
  平涂地叠在它上面。
- 每个渐变色标都必须是已通过对比度校验的背景色（或 `transparent`），因此其上的文字处处可读。
  渐变不能出现在面板内部的内容区、按钮或文字下方。

---

## Shapes

### 圆角

外层容器圆角大、内层小，嵌套时内圆角 ≈ 外圆角 − 内边距，让同心的弧线对齐。

| Token | 用途 |
|---|---|
| `{rounded.xs}` / `{rounded.sm}` | Tooltip、技术标签、菜单项、小图标底 |
| `{rounded.md}` | 输入框、导航项、行内选中底 |
| `{rounded.lg}` | 面板里的对象瓦片、Popover、反馈背景场与横幅 |
| `{rounded.xl}` | 岛屿、面板、首页舞台、Sheet、Dialog |
| `{rounded.full}` | 按钮、Toast、状态点、状态芯片、头像 |

同类对象使用同一圆角，不混用。

### 招牌形状：斜切色块

Purrcept 唯一的品牌图形原语是**斜切色块**：一块纯色平面，其中一边以固定角度（约 72°）
被斜切，类似赛璐璐背景板。

- 只出现在首页舞台，以及空状态。
- 颜色只能是 `surface-sunken` / `brand-container` / 当前状态的 container 色。舞台上的色块
  跟随 Agent 状态切换色阶，这就是“氛围信号”；空状态使用 `brand-container`。
- 色块本身平涂、硬边；它下面可以是 `{gradients.stage}`，上面不叠渐变。
- 不放在正文下方，不承载任何信息。

### 图标

- 统一 1.75px 线性图标，端点和转角一致；状态图标可用实心。
- 同一语义全产品只用一个图标。
- 图标按钮只用于约定俗成的动作（关闭、搜索、更多、返回），其余动作必须带文字。

### 线

- `outline-subtle`：面板内的扫描线、表头分隔、面板头部与内容的分隔。
- `outline`：secondary 按钮与输入框的边界、浮层轮廓、拖拽边界。
- 连接线只在表达真实关系时出现，例如行动路径和时间线。

---

## Motion

动效是 Purrcept 个性的主要载体，也是第 7 条原则的落地。参考实现使用
[Motion](https://motion.dev)，它在原生 JS 和 React 中都支持弹簧、可打断和速度继承。

### 三条底线

1. **连续。** 对象身份永不瞬移。列表重排、卡片展开为详情、选择进入 Inspector 时，都是
   同一个元素在移动（layout / shared element 动画），禁止“先消失、再凭空出现”。
2. **可打断。** 任何过渡都可以在中途被反向操作接管，并从**当前位置和当前速度**继续，
   不能重置后重播。因此位移和缩放一律使用弹簧，不使用固定时长曲线。
3. **跟手。** 拖拽、抽屉、Sheet 关闭在指针移动时 1:1 跟随；松手后把指针速度交给弹簧。

### 动效词汇

| Token | 参数 | 用途 |
|---|---|---|
| `motion.snap` | 0.18s / bounce 0 | 按压缩放、开关、选中、悬停上浮、Sheet 进出 |
| `motion.move` | 0.32s / bounce 0 | 位移、重排、面板与页面切换 |
| `motion.arrive` | 0.38s / bounce 0.12 | 新对象到达、Dialog / Popover 打开 |
| `motion.settle` | 0.45s / bounce 0.18 | 完成时刻的收束，**全系统最大回弹** |
| `motion.exit` | 0.22s / bounce 0 | 离开：比进入更快 |
| `motion.color` | 120ms linear | 所有颜色与阴影变化 |
| `motion.hit` | 80ms 停顿 | 失败时的顿帧 |
| `motion.pulse` | 1.6s 周期 / 峰值 1.25 | 运行中状态点的低幅循环，**全系统唯一的循环** |

`bounce ≤ 0.18` 是“个性但不嘈杂”在动效上的量化边界。

### 平涂的时间维度

长时间的颜色交叉淡化，会在中间帧产生浑浊的混合色，相当于在时间上画了一段渐变。所以：

- **颜色与阴影变化 ≤ 120ms，或直接瞬切；**
- 动感来自形状、位置和尺度的弹簧运动，而不是颜色的慢速过渡。

### 状态节拍

从日式动画的 timing 与 hold（停顿帧）借来的状态转换节拍，全产品通用：

| 进入状态 | 节拍 |
|---|---|
| active（运行中） | 色块瞬切 → 状态点开始 `motion.pulse` 低幅循环 |
| completed | 标记缩小到 0.9 → `settle` 弹回 1 → **保持** |
| failed | `hit` 顿帧：颜色瞬切并停住 80ms → 静止。**不摇晃、不循环抖动** |
| waiting-user | 该区域所有循环停止。**静止本身就是信号** |
| paused | 循环在约 300ms 内减速到停，和 failed 的硬停形成对比 |

### 空间拓扑

全产品只有一种空间模型：

- 层级加深 = 内容从右侧推入，旧内容向左后退并淡出；返回完全反向。**这是唯一的返回动画。**
- 同级页面与标签页：**旧内容立即移除，新内容到达**。高频切换不能保留退场页：双页并存会在
  列宽变化时叠字，并造成空白闪动。到达的节拍全产品只有一种（`pc-enter`）：
  - 新页面的各块面板以 `{motion.arrive}` 从下方 `{spacing.md}` 处升起，按 `motion.stagger`
    错峰（最多 6 项）；
  - 透明度从 0.4 起步而不是 0，保证任何一帧都不出现空白页；
  - 导航的当前项指示块以 `{motion.move}` 从旧位置**滑到**新位置（shared layout），它是同一个
    对象在移动，不是两个状态的淡入淡出；文字颜色与指示块同帧切换，不做颜色过渡。
- 同一区域内的选择变化（例如 Inspector 换成另一条记录）使用同一到达节拍：面板位置不动，旧内容
  立即移除，新内容升起。
- Sheet 表示进入详情层级，以 `{motion.snap}` 从右侧推入并原路退出，拖拽回位使用同一弹簧。
- 浮层从触发源长出，关闭时收回触发源（transform-origin 取触发点）。

### 编排

- 列表与页面面板入场 stagger 每项 30ms，最多 6 项，其余与第 6 项同时出现。
- 同一时刻最多一组编排；页面切换时只编排主舞台，Inspector 与导航不再各自编排。
- 低于 300ms 的操作不显示加载态，避免闪烁。

### 实现约束

- 只对 `transform`、`opacity`、`clip-path` 做动画；布局变化使用 Motion 的 layout 动画
  （FLIP），不直接动画 `width`、`height`、`top`。
- 颜色过渡用 CSS `transition: background-color 120ms linear` 即可，不必交给弹簧。悬停上浮、
  按压缩放这类一次性过渡可以使用导出的 CSS 弹簧回退曲线。
- `prefers-reduced-motion: reduce` 时：位移改为瞬切，保留颜色和形状信号；吉祥物切换为
  静态姿势。状态仍必须完整可读。

---

## Feedback & Overlays

### 浮层只有四种

| 浮层 | 出现方式 | 用途 | 是否阻断 |
|---|---|---|---|
| **Popover** | 从锚点长出 | 菜单、选择器、补充说明 | 否 |
| **Sheet** | 从右侧边缘推入 | 详情、编辑、窄屏 Inspector、审批 | 否（审批时为局部阻断） |
| **Dialog** | 屏幕中央，`arrive` 进入，带 scrim | 只用于 `blocking`：不可逆操作、权限、安全 | 是 |
| **Toast** | 底部中央 | 仅限结果无法在对象上观察、且无需处理的短消息 | 否 |

每种浮层**全产品只有一种样式**：`{materials.glass}` + 1px `{colors.outline-subtle}` +
`{elevation.overlay}`（Dialog 用 `{elevation.dialog}`）。禁止为单个页面设计“特别的弹窗”。

### Toast 的使用条件

以下三条同时成立才可以使用 Toast：

1. 结果无法在操作对象上直接看到；
2. 不需要用户处理；
3. 消失后不会造成信息损失。

### 错误文案

必须依次回答：**发生了什么 → 影响了什么 → 现在能做什么**。错误码作为次级信息保留。

### 按钮

- 每个操作上下文只有一个 primary（品牌色实底、胶囊形、`{elevation.control}`），表示推荐的
  下一步。
- secondary 是白底胶囊 + `{colors.outline}` + `{elevation.control-surface}`；ghost 没有底色。
- 按钮文字使用动词短语，例如“重新授权并重试”，不写“确定”。
- 加载时保留按钮宽度和文字，在文字旁加状态点，不要只剩一个 Spinner。
- Disabled 必须说明原因（Tooltip 或旁注），并去掉阴影。
- 可撤销的普通操作不弹确认框：直接执行，并提供撤销。

---

## Mascot

吉祥物是首页的视觉中心和 Agent 的**身体**，参考 Grok Companion 的做法：它不是装饰插画，
而是一个**活的状态显示器**。

### 定位

- **只出现在首页舞台。** 常规操作区、列表、Inspector 和对话框中不出现吉祥物；那里使用
  墨色猫头标志或实体头像。
- 首页的视觉中心就是吉祥物，因此首页不再使用 `display` 级大标题与它争夺注意力。
- 移除吉祥物资源后，首页必须退化为“墨色猫头 + 状态点 + 当前任务文字”，信息结构不变。

### 造型

- **探头构图**：一颗大大的猫头从首页舞台的**底边**探出来，身体在舞台之外。吉祥物的底边
  与舞台底边重合，不浮空、不加底座、不加投影。
- **无线稿平涂**，参考 Grok Companion 的 Q 版头像：形体只靠色块区分，没有描边、渐变、
  高光和柔影。两颊外鼓的团子头、一对圆角三角耳、头顶一撮**闪电形呆毛**；脸上只有一对
  竖椭圆眼和腮红，没有鼻子、嘴和胡须。越少越可爱，也越不和界面争夺焦点。
- **常驻侧倾约 7°**：头顶偏向右侧的内容，像从角落探头张望；静止时也有生命感。姿势里的
  侧头在此基础上叠加。
- 固有色只有三种吉祥物专用色：`mascot-fur`（暖白毛）、`mascot-fur-shade`（内耳与头部
  右下的一块硬边赛璐璐阴影，用来撑起白色轮廓）、`mascot-blush`（腮红），都只允许出现在
  吉祥物内部。
- 白色的猫必须叠在有色底上（舞台的斜切色块或 `surface-sunken`），不得直接放在
  `surface` / `canvas` 上。
- 全身只有**眼睛**是状态色部位，颜色始终等于 Agent 当前状态的语义色：视线和状态色是同一个
  信号，用户看它在哪里，就同时知道它在做什么。
  - `idle` 时眼睛是纯墨色，整只猫没有任何语义色；
  - 等待类状态使用 `waiting-signal`（填色信号，不是文字色）。
- 没有尾巴。需要“慢摆尾巴”表达的思考，改为**视线上移 + 一只耳朵低幅抖动**。
- 轮廓剪影在 32px 时仍可识别（画廊有 32px 检查行）。

### 状态姿势

吉祥物只接收一个输入：Agent 状态。姿势与语义模型一一对应；同一颜色家族内的状态必须在
形体上也能区分，不只靠颜色。

| 状态 | 眼睛 | 视线 | 耳朵 | 运动 |
|---|---|---|---|---|
| `idle` | 睁开 | 正视 | 竖起 | 4–8 秒随机眨眼一次，算作首页唯一的持续运动 |
| `perceiving` | 睁开 | 看向输入来源 | 转向视线方向 | 一次转动后保持 |
| `reasoning` | 睁开 | 上移 | 竖起 | 一只耳朵低幅循环抖动 |
| `acting` | 睁开 | **看向行动路径的当前节点** | 竖起 | 视线跟随节点推进 |
| `waiting-external` | 睁开 | 看向外部对象 | 竖起，侧头 | 静止 |
| `waiting-user` | 睁开 | **正视用户** | 竖起 | 完全静止 |
| `warning` | 睁开 | 正视 | 向两侧半张开（警觉） | 静止 |
| `paused` | 闭眼 | — | 竖起 | 静止 |
| `completed` | 笑眼 | 正视 | 竖起 | `settle` 点头一次后静止 |
| `failed` | 半垂 | 下移 | 下压（飞机耳） | `hit` 瞬切后静止 |

视线是吉祥物最重要的表达：它看向哪里，用户的注意力就跟到哪里。`acting` 时看向行动路径，
`waiting-user` 时看向用户，本身就是因果提示。

### 实现

- 组件契约只有 `state` 和可选的 `gazeTarget`；资源格式可以替换（SVG + Motion、Rive 状态机
  或 Live2D），但不允许组件外部直接控制某个动作。
- 参考实现是手写分件 SVG + Motion（`Mascot`），姿势表 `POSES` 是上表的代码形式，修改任一方
  必须同步另一方；单元测试锁定表中的关键规则（只有 idle 眨眼、同家族姿势可区分等）。
- 姿势之间的切换遵守 Motion 一节的三条底线：连续（`move` 弹簧）、可打断（新状态从当前值
  接管）、跟手（视线跟随 `gazeTarget`，目标随布局动画移动时逐帧跟随一个弹簧时长）。
- 视线偏移随目标距离衰减，近处目标不会出现斗鸡眼；没有目标时有确定的默认方向。
- 眼睛保留实心眼与眼睑两层，用 `{motion.snap}` 收合、翻转和显隐衔接睁眼、闭眼与笑眼；
  视线先于头部落定，耳根使用固定的 SVG 坐标轴心，不能随眼睛或轮廓包围盒移动。
- 思考时的抖耳是“快速外拨 → 小幅反拨 → 弹簧归位”，耳廓随外拨略收窄，模拟耳根发力。
  首次等 `{motion.move}` 落定后触发，后续静候为 `{motion.pulse}` 周期的 2–4 倍随机值；
  定时器只安排静候，位移仍使用 `{motion.snap}` / `{motion.settle}`，禁止匀速摇摆。
- 完成点头先轻压再以 `{motion.settle}` 收束，只在进入完成状态时播放。切换状态或卸载时
  取消未完成的动作和计时，暂停时柔和归位，失败与等待用户时立即停止反射动作。
- `prefers-reduced-motion` 下只切换静态姿势：不眨眼、不抖耳、不点头、不播放过渡。

---

## Components

组件只接收**语义参数**，由组件内部决定颜色、图标、范围、材质和动效。

```tsx
// 推荐：调用方描述语义。
<Feedback
  state="failed"
  scope="object"
  urgency="actionable"
  persistence="until-resolved"
  title="微信授权已过期"
  actions={<Button>重新授权并重试</Button>}
/>

// 禁止：调用方拼装视觉。
<Notice color="red" popup shadow="large" />
```

参考实现位于 [react/](react/)（`@purrcept/cel-react`）。能在类型上排除的违规都在类型上排除：
`Feedback` 不接受 `blocking`，`actionable` 必须带操作，`until-resolved` 不能关闭；Toast 只接受
`completed` / `idle`；Button 没有 `disabled`，只有必须写明原因的 `disabledReason`。其他平台的
实现应保持相同的语义契约。

### StatusMark

状态的最小单元：状态点或图标 + 可选文字。它是全产品唯一的状态表达组件；状态芯片、步骤
节点、吉祥物眼睛的颜色都从它的状态映射中取值。

### Panel

三层结构中的第 1 层。surface + `{elevation.panel}` + `{rounded.xl}`，内边距 `{spacing.lg}`。

- 由标题（`title`）、可选的头部操作和内容组成；头部操作最多一个 primary。
- 面板之间不画线、不嵌套；面板内部的对象使用 `object-surface` 瓦片。
- 面板只表达区域，不表达状态：区域级的状态由 `Feedback scope="region"` 在面板内部铺背景场。

### NavRail

外壳的导航岛：`{materials.glass}` + `{elevation.panel}` + `{rounded.xl}`。

- 顶部是猫头标志，下面是 `nav-item` 图标按钮，配 Tooltip；当前项 `nav-item-current`。
- 导航图标只表达目的地，状态图标不得用于导航；需要提示待处理数量时使用墨色数字徽标，
  不使用状态色。

### ActionPath

把 Runtime 的行动链可视化：**实体 → 设备 → 应用 → 目标**。

- 节点使用实体头像或类别图标，下方是名称和一行状态。
- 已完成的连接是实线，进行中的连接以 `move` 弹簧推进，未开始的连接是虚线。
- 节点状态使用 StatusMark；当前节点是唯一被上色的节点，节点底座带 `{elevation.control-surface}`。
- 窄屏转为纵向，保留方向。

### Step List / Timeline

- 时间线的线和节点承担真实顺序。
- 节点颜色遵循状态表；当前步骤是唯一的 active 节点。
- 失败步骤按“部分失败”规则展开已发生 / 未发生 / 未知。

### Inspector

- 一块 Panel；顺序：身份与状态 → 关键属性 → 可执行操作 → 技术细节（默认折叠）。
- 选择变化时面板位置不动，旧详情立即移除，新详情以 `pc-enter` 的到达节拍升起（透明度从 0.4
  起步，不从全透明重新显现）。
- Inspector 内部依靠 `label` 小标题与间距分组；技术细节与上方内容之间可以用一条
  `outline-subtle` 分界线。

### ApprovalSheet

`requires_approval` 的唯一呈现方式。

- 从右侧 Sheet 推入；Agent 进入 `waiting-user`，首页吉祥物正视用户。
- 内容依次是：**谁** 要 **通过什么** 对 **谁 / 什么** 做 **什么**，以及风险等级和是否可逆。
- 操作：一个 primary（或 R3 时为 destructive）“允许并执行”，一个 secondary“拒绝”。
- 用户离开后，审批请求保留在待处理列表中，不会丢失。

### 列表与表格

- 列表与表格放在一块面板里；行是平面的，不把每行包装成卡片。
- 行高、前导图标、状态列和时间列建立扫描节奏；行之间用 `outline-subtle` 扫描线或悬停色阶。
- 数字右对齐，名称左对齐，状态列固定宽度。
- 行内展开附着在行下方，不弹出无关浮层。

### 空状态与加载

- 空状态说明这里会出现什么，并给一个下一步；可以使用 `brand-container` 的斜切色块，不使用
  大幅插画。
- 骨架屏必须接近真实结构，使用 surface-sunken 平涂块，不使用闪光渐变。
- 有真实进度时显示进度条，否则显示阶段和当前动作。

### 文案

- 标题说明“这是什么”，辅助文案说明“为什么”，按钮说明“做什么”。
- 行为可归因：写“正在通过手机打开微信”，不写“处理中”。
- 外部等待指明对象：写“等待微信返回授权结果”，不写“请稍候”。

### 无障碍

- 状态至少使用颜色、形状、文字中的两种；失败和等待用户三种都用。
- 所有交互对象都有可见的品牌色焦点环（2px `{colors.focus-ring}`，偏移 2px）。
- 命中区域 ≥ `{spacing.touch-target}`。
- 状态变化通过 ARIA live 区域通知，但不逐条朗读高频日志。
- 玻璃与背景美术上的文字必须达到 4.5:1；开启“减少透明度”时，玻璃退化为 surface。

---

## Governance

“绝不允许多套表现”只有在工程上被约束时才能成立。

1. **语义 props 强制。** 公共组件不接受 `color`、`shadow`、`radius` 这类视觉参数。
2. **禁止裸值。** 样式中出现 Token 之外的颜色、圆角、阴影、时长、渐变、模糊时，lint 报错。
3. **唯一实现。** 浮层、返回动画、StatusMark、Feedback、玻璃材质各只有一个实现；新需求先
   扩展语义，再扩展组件。React 参考组件的样式与画廊本身必须零违规、零豁免地通过样式 lint。
4. **新增 Token 需要语义理由。** 不接受“更好看的蓝”“另一种卡片”“再来一种玻璃”。
5. **视觉回归。** 每个状态 × 每个 scope 的组合都要有快照。

### Token 管线

文件头 YAML 是唯一规范值，由 `scripts/export_tokens.py` 导出到 `dist/`：

| 产物 | 用途 |
|---|---|
| `purrcept.css` | `--pc-*` CSS 变量；弹簧附带 `linear()` 回退曲线；减少动效时清零位移时长 |
| `motion.js` / `motion.d.ts` | Motion 预设：`motion.*`、`holds`、`stagger`、`staggerDelay()`、`transition()` |
| `tokens.json` | 完全解析后的值，供设计工具与截图测试使用 |

导出前，脚本会把以下规范作为硬约束检查，任何一项不通过都拒绝导出：

- 组件的颜色、字体、圆角必须引用 Token（禁止裸值），且引用必须存在、组别正确；
- 弹簧 `bounce ≤ 0.18`；tween 只用于颜色，时长 ≤ 120ms；
- `contrast` 段声明的文字 × 背景组合、全部 `on-*` 配对、组件的文字 / 背景都 ≥ 4.5:1；
- 阴影：外阴影必须与 `colors.ink` 同 RGB 且不透明度 ≤ 0.24；inset 只能是墨色或纯白；
- 渐变：只允许 `linear-gradient` / `radial-gradient`；色标只能引用 `contrast.backgrounds` 中的
  颜色或 `transparent`，不能出现颜色字面量；
- 材质：底色必须引用 rgba 颜色 Token 且不透明度 ≥ 0.7；模糊 8–40px；饱和度 1–2；底色叠在
  canvas 上的合成色必须让 `contrast.text` 全部 ≥ 4.5:1；
- 未知字段、非 kebab-case 的 Token 名一律拒绝。

CSS 的弹簧回退曲线**不可打断**，只适合悬停、按压这类一次性过渡；会被用户中途反向操作的
位移必须使用 `motion.js`。

### 样式 lint

`scripts/lint_styles.py` 在使用方的 `.css`、HTML `<style>` 块和 `style` 属性中强制“禁止裸值”：

| 规则 | 名称 | 拒绝 |
|---|---|---|
| PC001 | raw-color | 十六进制、`rgb()` / `hsl()` / `oklch()` 等颜色函数、颜色名、颜色属性中的局部变量 |
| PC002 | raw-radius | 非零圆角长度、圆角属性中的局部变量 |
| PC003 | raw-shadow | 不是 `--pc-shadow-*` 或 `none` 的阴影、`drop-shadow()` |
| PC004 | raw-motion | 动效属性中的时长字面量、缓动关键字与 `cubic-bezier()` / `steps()` / `linear()` |
| PC005 | forbidden-material | 渐变字面量（请用 `--pc-gradient-*`）、不是 `--pc-material-*-filter` 的 `backdrop-filter`、`filter: blur()` |
| PC006 | token-override | 在使用方声明 `--pc-*` |
| PC007 | unknown-token | 引用不存在的 `--pc-*` |
| PC000 | directive | 缺少理由、规则未知或已经不再生效的豁免 |

受治理属性中的**局部变量**同样被拒绝：`--accent: var(--pc-color-active)` 这样的别名就是
一套私有视觉值，正是规范要消灭的东西。

背景美术与玻璃的正确写法：

```css
.app {
  background-color: var(--pc-color-canvas);
  background-image: var(--pc-gradient-atmosphere);
}
.nav-rail {
  background: var(--pc-material-glass-background);
  backdrop-filter: var(--pc-material-glass-filter);
}
```

确有正当理由时（例如热力图用渐变编码连续数据），在上一行写带理由的豁免：

```css
/* purrcept-lint-disable-next-line PC005 -- 热力图用渐变编码连续数值 */
background: linear-gradient(90deg, var(--pc-color-canvas), var(--pc-color-active));
```

HTML 属性使用 `<!-- purrcept-lint-disable-next-line PC002 -- 理由 -->`。lint 不检查间距与
字号，也不扫描 JS 中的内联样式；这些由评审和交付前检查负责。

---

## Do's and Don'ts

### Do

- 先确定页面的主任务、主对象和下一步操作，再决定分成哪几块面板。
- 让每一处语义色都对应一个状态，让每一处品牌色都对应一个可操作的东西。
- 用浮起的面板和间隙划分区域，在面板内部用距离、对齐和色阶分组。
- 把反馈附着在受影响对象上，面积与范围一致。
- 位移和缩放使用弹簧，颜色变化干脆利落。
- 失败时同时展示已发生、未发生和未知的部分。
- 关闭吉祥物、减少动效、减少透明度、200% 文本缩放后，页面依然完整可用。

### Don't

- 不要用品牌蓝表达“运行中”或任何状态，也不要用语义色做按钮、链接、导航或品牌。
- 不要让所有内容漂浮在一张白纸上；也不要用“左侧导航 + 顶部标题 + 均匀统计卡片矩阵”的
  后台模板交差。
- 不要面板套面板、卡片套卡片，也不要在面板之间再加分界线。
- 不要在内容区使用渐变或玻璃；不要使用彩色阴影、外发光或梦幻渐变。
- 不要为单个页面设计特别的弹窗、返回动画、状态词或玻璃。
- 不要用摇晃表达错误，也不要让任何错误循环抖动。
- 不要对局部错误弹出 Dialog，也不要在局部加载时锁住整页。
- 不要让吉祥物出现在首页以外的操作区域。
- 不要伪造进度百分比。

### 交付前检查

1. 缩到 25% 时，能否看出哪里在运行、哪里出错？
2. 屏幕上的每一处语义色是否都是状态？品牌色是否都在可操作的东西上？
3. 是否只有一个视觉中心、一处持续运动、每个上下文一个 primary？
4. 每块面板能否用一个名词说出职责？叠放是否不超过三层？面板之间是否没有分界线？
5. 局部反馈是否停留在局部？
6. 失败是否说明原因、影响和下一步，并区分已发生 / 未发生 / 未知？
7. 动画中途反向操作，是否从当前位置继续？
8. 所有视觉值是否来自 Token？渐变与玻璃是否只出现在背景美术、导航与浮层？
9. 减少动效、减少透明度、键盘操作、窄屏、无吉祥物资源时是否仍可用？
