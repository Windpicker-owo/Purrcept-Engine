---
version: 0.4.0
name: Purrcept Cel
description: "Purrcept 系列跨端视觉与交互语言：清透学园赛璐璐主调融合暖调陪伴手账；实线描边与零模糊硬投影塑造原画质感，弹簧物理承载鲜活生命感。"
colors:
  # 清透学园场：主舞台与日常交互底色
  canvas: "#F4F8FD"
  atmosphere-sky: "#E3F0FF"
  atmosphere-peach: "#FFEFE8"
  surface: "#FFFFFF"
  surface-sunken: "#ECF3FA"
  surface-selected: "#DCEBFF"
  # 暖调手账场：记忆、随笔与角色设定专属纸面
  paper: "#FFFDF8"
  paper-sunken: "#F7F1E6"
  paper-blush: "#FFF0EC"
  # 浮层轻透底色：只通过 materials.glass 使用，只给导航轨与浮层
  glass: "rgba(255, 255, 255, 0.88)"
  # 深靛赛璐璐墨线与手账可可墨色
  ink: "#182232"
  ink-secondary: "#3D4B63"
  ink-muted: "#53627A"
  ink-warm: "#5C4B43"
  ink-disabled: "#9BA8BC"
  on-ink: "#FFFFFF"
  outline: "#C5D4E8"
  outline-subtle: "#DFE9F5"
  outline-paper: "#E6D9C8"
  focus-ring: "#0B5ED7"
  scrim: "rgba(24, 34, 50, 0.36)"
  # 硬边投影专用色块
  cel-shadow-sky: "#C7DDF8"
  cel-shadow-paper: "#E6D7C3"
  # 品牌色：清透澄空蓝（brand 保正文对比度，brand-signal 负责高明度青春感点缀）
  brand: "#0B5ED7"
  brand-fill: "#1A73E8"
  brand-hover: "#1562C9"
  brand-pressed: "#0E4FA8"
  brand-signal: "#29A8FF"
  on-brand: "#FFFFFF"
  brand-container: "#DCEBFF"
  on-brand-container: "#0A439C"
  # 陪伴手账点缀：蜜桃腮红与和纸胶带琥珀
  blush-signal: "#FF8A7A"
  blush-container: "#FFE6E0"
  on-blush-container: "#8C2D19"
  tape-signal: "#F5B547"
  tape-container: "#FDECC8"
  on-tape-container: "#6E4200"
  # 语义五态色：只允许表达状态，禁止用于装饰或普通交互
  active: "#086A78"
  active-signal: "#12B5CB"
  active-container: "#D6F4F7"
  on-active-container: "#064E59"
  success: "#116E3A"
  success-signal: "#22C55E"
  success-container: "#DEF5E7"
  on-success-container: "#0D542B"
  waiting: "#944B00"
  waiting-signal: "#F59E0B"
  waiting-container: "#FDEFD6"
  on-waiting-container: "#693500"
  failed: "#BA2D25"
  failed-signal: "#F43F5E"
  failed-hover: "#9E241D"
  failed-pressed: "#851D17"
  failed-container: "#FCE6E4"
  on-failed-container: "#851D17"
  paused: "#6842C2"
  paused-signal: "#8B5CF6"
  paused-container: "#EDE7FC"
  on-paused-container: "#3E218A"
  # 吉祥物固有色（与 paper / blush 形成跨次元呼应）
  mascot-fur: "#FFFDF9"
  mascot-fur-shade: "#EAE0D5"
  mascot-blush: "#FFB5AA"
typography:
  display:
    fontFamily: '"Resource Han Rounded CN", "M PLUS Rounded 1c", "MiSans", "HarmonyOS Sans SC", sans-serif'
    fontSize: 44px
    fontWeight: 700
    lineHeight: 1.12
    letterSpacing: -0.02em
  headline:
    fontFamily: '"Resource Han Rounded CN", "M PLUS Rounded 1c", "MiSans", "HarmonyOS Sans SC", sans-serif'
    fontSize: 26px
    fontWeight: 700
    lineHeight: 1.25
    letterSpacing: -0.01em
  title:
    fontFamily: '"MiSans", "HarmonyOS Sans SC", "Plus Jakarta Sans", "PingFang SC", sans-serif'
    fontSize: 17px
    fontWeight: 700
    lineHeight: 1.45
  body:
    fontFamily: '"MiSans", "HarmonyOS Sans SC", "Plus Jakarta Sans", "PingFang SC", sans-serif'
    fontSize: 14px
    fontWeight: 400
    lineHeight: 1.6
  body-long:
    fontFamily: '"MiSans", "HarmonyOS Sans SC", "Plus Jakarta Sans", "PingFang SC", sans-serif'
    fontSize: 15px
    fontWeight: 400
    lineHeight: 1.65
    letterSpacing: 0.01em
  label:
    fontFamily: '"MiSans", "HarmonyOS Sans SC", "Plus Jakarta Sans", "PingFang SC", sans-serif'
    fontSize: 13px
    fontWeight: 600
    lineHeight: 1.4
    letterSpacing: 0.01em
  caption:
    fontFamily: '"MiSans", "HarmonyOS Sans SC", "Plus Jakarta Sans", "PingFang SC", sans-serif'
    fontSize: 12px
    fontWeight: 500
    lineHeight: 1.4
    letterSpacing: 0.01em
  hud:
    fontFamily: '"JetBrains Mono", "Geist Mono", "SFMono-Regular", Consolas, monospace'
    fontSize: 12px
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: 0.06em
    fontFeature: '"tnum" 1, "zero" 1'
  mono:
    fontFamily: '"JetBrains Mono", "Geist Mono", "SFMono-Regular", Consolas, monospace'
    fontSize: 13px
    fontWeight: 500
    lineHeight: 1.55
    fontFeature: '"tnum" 1, "zero" 1'
rounded:
  none: 0px
  xs: 6px
  sm: 10px
  md: 14px
  lg: 20px
  xl: 28px
  full: 9999px
spacing:
  base: 4px
  xxs: 4px
  xs: 8px
  sm: 12px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
  4xl: 96px
  gutter: 32px
  gutter-narrow: 16px
  island-gap: 14px
  sidebar: 76px
  inspector: 368px
  content-max: 1600px
  touch-target: 44px
breakpoints:
  navigation: 768px
  inspector: 1152px
  workspace: 960px
elevation:
  # 零模糊赛璐璐硬边阴影：所有阴影模糊半径必须为 0，实色硬投影引用 colors.*，半透明硬投影只用墨色
  well: "inset 0 2px 0 rgba(24, 34, 50, 0.05)"
  control: "0 3px 0 0 {colors.brand-pressed}"
  control-pressed: "0 1px 0 0 {colors.brand-pressed}"
  control-surface: "0 3px 0 0 {colors.cel-shadow-sky}"
  control-surface-pressed: "0 1px 0 0 {colors.cel-shadow-sky}"
  destructive: "0 3px 0 0 {colors.failed-pressed}"
  destructive-pressed: "0 1px 0 0 {colors.failed-pressed}"
  panel: "3px 4px 0 0 {colors.cel-shadow-sky}"
  notebook: "3px 4px 0 0 {colors.cel-shadow-paper}"
  sticker: "3px 3px 0 0 {colors.ink}"
  lifted: "4px 6px 0 0 {colors.cel-shadow-sky}"
  overlay: "6px 8px 0 0 rgba(24, 34, 50, 0.14)"
  dialog: "8px 10px 0 0 rgba(24, 34, 50, 0.22)"
gradients:
  atmosphere: "radial-gradient(58% 52% at 0% 0%, {colors.atmosphere-sky} 0%, transparent 100%), radial-gradient(52% 48% at 100% 0%, {colors.atmosphere-peach} 0%, transparent 100%)"
  stage: "linear-gradient(118deg, {colors.surface} 42%, {colors.atmosphere-sky} 100%)"
  notebook-header: "linear-gradient(180deg, {colors.paper-blush} 0%, {colors.paper} 100%)"
materials:
  glass: { tint: "{colors.glass}", blur: 16px, saturate: 1.4 }
motion:
  snap:   { type: spring, visualDuration: 0.18, bounce: 0.06 }
  move:   { type: spring, visualDuration: 0.30, bounce: 0.04 }
  arrive: { type: spring, visualDuration: 0.36, bounce: 0.14 }
  settle: { type: spring, visualDuration: 0.44, bounce: 0.18 }
  exit:   { type: spring, visualDuration: 0.20, bounce: 0 }
  color:  { type: tween, duration: 0.10, ease: linear }
  hit:    { type: hold, duration: 0.08 }
  pulse:  { type: loop, duration: 1.6, scale: 1.25 }
  defer:  { type: threshold, duration: 0.3 }
  linger: { type: threshold, duration: 0.4 }
  resist: { type: elastic, factor: 0.08 }
  stagger: 0.03
  stagger-max-items: 6
contrast:
  minimum: 4.5
  text: [ink, ink-secondary, ink-muted, ink-warm, brand, active, success, waiting, failed, paused]
  backgrounds: [canvas, surface, surface-sunken, surface-selected, paper, paper-sunken, paper-blush, atmosphere-sky, atmosphere-peach]
components:
  button-primary:
    backgroundColor: "{colors.brand-fill}"
    textColor: "{colors.on-brand}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    height: 38px
    padding: "0 18px"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    outline: "{colors.outline}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    height: 38px
    padding: "0 18px"
  button-ghost:
    backgroundColor: transparent
    textColor: "{colors.ink-secondary}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    height: 38px
    padding: "0 12px"
  button-destructive:
    backgroundColor: "{colors.failed}"
    textColor: "{colors.on-ink}"
    typography: "{typography.label}"
    rounded: "{rounded.full}"
    height: 38px
    padding: "0 18px"
  input:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    outline: "{colors.outline}"
    typography: "{typography.body}"
    rounded: "{rounded.md}"
    height: 42px
    padding: "0 14px"
  nav-item:
    backgroundColor: transparent
    textColor: "{colors.ink-muted}"
    rounded: "{rounded.md}"
    size: 46px
  nav-item-current:
    backgroundColor: "{colors.brand-container}"
    textColor: "{colors.on-brand-container}"
    rounded: "{rounded.md}"
    size: 46px
  panel:
    backgroundColor: "{colors.surface}"
    outline: "{colors.outline-subtle}"
    rounded: "{rounded.xl}"
    padding: "{spacing.lg}"
  notebook-sheet:
    backgroundColor: "{colors.paper}"
    outline: "{colors.outline-paper}"
    rounded: "{rounded.lg}"
    padding: "{spacing.lg}"
  object-surface:
    backgroundColor: "{colors.surface-sunken}"
    rounded: "{rounded.lg}"
    padding: "{spacing.md}"
  stage-field:
    backgroundColor: "{colors.surface}"
    outline: "{colors.outline}"
    rounded: "{rounded.xl}"
    padding: "{spacing.xl}"
  status-mark:
    size: 8px
    rounded: "{rounded.full}"
  status-chip:
    typography: "{typography.caption}"
    rounded: "{rounded.full}"
    height: 26px
    padding: "0 10px"
  progress-track:
    backgroundColor: "{colors.outline-subtle}"
    rounded: "{rounded.full}"
    height: 6px
  tooltip:
    backgroundColor: "{colors.ink}"
    textColor: "{colors.on-ink}"
    typography: "{typography.caption}"
    rounded: "{rounded.sm}"
    padding: "6px 10px"
---

# Purrcept Cel

## Overview

Purrcept 是一个专注于**年轻化、二次元陪伴型 AI Bot**（以核心角色“杰瑞喵”为代表）的项目。
`Purrcept Cel 0.4` 以**清透学园风（Seishun Stage）**为主基调，并在记忆、随笔与日常回顾模块
自然融入**暖调手账风（Cozy Notebook）**：

> **白昼是清透的赛璐璐学园日常，翻开记忆是带着体温的手账桌角。**
>
> 实线描边与零模糊硬投影塑造原画质感，可打断弹簧承载鲜活生命感。

> **交互用澄空蓝，陪伴融暖纸，状态归五色。**
>
> 文本色严守 WCAG AA 可读底线，高明度信号色点亮番剧镜头感。

### 双生场域模型（Dual-Zone Surface Model）

| 场域 | 适用模块 | 气质锚点 | 核心 Token |
|---|---|---|---|
| **清透学园场** | 首页舞台、即时对话、设备连接、行动时间线、设置 | 明亮、通透、青春番剧感 | `{colors.canvas}` + `{colors.surface}` + `{colors.brand-signal}` + `{elevation.panel}` |
| **暖调手账场** | 记忆手账（Notebook）、日常随笔、角色人设卡 | 温暖、亲密、纸张与胶带触感 | `{colors.paper}` + `{colors.paper-sunken}` + `{colors.blush-signal}` + `{elevation.notebook}` |

---

## Semantics

状态集合与 Purrcept 主体运行时一一对应，归入五个语义色彩家族（`neutral`、`active`、
`waiting`、`paused`、`success`、`failed`）。

| 状态 | 色彩家族 | 形状信号 | 运动 | 用户应理解为 |
|---|---|---|---|---|
| `idle` | neutral | 空心圆环 | 静止（首页吉祥物 4–8 秒眨眼） | 在线待命，当前没有后台任务 |
| `perceiving` | active | 实心点 | `motion.pulse` 低幅循环 | 正在接收或倾听输入 |
| `reasoning` | active | 实心点 | `motion.pulse` 低幅循环 | 正在思考与组织回应 |
| `acting` | active | 实心点 | `motion.pulse` 低幅循环 | 正在操作设备、应用或手账 |
| `waiting-external` | waiting | 时钟 | 静止 | 在等待外部服务响应 |
| `waiting-user` | waiting | 人形 | **全部静止** | 等你拿主意或确认 |
| `warning` | waiting | 三角 | 静止 | 可继续运行，但需留意异常 |
| `paused` | paused | 双竖线 | 收束至停 | 已暂停，保留现场 |
| `completed` | success | 勾 | `motion.settle` 收束后静止 | 已完成，回执可核对 |
| `failed` | failed | 叉 | `motion.hit` 顿帧后静止 | 已停止，区分已发生与未发生 |

- 反馈函数保持 `呈现 = f(状态, 作用范围, 紧迫度, 持续性)`；风险等级由 `EffectKind` 推导（R0–R3）；
  部分失败必须通过 `OutcomeList` / `PartialFailure` 如实列出已发生、结果未知与未发生。

---

## Colors

### 文本安全色与高明度信号色双轨制

为了兼顾 WCAG AA（≥ 4.5:1）可读性与二次元清透高明度色彩，`Purrcept Cel 0.4` 将色彩拆分为：

1. **文本安全色**（列入 `contrast.text`）：`{colors.ink}`、`{colors.ink-secondary}`、`{colors.ink-muted}`、
   `{colors.ink-warm}`、`{colors.brand}` 及五态文本色，对全部 9 种浅色背景（`canvas`、`surface`、
   `surface-sunken`、`surface-selected`、`paper`、`paper-sunken`、`paper-blush`、`atmosphere-sky`、
   `atmosphere-peach`）对比度均 ≥ 4.8:1。
2. **图形信号色**（`*-signal`）：`{colors.brand-signal}`（天青）、`{colors.blush-signal}`（蜜桃腮红）、
   `{colors.tape-signal}`（和纸胶带琥珀）及五态信号色，专用于非正文图形、徽章边线、进度条、
   胶带装饰与吉祥物眼睛。

### 深靛墨线与手账暖纸

- `{colors.ink}` 采用深靛蓝墨色（`#182232`）替代死黑，使实线描边与硬投影呈现赛璐璐动画原画的通透感。
- `{colors.paper}`（`#FFFDF8`）与吉祥物毛色 `{colors.mascot-fur}`（`#FFFDF9`）同源，配合
  `{colors.paper-blush}` 与 `{colors.tape-container}`，打破角色与外部界面的次元壁。

---

## Typography

- **圆体标题栈**（`display`、`headline`）：优先使用 `"Resource Han Rounded CN"`、`"M PLUS Rounded 1c"`，
  回退至 `"MiSans"` 与 `"HarmonyOS Sans SC"`，赋予角色名、状态主句与手账标题鲜明的亲和力与萌感。
- **清透正文栈**（`title`、`body`、`body-long`、`label`、`caption`）：优先 `"MiSans"`、
  `"HarmonyOS Sans SC"` 与几何英文 `"Plus Jakarta Sans"`，剔除 `Microsoft YaHei` 回退。
- **机能装饰与代码栈**（`hud`、`mono`）：`"JetBrains Mono"` 开启表格数字与斜杠零，其中 `hud`
  专用于大写英文番剧眉标（如 `STAGE // 01`、`COMPANION LINK`）。
- 每条使用 `font` 简写的 CSS 规则必须同时声明 `font-variant-numeric: tabular-nums`（`PC008` 守护）。

---

## Elevation & Depth：零模糊赛璐璐硬边阴影

`Purrcept Cel 0.4` **全面禁止模糊弥散阴影**：`elevation` 中每一层阴影的模糊半径（blur）必须为 `0`，
由导出脚本机器强制检查：

- **学园场面板**使用 `{colors.outline-subtle}` 实线描边配 `{elevation.panel}`（冰蓝硬偏移投影 `{colors.cel-shadow-sky}`）。
- **手账场面板**（`Panel surface="notebook"`）使用 `{colors.outline-paper}` 描边配 `{elevation.notebook}`（暖卡纸硬投影 `{colors.cel-shadow-paper}`）。
- **焦点贴纸**使用 `{colors.ink}` 描边配 `{elevation.sticker}`，每屏最多 1–2 处。
- **物理吃阴影按压反馈**：实底与次级按钮默认带 `3px` 硬底座（`{elevation.control}` /
  `{elevation.control-surface}` / `{elevation.destructive}`），按压时沿 Y 轴下移 `2px` 并切换为 `1px`
  压实阴影（`*-pressed`），做出清脆的机械触底感。

---

## Shapes & Patterns

- **基础圆角**：`{rounded.xs}`（6px）、`{rounded.sm}`（10px）、`{rounded.md}`（14px）、
  `{rounded.lg}`（20px）、`{rounded.xl}`（28px）、`{rounded.full}`。
- **复合不对称造型**（导出为 `--pc-shape-*`）：
  - `--pc-shape-bubble-agent`：左上 `xs` 小尖角、其余三角 `lg`，专用于角色回复气泡；
  - `--pc-shape-bubble-user`：右下 `xs` 小尖角、其余三角 `lg`，专用于用户消息气泡；
  - `--pc-shape-note-tab`：右下 `xs` 微折角，专用于手账便签卡。
- **内置底纹**（导出为 `--pc-pattern-*`）：`--pc-pattern-halftone`（学园半调圆点阵）与
  `--pc-pattern-notebook-grid`（手账方格内页线）。
- **舞台破界规则**：首页舞台外框允许探头吉祥物的耳尖与呆毛向上突破上边缘，斜切背景板在独立内层裁剪。

---

## Governance

1. `DESIGN.md` 文件头是唯一 Token 真理源，`scripts/export_tokens.py` 严格校验：
   - 所有文本 × 背景配对及组件文字/背景对比度 ≥ 4.5:1；
   - 所有阴影模糊半径必须为 `0`（禁止弥散灰影），颜色必须引用 `{colors.*}` 或合规墨色/白色 `rgba()`；
   - 弹簧 `bounce ≤ 0.18`，颜色过渡 `≤ 120ms`。
2. `scripts/lint_styles.py` 强制禁止颜色、圆角、阴影、动效裸值（`PC001`–`PC008`），支持多值
   `--pc-radius-*` / `--pc-shape-*` 圆角组合与 `--pc-pattern-*` 底纹变量；参考组件与画廊必须零违规、零豁免。
