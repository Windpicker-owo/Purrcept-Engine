"""LiteLLM provider integration for Purrcept Core."""

from .backend import CompletionCallable, LiteLLMBackend
from .config import PROVIDER_OPTIONS_KEY, LiteLLMConfig
from .decision import DecisionCallable, LiteLLMDecisionBackend, LiteLLMDecisionConfig
from .errors import map_litellm_error
from .observability import (
    LiteLLMOpenTelemetryCallback,
    LiteLLMOpenTelemetryCompatibilityError,
    LiteLLMOpenTelemetryConfig,
    LiteLLMOpenTelemetryDependencyError,
    LiteLLMOpenTelemetryError,
    OpenTelemetryCaptureMode,
    OpenTelemetryExporter,
    create_opentelemetry_callback,
)

__version__ = "0.2.1"

__all__ = [
    "PROVIDER_OPTIONS_KEY",
    "CompletionCallable",
    "DecisionCallable",
    "LiteLLMBackend",
    "LiteLLMConfig",
    "LiteLLMDecisionBackend",
    "LiteLLMDecisionConfig",
    "LiteLLMOpenTelemetryCallback",
    "LiteLLMOpenTelemetryCompatibilityError",
    "LiteLLMOpenTelemetryConfig",
    "LiteLLMOpenTelemetryDependencyError",
    "LiteLLMOpenTelemetryError",
    "OpenTelemetryCaptureMode",
    "OpenTelemetryExporter",
    "__version__",
    "create_opentelemetry_callback",
    "map_litellm_error",
]
