"""Shared validation for runtime-owned transport settings."""

from math import isfinite


def validate_optional_string(value: object, *, field_name: str) -> None:
    """Validate an optional explicit connection identifier."""
    if value is None:
        return
    if not isinstance(value, str):
        raise TypeError(f"{field_name} must be a string or None.")
    if not value:
        raise ValueError(f"{field_name} must not be empty.")


def validate_timeout(value: object) -> None:
    """Require a finite positive request timeout when configured."""
    if value is None:
        return
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise TypeError("timeout must be a number or None.")
    if not isfinite(value):
        raise ValueError("timeout must be finite.")
    if value <= 0:
        raise ValueError("timeout must be greater than zero.")
