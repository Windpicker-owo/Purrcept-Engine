"""Execute Core model requests through LiteLLM Chat Completions.

This module owns the :class:`LiteLLMBackend` boundary and the lifecycle of one
invocation, not provider selection, callback construction, or callback exporter
shutdown.  A request is compiled by :mod:`purrcept_litellm._request`, executed
through the selected asynchronous completion callable, converted by
:mod:`purrcept_litellm._response`, and mapped onto Core errors when necessary.

The default LiteLLM SDK path additionally joins only the request-local callback
hooks it supplied.  This ordering is essential for short-lived event loops:
LiteLLM detaches async success logging, so returning earlier could cancel span
creation before an owning runtime can flush the exporter.  Injected completion
callables remain borrowed test or embedding seams and are not assumed to use
LiteLLM's background callback scheduler.
"""

from __future__ import annotations

import asyncio
import inspect
from collections.abc import AsyncIterable, Awaitable, Callable, Mapping, Sequence
from importlib import import_module
from typing import NoReturn, Protocol, cast

from purrcept_core.models import (
    JsonValue,
    ModelEventSink,
    ModelRequest,
    ModelResponse,
    ModelStreamCompleted,
    ModelStreamEvent,
)

from ._callbacks import RequestCallbackCompletion, event_callback, snapshot_callbacks
from ._request import compile_request
from ._response import StreamAccumulator, convert_response, synthetic_stream_events
from .config import LiteLLMConfig
from .errors import map_litellm_error


class CompletionCallable(Protocol):
    """An injected LiteLLM-compatible asynchronous completion function."""

    def __call__(self, **kwargs: object) -> Awaitable[object]:
        """Return a final response or async stream wrapper."""

        ...


class LiteLLMBackend:
    """Use LiteLLM Chat Completions as a unified Purrcept model backend.

    Runtime-owned callbacks are snapshotted when the backend is created. Every
    invocation receives fresh ``success_callback`` and ``failure_callback``
    lists because LiteLLM consumes and mutates those request-local lists while
    classifying synchronous and asynchronous callback hooks. The backend never
    registers callbacks in LiteLLM's process-global callback collections.
    """

    __slots__ = ("_await_callback_completion", "_callbacks", "_completion", "_config")

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        api_version: str | None = None,
        timeout: float | None = None,
        allow_strict_prompt_cache: bool = False,
        default_options: Mapping[str, JsonValue] | None = None,
        callbacks: Sequence[object] = (),
        completion: CompletionCallable | None = None,
    ) -> None:
        self._config = LiteLLMConfig(
            api_key=api_key,
            api_base=api_base,
            api_version=api_version,
            timeout=timeout,
            allow_strict_prompt_cache=allow_strict_prompt_cache,
            default_options={} if default_options is None else default_options,
        )
        self._callbacks = snapshot_callbacks(callbacks)
        selected = _default_completion if completion is None else completion
        if not callable(cast(object, selected)):
            raise TypeError("completion must be an asynchronous callable or None.")
        self._completion = cast(CompletionCallable, selected)
        # The injected completion seam is borrowed test/embedding code and may
        # not implement LiteLLM's callback scheduler. The built-in completion is
        # the boundary whose detached worker lifecycle this backend must join.
        self._await_callback_completion = completion is None

    @property
    def config(self) -> LiteLLMConfig:
        """Return the immutable backend configuration."""

        return self._config

    @property
    def callbacks(self) -> tuple[object, ...]:
        """Return the immutable callbacks attached to every model invocation."""

        return self._callbacks

    async def generate(
        self,
        request: ModelRequest,
        *,
        model: str,
        emit: ModelEventSink | None = None,
    ) -> ModelResponse:
        """Compile, execute, and convert one model request."""

        # Always stream. Non-streaming Chat Completions often idle-timeout on
        # long generations; a caller without ``emit`` still receives the
        # assembled ``ModelResponse`` after the iterator is exhausted.
        payload = compile_request(
            request,
            model=model,
            config=self._config,
        )
        callback_completion = (
            RequestCallbackCompletion(self._callbacks)
            if self._callbacks and self._await_callback_completion
            else None
        )
        abandon_callbacks = (
            callback_completion.abandon
            if callback_completion is not None
            else _ignore_callback_completion
        )
        if callback_completion is not None:
            payload["success_callback"] = callback_completion.success_callbacks
            payload["failure_callback"] = callback_completion.failure_callbacks
        elif self._callbacks:
            # Compatibility: LiteLLM currently partitions callbacks by mutating
            # these lists. Fresh copies preserve backend ownership and prevent a
            # concurrent or previous request from changing later instrumentation.
            # Its async completion path also classifies a CustomLogger instance
            # inconsistently between success and failure. Selecting its concrete
            # event hooks here keeps both paths request-scoped and executable.
            payload["success_callback"] = [
                event_callback(callback, method_name="async_log_success_event")
                for callback in self._callbacks
            ]
            payload["failure_callback"] = [
                event_callback(callback, method_name="log_failure_event")
                for callback in self._callbacks
            ]
        try:
            try:
                raw = await self._completion(**payload)
            except Exception as error:
                _raise_mapped(error, model=model)

            if isinstance(raw, AsyncIterable):
                sink = emit if emit is not None else _discard_stream_event
                return await _consume_stream(
                    cast(AsyncIterable[object], raw),
                    emit=sink,
                    model=model,
                    abandon_callbacks=abandon_callbacks,
                )

            response = convert_response(raw, requested_model=model, emit=emit)
            if emit is not None:
                for event in synthetic_stream_events(response):
                    emit(event)
            return response
        except (asyncio.CancelledError, KeyboardInterrupt, SystemExit):
            # Lifecycle: process or task termination may stop LiteLLM before it
            # can schedule either terminal callback. Releasing only our barrier
            # preserves that control-flow signal across every invocation phase.
            abandon_callbacks()
            raise
        finally:
            if callback_completion is not None:
                # Lifecycle: LiteLLM 1.94 dispatches successful SDK callbacks
                # through a detached global logging worker. Awaiting our
                # request-owned barriers keeps the callback on this event loop
                # without inspecting or mutating that global worker.
                await callback_completion.wait()


def _ignore_callback_completion() -> None:
    """Provide a uniform abandonment hook when no callback barrier exists."""


def _discard_stream_event(event: ModelStreamEvent) -> None:
    """Drop stream events when the caller only wants the assembled response."""

    del event


async def _default_completion(**kwargs: object) -> object:
    module = import_module("litellm")
    raw_function: object = module.__dict__["acompletion"]
    function = cast(Callable[..., Awaitable[object]], raw_function)
    return await function(**kwargs)


async def _consume_stream(
    stream: AsyncIterable[object],
    *,
    emit: ModelEventSink,
    model: str,
    abandon_callbacks: Callable[[], None] = _ignore_callback_completion,
) -> ModelResponse:
    """Consume one stream while separating provider and local termination.

    Provider iteration errors remain terminal LiteLLM outcomes, so the backend
    still joins their failure callbacks. A local parser, event sink, or caller
    interruption happens before LiteLLM observes normal exhaustion; those paths
    close the iterator and release the callback barrier before propagating the
    original exception.
    """

    accumulator = StreamAccumulator(model)
    try:
        iterator = aiter(stream)
    except BaseException:
        abandon_callbacks()
        await _close_stream_after_local_exit(stream)
        raise

    while True:
        try:
            chunk = await anext(iterator)
        except StopAsyncIteration:
            break
        except Exception as error:
            _raise_mapped(error, model=model)
        except BaseException:
            # Cancellation is local to the caller, so LiteLLM may never emit a
            # provider failure callback for this interrupted iterator.
            abandon_callbacks()
            await _close_stream_after_local_exit(iterator)
            raise

        try:
            for event in accumulator.ingest(chunk):
                emit(event)
        except BaseException:
            # The provider stream has not reached its terminal iteration yet.
            # Release the callback barrier before closing it, because closing a
            # partially consumed LiteLLM stream does not promise a terminal hook.
            abandon_callbacks()
            await _close_stream_after_local_exit(iterator)
            raise

    response = accumulator.complete()
    emit(ModelStreamCompleted(response))
    return response


async def _close_stream_after_local_exit(stream: object) -> None:
    """Close a partially consumed stream without replacing its causal error.

    LiteLLM and custom completion implementations may expose ``aclose`` without
    sharing a concrete stream type. Closing is best-effort because a cleanup
    failure must not mask the sink exception or cancellation that caused the
    early exit.
    """

    try:
        close = getattr(stream, "aclose", None)
        if not callable(close):
            return
        result = close()
        if inspect.isawaitable(result):
            await cast(Awaitable[object], result)
    except BaseException:
        pass


def _raise_mapped(error: Exception, *, model: str) -> NoReturn:
    mapped = map_litellm_error(error, model=model)
    if mapped is error:
        raise error
    raise mapped from error


__all__ = ["CompletionCallable", "LiteLLMBackend"]
