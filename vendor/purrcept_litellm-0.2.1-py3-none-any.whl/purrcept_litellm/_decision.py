"""Translate Core decisions to and from LiteLLM's OpenAI-shaped public API.

Compilation is pure and preserves ordered evidence and typed options. Response
conversion validates SDK-visible results only: LiteLLM may already have replaced
missing answers with refusals or supplied missing probability entries. We never
repair, threshold, or reinterpret those normalized values ourselves.
"""

from __future__ import annotations

import base64
from collections.abc import Mapping
from typing import TYPE_CHECKING, cast

from purrcept_core.models import (
    ChoiceAnswer,
    ChoiceProbability,
    ChoiceQuestion,
    DecisionAnswer,
    DecisionRefusal,
    DecisionRequest,
    DecisionResponse,
    DecisionResponseError,
    ImageBlock,
    ImageUrl,
    JsonValue,
    ModelRequestError,
    PredicateAnswer,
    PredicateQuestion,
    ScoreAnswer,
    ScoreProbability,
    TextBlock,
    TokenUsage,
)

from ._values import json_object, read, sequence, thaw_json
from .config import PROVIDER_OPTIONS_KEY

if TYPE_CHECKING:
    from .decision import LiteLLMDecisionConfig

# These parameters belong to the backend or to a different capability. Passing
# them through **kwargs could be silently ignored by the Decisions SDK.
_RESERVED = frozenset(
    {
        "model",
        "input",
        "state",
        "questions",
        "api_key",
        "api_base",
        "api_version",
        "timeout",
        "metadata",
        "callback",
        "callbacks",
        "success_callback",
        "failure_callback",
        "stream",
        "stream_options",
        "messages",
        "tools",
        "tool_choice",
        "temperature",
        "max_tokens",
        "max_output_tokens",
        "stop",
        "response_format",
        "parallel_tool_calls",
    }
)


def validate_options(options: Mapping[str, JsonValue]) -> None:
    """Reject overrides of transport ownership or decision semantics."""
    if not isinstance(cast(object, options), Mapping):
        raise ModelRequestError("Decision options must be a JSON object.", provider="litellm")
    reserved = _RESERVED.intersection(options)
    if reserved:
        raise ModelRequestError(
            f"Decision options cannot override: {', '.join(sorted(reserved))}.", provider="litellm"
        )


def compile_decision(
    request: DecisionRequest,
    *,
    model: str,
    config: LiteLLMDecisionConfig,
) -> dict[str, object]:
    """Create a fresh payload and enforce this adapter's supported API limits."""
    if not isinstance(cast(object, request), DecisionRequest):
        raise TypeError("request must be a DecisionRequest.")
    if not isinstance(cast(object, model), str) or not model.strip():
        raise ModelRequestError("model must be a nonempty string.", provider="litellm")
    if len(request.questions) > 128:
        raise ModelRequestError("LiteLLM supports at most 128 decision questions.")

    questions: list[dict[str, object]] = []
    for question in request.questions:
        item: dict[str, object] = {"name": question.name, "instructions": question.instructions}
        if isinstance(question, PredicateQuestion):
            item["type"] = "predicate"
        elif isinstance(question, ChoiceQuestion):
            keys = [
                str(c.value).lower() if isinstance(c.value, bool) else c.value
                for c in question.choices
            ]
            if len(keys) > 255 or len(set(keys)) != len(keys):
                # Compatibility: LiteLLM converts bools to System One string
                # keys even for validation of an OpenAI-bound request.
                raise ModelRequestError("LiteLLM choices exceed 255 or have colliding text keys.")
            item.update(
                type="choice",
                choices=[
                    {"value": c.value, **({"description": c.description} if c.description else {})}
                    for c in question.choices
                ],
            )
        else:
            if len(question.levels) > 10:
                raise ModelRequestError("LiteLLM supports at most 10 score levels.")
            item.update(
                type="score",
                levels=[
                    {
                        "label": level.label,
                        **({"description": level.description} if level.description else {}),
                    }
                    for level in question.levels
                ],
            )
        questions.append(item)

    evidence: object = request.input
    if not isinstance(request.input, str):
        parts: list[dict[str, object]] = []
        image_count = 0
        for block in request.input:
            if isinstance(block, TextBlock):
                parts.append({"type": "input_text", "text": block.text})
            else:
                image_count += 1
                if block.alt_text is not None:
                    parts.append({"type": "input_text", "text": block.alt_text})
                parts.append({"type": "input_image", "image_url": _image_url(block)})
        if image_count > 128:
            raise ModelRequestError("LiteLLM supports at most 128 decision images.")
        evidence = [{"role": "user", "content": parts}]

    options = cast(dict[str, object], thaw_json(config.default_options))
    scoped = request.provider_options.get(PROVIDER_OPTIONS_KEY, {})
    validate_options(cast(Mapping[str, JsonValue], scoped))
    options.update(cast(dict[str, object], thaw_json(scoped)))
    options.update(model=model, input=evidence, questions=questions)
    if request.metadata:
        options["metadata"] = thaw_json(request.metadata)
    for name in ("api_key", "api_base", "timeout"):
        value: object = getattr(config, name)
        if value is not None:
            options[name] = value
    return options


def _image_url(block: ImageBlock) -> str:
    """Encode bytes without fetching remote evidence or substituting descriptions."""
    if isinstance(block.source, ImageUrl):
        return block.source.url
    encoded = base64.b64encode(block.source.data).decode("ascii")
    return f"data:{block.source.media_type};base64,{encoded}"


def convert_decision(
    raw: object,
    *,
    request: DecisionRequest,
    requested_model: str,
) -> DecisionResponse:
    """Translate a normalized result, reporting malformed values as response errors."""
    try:
        answers = tuple(_answer(item) for item in sequence(read(raw, "answers", None)))
        raw_usage = read(raw, "usage", None)
        usage = None
        if raw_usage is not None:
            inputs = read(raw_usage, "input_tokens_details", None)
            outputs = read(raw_usage, "output_tokens_details", None)
            usage = TokenUsage(
                input_tokens=cast(int, read(raw_usage, "input_tokens", None)),
                output_tokens=cast(int, read(raw_usage, "output_tokens", None)),
                cached_input_tokens=cast(int, read(inputs, "cached_tokens", 0)),
                cache_write_input_tokens=cast(int, read(inputs, "cache_write_tokens", 0)),
                reasoning_tokens=cast(int, read(outputs, "reasoning_tokens", 0)),
            )
        response = DecisionResponse(
            answers,
            usage=usage,
            model=cast(str | None, read(raw, "model", requested_model)),
            provider_metadata=json_object(read(raw, "model_extra", None)),
        )
        response.validate_for(request)
        return response
    except (TypeError, ValueError) as error:
        raise DecisionResponseError(
            f"Invalid LiteLLM decision response: {error}", provider="litellm", model=requested_model
        ) from error


def _answer(raw: object) -> DecisionAnswer:
    """Use the discriminator without coercing provider values or inventing defaults."""
    name = cast(str, read(raw, "name", None))
    kind = read(raw, "type", None)
    if kind == "refusal":
        return DecisionRefusal(name)
    if kind == "predicate":
        return PredicateAnswer(name, cast(float, read(raw, "probability", None)))
    confidence = cast(float, read(raw, "confidence", None))
    probabilities = sequence(read(raw, "probabilities", None))
    if kind == "choice":
        return ChoiceAnswer(
            name,
            cast(str | bool, read(raw, "choice", None)),
            tuple(
                ChoiceProbability(
                    cast(str | bool, read(p, "value", None)),
                    cast(float, read(p, "probability", None)),
                )
                for p in probabilities
            ),
            confidence,
        )
    if kind == "score":
        return ScoreAnswer(
            name,
            cast(float, read(raw, "score", None)),
            tuple(
                ScoreProbability(
                    cast(int, read(p, "value", None)),
                    cast(str, read(p, "label", None)),
                    cast(float, read(p, "probability", None)),
                )
                for p in probabilities
            ),
            confidence,
        )
    raise ValueError(f"Unknown decision answer type: {kind!r}.")
