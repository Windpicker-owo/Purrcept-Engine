"""Share request-local callback ownership across LiteLLM capabilities.

Each invocation owns fresh callback lists and completion signals. Backends join
only their own detached terminal hooks; runtime owners flush and close exporters
after all calls finish. Cancellation abandons signals without closing borrowed
callbacks or touching LiteLLM global registries.
"""

from __future__ import annotations

import asyncio
import inspect
from collections.abc import Awaitable, Callable, Sequence
from typing import cast


def snapshot_callbacks(callbacks: Sequence[object]) -> tuple[object, ...]:
    """Validate and freeze callback ownership at the backend boundary."""

    raw_callbacks = cast(object, callbacks)
    if isinstance(raw_callbacks, (str, bytes)) or not isinstance(raw_callbacks, Sequence):
        raise TypeError("callbacks must be a sequence of LiteLLM callback values.")
    snapshot = tuple(callbacks)
    if any(callback is None for callback in snapshot):
        raise TypeError("callbacks must not contain None.")
    return snapshot


def event_callback(callback: object, *, method_name: str) -> object:
    """Select a CustomLogger event hook while preserving plain callbacks."""

    candidate = getattr(callback, method_name, None)
    return candidate if callable(candidate) else callback


class RequestCallbackCompletion:
    """Join callback work that LiteLLM otherwise detaches from SDK calls.

    One event belongs to each backend callback and is shared by its success and
    failure wrappers because exactly one terminal path is expected per request.
    Non-callable LiteLLM callback identifiers pass through unchanged; they have
    process-owned lifecycles and cannot provide a request-local completion
    signal. Runtime-created OpenTelemetry callbacks expose concrete event hooks
    and therefore always participate in the barrier.
    """

    __slots__ = ("_events", "failure_callbacks", "success_callbacks")

    def __init__(self, callbacks: tuple[object, ...]) -> None:
        """Allocate one terminal signal per borrowed callable for this invocation."""
        events: list[asyncio.Event] = []
        success_callbacks: list[object] = []
        failure_callbacks: list[object] = []

        for callback in callbacks:
            success = event_callback(callback, method_name="async_log_success_event")
            failure = event_callback(callback, method_name="log_failure_event")
            if not callable(success) or not callable(failure):
                success_callbacks.append(success)
                failure_callbacks.append(failure)
                continue

            completed = asyncio.Event()
            events.append(completed)
            success_callbacks.append(_async_callback_with_completion(success, completed))
            failure_callbacks.append(_sync_callback_with_completion(failure, completed))

        self._events = tuple(events)
        self.success_callbacks = success_callbacks
        self.failure_callbacks = failure_callbacks

    async def wait(self) -> None:
        """Wait until every request-owned callable reaches a terminal hook."""

        if self._events:
            await asyncio.gather(*(event.wait() for event in self._events))

    def abandon(self) -> None:
        """Release waiters when LiteLLM cannot reach a terminal callback.

        Abandonment does not cancel a callback that is already running. It only
        makes the request barrier terminal so a local stream failure or caller
        cancellation cannot be replaced by an indefinite lifecycle wait.
        """

        for event in self._events:
            event.set()


def _async_callback_with_completion(
    callback: Callable[..., object],
    completed: asyncio.Event,
) -> Callable[..., Awaitable[object]]:
    """Wrap one success callback and signal after its returned awaitable ends."""

    async def invoke(*args: object, **kwargs: object) -> object:
        try:
            result = callback(*args, **kwargs)
            if inspect.isawaitable(result):
                return await cast(Awaitable[object], result)
            return result
        finally:
            completed.set()

    return invoke


def _sync_callback_with_completion(
    callback: Callable[..., object],
    completed: asyncio.Event,
) -> Callable[..., object]:
    """Wrap one failure callback, including an unexpectedly async result."""

    def invoke(*args: object, **kwargs: object) -> object:
        try:
            result = callback(*args, **kwargs)
        except BaseException:
            completed.set()
            raise
        if inspect.isawaitable(result):
            pending = asyncio.create_task(
                _await_callback_result(cast(Awaitable[object], result), completed)
            )
            pending.add_done_callback(_consume_callback_task_result)
        else:
            completed.set()
        return result

    return invoke


async def _await_callback_result(result: Awaitable[object], completed: asyncio.Event) -> None:
    """Complete an async failure hook scheduled from LiteLLM's sync dispatcher."""

    try:
        await result
    finally:
        completed.set()


def _consume_callback_task_result(task: asyncio.Task[None]) -> None:
    """Retrieve a failure-hook exception after LiteLLM's sync dispatcher returns."""

    try:
        task.result()
    except BaseException:
        # Compatibility: LiteLLM treats callback failures as non-blocking. The
        # completion event is the ownership signal; the provider result remains
        # authoritative even when an observability callback fails.
        pass
