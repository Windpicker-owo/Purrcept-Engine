"""Execute portable decisions through LiteLLM's non-streaming Decisions API.

The runtime owns this backend and its borrowed callbacks. Each invocation
compiles one isolated payload, awaits one SDK call, and validates normalized
answers. Provider selection and wire conversion belong to LiteLLM; business
thresholds, retries, and exporter shutdown remain with the application/runtime.
"""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import dataclass, field
from importlib import import_module
from typing import Protocol, cast

from purrcept_core.models import DecisionRequest, DecisionResponse, JsonValue

from ._callbacks import RequestCallbackCompletion, event_callback, snapshot_callbacks
from ._config import validate_optional_string, validate_timeout
from ._decision import compile_decision, convert_decision, validate_options
from ._values import freeze_json_object
from .errors import map_litellm_error


class DecisionCallable(Protocol):
    """Borrowed async SDK seam supplied by tests or an embedding application.

    Called once with a fresh LiteLLM Decisions payload. It must return the OpenAI
    Decisions shape, not System One's keyed answers. Injected callables own callback
    scheduling; the backend only joins hooks scheduled by its built-in SDK path.
    """

    def __call__(self, **kwargs: object) -> Awaitable[object]:
        """Return a complete decision response without a stream iterator."""
        ...


def _empty_options() -> Mapping[str, JsonValue]:
    return {}


@dataclass(frozen=True, slots=True)
class LiteLLMDecisionConfig:
    """Immutable connection configuration, excluding chat-generation controls.

    Explicit credentials take precedence over LiteLLM's environment defaults.
    Default options and request options cannot replace the backend-owned payload,
    credentials, timeout, metadata, or callback lifecycle.
    """

    api_key: str | None = field(default=None, repr=False, kw_only=True)
    api_base: str | None = field(default=None, kw_only=True)
    timeout: float | None = field(default=None, kw_only=True)
    default_options: Mapping[str, JsonValue] = field(default_factory=_empty_options, kw_only=True)

    def __post_init__(self) -> None:
        """Freeze options and reject invalid transport configuration early."""
        validate_optional_string(self.api_key, field_name="api_key")
        validate_optional_string(self.api_base, field_name="api_base")
        validate_timeout(self.timeout)
        validate_options(self.default_options)
        object.__setattr__(
            self,
            "default_options",
            freeze_json_object(self.default_options, field_name="default_options"),
        )


class LiteLLMDecisionBackend:
    """DecisionBackend using adecisions for both OpenAI and System One providers.

    Instances are reusable across concurrent calls. They never register global
    callbacks or close borrowed exporters. The default SDK path waits for its own
    terminal callbacks so a short-lived event loop can safely flush afterwards.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        timeout: float | None = None,
        default_options: Mapping[str, JsonValue] | None = None,
        callbacks: Sequence[object] = (),
        decision: DecisionCallable | None = None,
    ) -> None:
        """Snapshot configuration and borrow an optional async transport seam."""
        self._config = LiteLLMDecisionConfig(
            api_key=api_key,
            api_base=api_base,
            timeout=timeout,
            default_options={} if default_options is None else default_options,
        )
        self._callbacks = snapshot_callbacks(callbacks)
        if decision is not None and not callable(cast(object, decision)):
            raise TypeError("decision must be an asynchronous callable or None.")
        self._decision = _default_decision if decision is None else decision
        self._join_callbacks = decision is None

    @property
    def config(self) -> LiteLLMDecisionConfig:
        """Return the backend's immutable configuration snapshot."""
        return self._config

    @property
    def callbacks(self) -> tuple[object, ...]:
        """Return borrowed callback instances; the runtime owns their shutdown."""
        return self._callbacks

    async def decide(self, request: DecisionRequest, *, model: str) -> DecisionResponse:
        """Compile, await, and validate one non-streaming decision invocation."""
        payload = compile_decision(request, model=model, config=self._config)
        completion = (
            RequestCallbackCompletion(self._callbacks)
            if self._callbacks and self._join_callbacks
            else None
        )
        if completion is not None:
            payload["success_callback"] = completion.success_callbacks
            payload["failure_callback"] = completion.failure_callbacks
        elif self._callbacks:
            payload["success_callback"] = [
                event_callback(cb, method_name="async_log_success_event") for cb in self._callbacks
            ]
            payload["failure_callback"] = [
                event_callback(cb, method_name="log_failure_event") for cb in self._callbacks
            ]

        try:
            try:
                raw = await self._decision(**payload)
            except Exception as error:
                mapped = map_litellm_error(error, model=model)
                if mapped is error:
                    raise
                raise mapped from error
            return convert_decision(raw, request=request, requested_model=model)
        except (asyncio.CancelledError, KeyboardInterrupt, SystemExit):
            # Lifecycle: cancellation can prevent LiteLLM from scheduling any
            # terminal hook. Release only our waiters, not borrowed callbacks.
            if completion is not None:
                completion.abandon()
            raise
        finally:
            if completion is not None:
                await completion.wait()


async def _default_decision(**kwargs: object) -> object:
    """Resolve the supported public SDK function without changing global state."""
    module = import_module("litellm")
    function = cast(Callable[..., Awaitable[object]], module.__dict__["adecisions"])
    return await function(**kwargs)
