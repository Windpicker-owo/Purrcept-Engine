"""Compile Core requests without importing the transport SDK or opening resources.

Engine callers use the same compilers as the backends for capacity planning and
evidence. The identity covers the compilation dependencies and package versions;
it is cached for this process, whose installed source must remain immutable.
Neither compilation nor identity lookup performs network or client initialization.
"""

from __future__ import annotations

import hashlib
from functools import lru_cache
from importlib.metadata import version
from pathlib import Path
from typing import Literal

from ._decision import compile_decision
from ._request import compile_request

__all__ = ["compile_decision", "compile_request", "compiler_identity"]


@lru_cache(maxsize=2)
def compiler_identity(kind: Literal["generation", "decision"]) -> str:
    """Return a process-stable identity for persisted capacity anchors.

    Callers must discard anchors when this identity changes. Both request kinds
    include shared configuration and value conversion code in the fingerprint;
    changes to those dependencies must invalidate anchors as well as direct
    compiler changes. Installed files must not be edited while this process runs.
    """
    if kind not in ("generation", "decision"):
        raise ValueError("Unknown compilation kind.")
    directory = Path(__file__).resolve().parent
    names = (
        "compilation.py",
        "_request.py",
        "_decision.py",
        "_values.py",
        "_config.py",
        "config.py",
        "decision.py",
    )
    digest = hashlib.sha256(b"purrcept-compilation-v1\0" + kind.encode())
    for name in names:
        digest.update(name.encode() + b"\0" + (directory / name).read_bytes())
    return (
        f"purrcept_litellm/{version('purrcept_litellm')}:litellm/{version('litellm')}:"
        f"core/{version('purrcept_core')}:"
        f"{kind}:v1:{digest.hexdigest()}"
    )
